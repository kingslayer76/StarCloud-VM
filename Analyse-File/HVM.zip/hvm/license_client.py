#!/usr/bin/env python3

import os
import sys
import json
import base64
import hashlib
import uuid
import logging
import sqlite3
import threading
from contextlib import contextmanager
from typing import Optional, Dict, Any, Tuple
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

logger = logging.getLogger(__name__)

EMBEDDED_PUB_KEY_PEM = """-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAiKiA5Azkj2P+9Oiy6N8DEFWxo3oFXK2cUIUxBTvllgw=
-----END PUBLIC KEY-----"""

LICENSE_SERVER_URL = ""
RECHECK_INTERVAL = 999999
MAX_ENVELOPE_AGE = 999999
SALT = b"HVM-Panel-v8-Salt2026"

_PUBLIC_KEY_OBJ = None
_DB_PATH = None
_LOCK = threading.RLock()
_THREAD_STARTED = False

def _load_public_key():
    global _PUBLIC_KEY_OBJ
    if _PUBLIC_KEY_OBJ is not None:
        return _PUBLIC_KEY_OBJ
    pem = EMBEDDED_PUB_KEY_PEM
    if not pem or "REPLACE WITH YOUR PUBLIC KEY" in pem:
        logger.error("License public key is not configured.")
        return None
    try:
        key = serialization.load_pem_public_key(pem.encode())
        if not isinstance(key, Ed25519PublicKey):
            logger.error("Public key is not Ed25519.")
            return None
        _PUBLIC_KEY_OBJ = key
        return key
    except Exception as e:
        logger.error("Failed to load public key: %s", e)
        return None

def get_public_key_fingerprint():
    pem = EMBEDDED_PUB_KEY_PEM
    normalised = "\n".join(line.strip() for line in pem.splitlines() if line.strip())
    return hashlib.sha256(normalised.encode()).hexdigest()

def get_server_url():
    return ""

def _get_db_path():
    return _DB_PATH or os.getenv("DATABASE_PATH", "hvm.db")

@contextmanager
def _db():
    conn = sqlite3.connect(_get_db_path(), timeout=15)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()

def init_license_storage(db_path=None):
    global _DB_PATH
    if db_path:
        _DB_PATH = db_path
    with _db() as conn:
        c = conn.cursor()
        c.execute("""
        CREATE TABLE IF NOT EXISTS license_state (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            machine_id TEXT,
            activated INTEGER DEFAULT 0,
            activated_at TEXT,
            activated_by TEXT,
            key_blob TEXT
        )""")
        c.execute("SELECT COUNT(*) FROM license_state")
        if c.fetchone()[0] == 0:
            c.execute("INSERT INTO license_state (id, machine_id, activated) VALUES (1, ?, 0)",
                      (str(uuid.uuid4()),))
        conn.commit()

def _get_state():
    with _db() as conn:
        c = conn.cursor()
        c.execute("SELECT * FROM license_state WHERE id = 1")
        return c.fetchone()

def _update_state(**fields):
    if not fields:
        return
    cols = ", ".join(f"{k} = ?" for k in fields)
    vals = list(fields.values())
    with _db() as conn:
        conn.execute(f"UPDATE license_state SET {cols} WHERE id = 1", vals)
        conn.commit()

def get_machine_id():
    s = _get_state()
    if s and s["machine_id"]:
        return s["machine_id"]
    mid = str(uuid.uuid4())
    _update_state(machine_id=mid)
    return mid

def _xor(data, key):
    out = bytearray(len(data))
    for i, b in enumerate(data):
        out[i] = b ^ key[i % len(key)]
    return bytes(out)

def _encrypt_key(plain, machine_id):
    key = hashlib.sha256(("license::" + machine_id).encode()).digest()
    blob = _xor(plain.encode(), key)
    return base64.b64encode(blob).decode()

def _decrypt_key(blob_b64, machine_id):
    if not blob_b64:
        return None
    try:
        blob = base64.b64decode(blob_b64)
        key = hashlib.sha256(("license::" + machine_id).encode()).digest()
        return _xor(blob, key).decode()
    except Exception:
        return None

def validate_license(license_key):
    pub = _load_public_key()
    if pub is None:
        return False
    try:
        signature = base64.b64decode(license_key)
    except Exception:
        return False
    machine_id = get_machine_id()
    message = (machine_id + SALT.decode()).encode()
    try:
        pub.verify(signature, message)
        return True
    except InvalidSignature:
        return False

def is_activated():
    s = _get_state()
    if not s:
        return False
    if not s.get("activated", 0):
        return False
    key_blob = s.get("key_blob")
    if not key_blob:
        return False
    machine_id = s.get("machine_id")
    stored_key = _decrypt_key(key_blob, machine_id)
    if not stored_key:
        return False
    return validate_license(stored_key)

def activate_with_server(license_key, activated_by="web"):
    license_key = (license_key or "").strip()
    if not license_key:
        return False, "License key is required."
    if validate_license(license_key):
        mid = get_machine_id()
        _update_state(
            activated=1,
            activated_at=_utcnow().isoformat(),
            activated_by=activated_by,
            key_blob=_encrypt_key(license_key, mid),
        )
        logger.info("License activated successfully.")
        return True, "License activated successfully!"
    else:
        return False, "Invalid license key."

def activate_with_server_wrapped(license_key, activated_by="web"):
    return activate_with_server(license_key, activated_by)

def revalidate_with_server():
    return True, "active", {"status": "active"}

def start_background_revalidation():
    pass

def deactivate_local(reason=""):
    _update_state(activated=0, key_blob=None)

def get_signed_envelope():
    if is_activated():
        return {"status": "active", "machine_id": get_machine_id()}
    return None

def get_status_info():
    s = _get_state()
    if not s:
        return {"activated": False}
    info = {k: s[k] for k in s.keys() if k not in ("key_blob",)}
    info["activated"] = bool(info.get("activated", 0))
    return info

def requires_license(fallback=None):
    from functools import wraps
    def deco(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            if not is_activated():
                if callable(fallback):
                    return fallback()
                raise PermissionError("License is not active")
            return fn(*args, **kwargs)
        return wrapper
    return deco

def _utcnow():
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).replace(tzinfo=None)

__all__ = [
    "LICENSE_SERVER_URL", "EMBEDDED_PUB_KEY_PEM",
    "RECHECK_INTERVAL", "MAX_ENVELOPE_AGE",
    "init_license_storage", "get_machine_id",
    "is_activated", "get_signed_envelope", "get_status_info",
    "verify_signed_response",
    "activate_with_server", "activate_with_server_wrapped",
    "revalidate_with_server", "deactivate_local",
    "start_background_revalidation",
    "requires_license",
    "get_public_key_fingerprint", "get_server_url",
]