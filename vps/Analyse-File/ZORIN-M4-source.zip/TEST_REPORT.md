# ZORIN-M4 verification report

Updated 2026-09-10. Code checks, synthetic speech, user feedback and real desktop checks are reported separately.

## Screen sharing, scroll verification and visual video fallback: 2026-09-12

The controller now chooses Chrome's named page document when Chromium exposes an empty WebView wrapper at the same size. This removes the prior zero-link accessibility root that made numbered YouTube selection fall through unnecessarily. When Chrome still exposes no card links, the approved Gemini screen-image fallback remains available and uses documented 0–1000 `[y_min, x_min, y_max, x_max]` boxes, converted to guarded physical coordinates only after a fresh-screen check.

The real read-only screen check recognized YouTube in a shared active-window frame and located the YouTube logo (`data/screen-vision-check.json`). A local real-window motion diagnostic verified both scroll directions and saved temporary before/down/up samples; it observed the page document and reported `Verified page scroll` for down and up. Numbered-video testing reached the visual fallback but the Gemini provider returned a transient outage before a click could be sent, so video numbers 2, 4 and 8 are not recorded as passed. No click is reported successful without URL or visual verification.

The regression suite passes: 206 tests in 5.54 seconds, including screen-packet transport, stale-frame rejection, normalized visual-box validation, Hindi/Hinglish ordinals and scroll-direction checks. The microphone gate diagnostic admitted normal speech at the configured quieter threshold without saving or uploading audio; it does not prove recognition accuracy in every room.

The saved audio diagnostic identified `Microphone (Usb Audio Device)` as the working input and recognized two spoken segments. `config.yaml` now selects that device by name instead of following a potentially changed Windows default. A new live capture could not be repeated in this session because the execution approval service reached its usage limit.

The next startup screenshot exposed the exact regression: the unqualified device name matched four PortAudio endpoints and Live aborted before opening audio. The configuration now stores the `MME` endpoint qualifier, and Live retries the Windows default once if a saved endpoint is unavailable instead of silently claiming microphone input.

## Hinglish routing and application identity repair: 2026-09-11

The user supplied a screenshot showing `Chrome pe YouTube` misrouted as an app name, invalid navigation JSON for `Chrome par YouTube search kar`, and a false completion after the garbled transcript `Jori new call`. Added Hinglish browser qualifiers and explicit search URL routing; literal typed payloads retain priority. Live tool results now reject conversational success with zero desktop actions. The cloud planner has one bounded JSON correction attempt before fallback. Live mode now starts its local fallback brain in the background, which its earlier startup path omitted.

Real testing through LiveAssistant's transcript/tool bridge exposed another bug: Start Search opened a Bing page titled Google Chrome, and title-only app verification accepted Edge as Chrome. Installed-app launch now uses the exact Get-StartApps identity; known-app window selection/verification also checks process identity. The test was repeated after fixing this failure.

All three repeated real checks passed (`data/hinglish-desktop-check.json`): `Zorin yotube kol` opened Chrome/YouTube in 17.469 s including app activation; `Zorin Chrome pe YouTube khol.` verified YouTube in 5.156 s; `Zorin Chrome par YouTube search kar.` reached `google.com/search?q=YouTube` in 9.531 s. These tests injected transcripts into the same Live tool/controller path and used real desktop input; they did not capture microphone audio or prove recognition accuracy. Latency remains variable, especially on first app launch.

An additional app check initially failed because Notepad remained in the background. The executor now explicitly focuses the registered app's observed window before verification and can reuse the topmost existing window for known-app launch requests. The repeat passed: Notepad foreground verified in 1.938 s, then YouTube in Chrome in 4.422 s (`data/hinglish-app-check.json`). No document text was entered or changed. Specific named-window selection still rejects ambiguous targets.

Automated suite: 190 passed in 5.31 s, including the exact reported phrases, search encoding, literal typing, no-action false success, bounded model correction, registered app launch, background-app focus and rejecting matching titles from the wrong process.

Restart verified at 13:04 IST on 2026-09-11: runtime PID 17800 matched new launcher 19320; Gemini connected, microphone capture and Puck output active, prior reply protection preserved. The loopback local brain health endpoint returned `status: ok`. These are startup/health checks, not a fresh microphone-accuracy test.

## Desktop control and conversational timing follow-up: 2026-09-10

- Fixed browser-qualified requests being treated as literal installed-app names. Chrome/site routing now uses a guarded address-replacement/navigation primitive with actual keyboard input and URL verification. Real testing exposed an additional appended-URL bug; exact address replacement and verification now reject that case before Enter. Existing Chrome reuse skips installed-app catalogue refresh.
- First-video selection passed on the real YouTube homepage. Fourth-video selection initially found only three visible cards and the old scroll failed. The selector now counts distinct watch/Shorts URLs across overlapping viewports with bounded wheel scrolling over an observed card. It rechecks position/focus before clicking. The repeat selected the fourth card and verified `youtube.com/shorts/GNrbxngFvRs`; see `data/desktop-fourth-video-check.json`. Other website video structures are not established by this check.
- Measured desktop opening: previous four-action route 7.078 s; two-action route 4.875 s in one run and 9.828 s in the later run. First-video click 7.204 s; fourth-video click 8.000 s including selection/scrolling/verification. These are typed controller timings, not microphone-to-spoken-reply timings, and show material remaining variability. The diagnostic disables companion speech, so its short acknowledgement does not represent Puck's dialogue delivery.
- User explicitly approved sharing visible control labels/positions plus foreground app/title. `cloud_control_labels` is enabled; the cloud observation excludes edit/combo fields, document bodies, field values, other windows, URL values and screenshots. Whole-screen/vision sharing remains off. Complex plans can now use the cloud model with the approved labels instead of being forced to the small local model.
- Removed the fixed 20-second post-conversation prompt. Optional Live remarks now require a settled context change, a model relevance decision (which can choose silence), and a fresh context/user-busy check before speech. Existing Puck style and microphone reply protection remain. This is contextual generation, not AGI or guaranteed human-level conversation.
- Automated suite: 177 tests passed in 4.27 s; pip check found no broken requirements. Coverage includes browser routing, exact-address verification, ordinal overlap/no-progress handling, label privacy and positive cloud routing, existing-window reuse, rejecting whole-sentence Start searches, and silent/stale activity decisions. Final startup checks are recorded separately below.
- Updated full assistant launched at 23:46 IST. Startup health at 23:46:22 confirmed Gemini connected, Puck selected, microphone capture and output active, reply protection/local speech gate enabled, approved control-label sharing enabled, and context-change proactivity. This is a point-in-time startup check; it does not establish live recognition accuracy or the user's subjective dialogue experience.

## Reply protection follow-up: 2026-09-10

The user reported repeated interruptions from noise and other people. Removed server-triggered automatic VAD interruption and added local sustained-speech/energy gating with preserved pre-roll and a minimum 600 ms endpoint. During an answer or the wait for an answer, speech is held as a candidate: Groq checks for an assistant address or explicit stop before any activityStart/audio is sent to Gemini. Rejected candidates do not clear playback, cancel desktop work or create another Gemini reply. Candidates retain their protected status even if playback finishes during capture. Mute/reconnect epochs discard stale candidates. No speaker-identification claim is made.

Real-service synthetic test `data/reply-protection-check.json` passed: background conversation rejected while actual Puck speech played; named stop candidate accepted. Test used stored synthetic clips, no microphone, no desktop actions. Unit suite: 155 passed in 4.24 s, including impulse rejection, low-energy speech rejection, protected/idle boundary behavior, pre-roll, reset, named versus unaddressed interruption, mute staleness and ensuring rejected audio never reaches the Gemini socket. The change preserves the selected Puck voice. Room/microphone performance still needs the user's live check.

## AI Studio voice import: 2026-09-10 evening

Default changed to `gemini-3.1-flash-live-preview`, voice `Puck`, from the supplied ZIP's server.ts. Implemented Python native audio transport, continuous playback, transcription, tool results, interruption, reconnection with in-memory session resumption, bounded microphone/playback queues, and existing desktop-worker integration. No React UI, HUD, theme tools, web server or fake immediate-success browser tools imported. No microphone recordings saved. No billing changes.

Real network/audio results (`data/live-voice-check.json`): two typed Hindi prompts produced audible Puck replies. Initial first playback was 0.765 s and 1.297 s; first received audio 0.750 s and 1.172 s. Both had zero recorded underruns. Total model turns took about 9 s because these include the spoken reply, not 9 s of initial silence. The synthetic tool test intentionally returned failure; the model did not claim successful opening. These timings used the initial 125 ms buffer; the final buffer is 200 ms after another test recorded one underrun.

Real synthetic-audio desktop probe (`data/live-desktop-check.json`): Gemini heard "Hello Soren YouTube kholo." Added a greeting-only correction for this observed assistant-name transcription. The next run verified Chrome focus/opening, address-bar focus and URL typing; the final page navigation was not verified. Do not count YouTube opening as passed. A later local observation showed WhatsApp in front, but that does not prove the exact cause of navigation failure. No automatic repeated attempt was added.

Real typed Notepad tool probe (`data/live-notepad-check.json`): Windows search lost focus and the local controller stopped; the Live voice accurately reported failure. This also is not a successful desktop check. This reply recorded one playback underrun before increasing the initial buffer. These failures show desktop verification can still dominate latency, independent of faster voice generation.

Regression suite: 147 tests passed; pip check found no broken requirements. New coverage includes contiguous PCM, bounded buffers, interrupt flush, mixed transcript/audio events, tool deduplication, waiting for real failure results, cancellation, mute epochs, rejecting ambient tool actions, grounding tasks in the user's words, preventing repeated task attempts, greeting normalization, and forgetting Live session context. Real microphone accuracy, sustained ambient conversation quality, long-session reconnection and the user's final subjective voice preference are not yet established by these tests. `data/runtime-health.json` records point-in-time connection/device startup health, not an ongoing guarantee.

Launch status: after the initial approval-review block, the user explicitly approved continuous Gemini Live microphone streaming. Full microphone-and-Puck-voice mode was launched on 2026-09-10 at 20:16 local time. Startup health confirmed the matching runtime process, connected Gemini session, active microphone, captured audio frames, and active output device. This confirms capture/startup, not the accuracy of any new user utterance.

All sections below describe earlier voice pipelines/tests unless explicitly marked otherwise.

## Latest checks: 2026-09-10

### Contextual companion follow-up

- User requested spontaneous, varied conversation tied to tabs/apps instead of fixed completion replies, and explicitly approved sending active titles and app names to the cloud conversation model. Full screen sharing and cloud vision remain off.
- Companion mode now detects settled foreground-title changes through a lightweight metadata read, generates a contextual remark or chooses silence, and checks that the title is still current before delivery. It does not execute actions. Busy/quiet states, pending microphone transcription, user input, repeated topics and near-duplicate wording suppress optional remarks. A generic service offer gets at most one rewrite.
- Greetings and successful task replies now use generated wording when companion mode is enabled. Task response text and optional speech synthesis run alongside desktop work; success replies are only handed to playback after verification. Cancellation/failure discards them. Conversation follow-ups can interrupt without repeating the assistant name; desktop work retains addressed interruption.
- The last 60 dialogue turns and bounded topic hashes persist locally. `/quiet` / “अभी मत बोलो” and `/unquiet` / “बात करते रहो” persist the user's preference. `/forget-memory` clears dialogue and topic records as well as existing memories.
- Real Groq replies to synthetic YouTube completion, Forza drift and Python tutorial contexts took 0.562–0.688 seconds. They related to the supplied context and earlier conversation. This is evidence of contextual generation, not human-level understanding or a guarantee of originality. See data/companion-smoke.json.
- A real foreground-activity test generated an unsolicited text remark after 6.125 seconds without submitting a command. It commented on a Steam-related context, rather than the documentation tab requested by the test; the user's active apps could change during the test. The documentation-tab expectation was not verified. That generic service-style remark prompted the bounded rewrite check. No speech was played in that diagnostic.
- Speech latency remains materially limited: the Gemini 3.1 probe confirmed daily quota exhaustion. One 2.5 fallback reply took 9.219 seconds to become ready. A later failed desktop-task diagnostic also fell back to Kokoro. Fast, consistent chosen-voice output is not established while cloud quotas/services fail.
- The live task diagnostic found a separate 19.5-second local replanning delay when multiple Chrome windows made the target ambiguous. The executor now reuses Chrome only when it is already the matching foreground app; other ambiguity asks for the intended window without model replanning. The failed task correctly discarded its generated success reply. Live success of the new overlap path has not yet been established under these quota/window conditions.
- Final automated checks: 136 tests passed in 7.21 seconds; dependency consistency passed. Coverage includes contextual event admission, title-only cloud payloads, local-only routing when title sharing is off, stale-context rejection, quiet persistence, dialogue/topic erasure, repetition/rewrite, unaddressed conversational follow-up, ambiguous-window fast failure, prepared-audio reuse and cancellation.

### Latency and YouTube follow-up, afternoon

- User reported 5–10 second delays, “Hello M4” taking the local planning route, and “YouTube kholo” becoming “YouTube poll.” User explicitly selected cloud recognition with local fallback after disclosure that speech segments go to Groq.
- Recognition now uses Groq whisper-large-v3 with multilingual spelling hints, a five-second request timeout, local fallback and rate-limit cooldown. The selected model recognized synthetic YouTube/Chrome/stop/Hindi conversation samples in 0.235–0.359 seconds. Turbo also understood all four at 0.203 seconds each; full v3 remains selected. These are synthetic checks, not a claim of accurate real-room listening. See data/cloud-stt-benchmark.json.
- Endpoint reduced from 840 to 600 ms. M4 is accepted as an address. Short greetings return locally without a model or desktop inspection. Ordinary conversation skips screen inspection and uses spoken replies; Hinglish configuration applies even to short English greetings. The persona asks a relevant conversational follow-up when appropriate, without forcing one every turn.
- Gemini 3.1 streaming is enabled. A real Hindi Algieba reply delivered its first chunk at 1.625 seconds and began device playback at 1.968 seconds, finishing with zero reported buffer underruns. No degraded event occurred. The 3.1 quota was available again for this check. The 2.5 fallback remains buffered. See data/streaming-voice-check.json.
- Fixed acknowledgement clips are cached by voice/model/delivery settings. Existing cached clips were ready in 0.016–0.031 seconds; two new clips took 7.547 and 3.328 seconds before caching, which motivated streaming for new replies. Only allowlisted synthetic acknowledgement text is cached. No personal conversation or microphone audio is saved.
- Final verification: 116 automated tests passed in 3.60 seconds. New coverage includes cloud/local fallback and cooldown, low-confidence silence, M4 greetings, YouTube planning, fixed-voice cache reuse/privacy, streaming before completion, truncated streams, cancellation, one continuous playback device and no fallback replay after partial speech. Dependency consistency also passed during this follow-up.
- Actual “YouTube kholo” desktop test: Chrome activation, address-bar selection and literal URL typing passed. First navigation verification hit a transient COM accessibility error. Verification now retries only screen observation, never the already-delivered input. The repeat passed all four steps and exited successfully. Tests ensure persistent observation errors cannot turn an old screen into a successful result.
- The initial cloud benchmark was blocked by automatic approval review reporting an account usage limit. A later launch was approved and the same benchmark retry succeeded; no approval bypass was used.

- Final verification: 92 automated tests passed in 2.35 seconds; dependency consistency passed.
- Full interactive microphone-and-voice mode was launched again on 2026-09-10 at 00:41 IST. The assistant process and local Whisper/reasoning servers passed health checks at 00:42 IST. These are point-in-time checks, not a guarantee that a later session remains running. See data/runtime-launch.json and data/runtime-health.json.
- The latest live microphone diagnostic recognized “Hello, Zorin. Chrome kholo.” and “Hello Zorin. Chrome kholo.” It processed 1,999 frames, with two transcription attempts and two recognized segments, no empty or stale transcripts. The user confirmed speaking all three requested phrases, but “Zorin, ruko” was not captured. No commands were executed and no microphone audio was saved. Live stop accuracy remains unverified.
- Cancel and microphone pause/resume now clear queued audio and invalidate partial and in-flight utterances. Diagnostic capture drains pending transcription instead of truncating it after a fixed delay. Regression tests cover these cases and optional speech-mode interruption.
- Automatic language detection is now the default. Synthetic Chrome, stop and casual Hindi samples were understood with both forced English and automatic detection. Automatic detection took 4.4–4.7 seconds, versus 2.3–2.4 seconds for forced English. These three synthetic samples do not establish noisy-room accuracy. Hindi cancellation, greetings and explicit durable memory have regression coverage.
- Gemini 3.1 returned a structured daily speech-quota failure. Gemini 2.5 Flash TTS is now a configured fallback, retaining Algieba and the chosen delivery instructions. A corrected transcript/delivery prompt passed actual startup: microphone, Whisper and local brain ready, speech started, final phase LISTENING, no degraded events. The actual backend was gemini-2.5-flash-preview-tts. Earlier microphone-test announcement failure preceded this correction. See data/startup-smoke.json.
- A real general-model desktop attempt repeatedly opened Notepad. Local planning then clicked Settings but failed to recognize completion. Explicit open-app-and-click instructions now use two verified steps. The final real “Open Notepad and click Settings” run verified both actions, replied “Done.” and exited successfully. No settings were changed. General multi-step model planning can still repeat actions or fail.
- Screen-dependent plans use the local provider when cloud screen sharing is disabled. An actual Groq planning response also confirmed that the saved Groq credentials worked during today's checks; provider availability can change.

## Current voice selection

Gemini `gemini-3.1-flash-tts-preview` is selected at the user's request. The locally saved API key works, subject to quotas. Actual Achird Hindi/Hinglish samples generated and played in 4.38 and 7.78 seconds. The user requested a different voice/delivery, so Zubenelgenubi (casual) and Algieba (smooth/calm) were also generated and played in 8.64 and 7.55 seconds. The user selected B: Algieba, smooth and calm. The 2.5 fallback has passed playback but has not received a separate subjective comparison. No key was displayed.

64 automated tests passed in 2.27 seconds before the final diagnostic/message changes. Coverage includes complete versus truncated Gemini responses, no request without a key, continuous multi-sentence playback, cancellation and Hindi fallback routing. Final verification is appended below.

The brain instructions request everyday modern Hindi/Hinglish: Hindi words in Devanagari for pronunciation, familiar English words retained. A real local-brain reply used “आज का दिन थोड़ा heavy था” and “मैं सुन रहा हूँ”. The small model sometimes copies examples or gives awkward replies; this does not establish human-quality conversation.

Before the afternoon streaming change, short replies were synthesized together and played as one buffer. The 2.5/local fallback paths retain this behavior. The current 3.1 streaming path and its measured playback timing are documented above.

## Voice auditions performed

| Path | Observed result |
| --- | --- |
| Microsoft Hindi Madhur / English Prabhat | Three samples generated in 1.53–1.84 seconds and played. User first found pronunciation much better, then clarified delivery still sounded robotic. |
| Tuned Madhur, Andrew Multilingual, Brian Multilingual | All three played on retry; Andrew initially returned no audio. User rejected these voices. |
| Official AI4Bharat Indic Parler demo, Rohit | Synthetic sample generated in 12.03 seconds and played. A malformed returned URL required the normal public file endpoint. Audition only, not a production dependency. User rejected the formal wording and voices. |
| Google Translate through gTTS | Two casual Hindi/Hinglish samples generated in 0.51–0.69 seconds and played. User found this artificial and requested Gemini TTS. This is distinct from Gemini/Cloud TTS. |
| Kokoro Hindi fallback | hm_omega with Hindi phonemization worked; cold generation 9.36 seconds. Lower-quality offline fallback, not an accepted final voice. |
| Gemini Flash TTS | Real Hindi/Hinglish synthesis and playback passed with the saved key. Initial Achird delivery did not satisfy the user; two alternative male voices played for comparison. |

Auditions use synthetic text; no microphone recordings were saved. Online auditions send synthetic reply text to their named services.

## Listening and local brain

- Noise alone no longer cancels replies in default confirmed interruption mode. While busy, recognized speech must address Zorin or match a stop/cancel phrase. Typed /cancel remains immediate. This is not speaker identification.
- Sparse-noise rejection, 840 ms endpoint, minimum speech duration, delayed echo filtering and transcript cancellation tests pass. They do not establish noisy-room accuracy.
- Whisper upgraded to ggml-large-v3-turbo-q5_0.bin. Synthetic Open Notepad and Chrome kholo were recognized correctly; measured transcription 7.391 seconds cold and 3.438 seconds warm.
- Revised live microphone check recognized “Okay.”: 1,333 frames, peak RMS 1,323.3, one utterance, no errors/stale drops. Earlier tests sometimes received near-silence or no transcripts. User screenshots show some real phrases and some mistakes. **Listening quality remains unresolved.**
- Qwen upgraded to Qwen3-4B-Instruct-2507-Q4_K_M.gguf. Actual short conversations complete locally without a paid API key. Social remarks use plain replies; tasks use structured plans.
- Local-server startup warmup, restart recovery and cooldown clearing are implemented. Full startup with upgraded Qwen/Whisper passed microphone/Whisper/brain readiness, speech and return to LISTENING with no degradation. That run preceded Gemini selection and does not prove Gemini works.

## Previously executed desktop/runtime checks

- Visible Notepad launch, focus, Ctrl+N and exact typing passed, leaving an unsaved test document.
- Named Notepad Settings click passed; Appearance detected without changing settings.
- A real planning task stopped before input when foreground changed; regression verifies the guard.
- Win32 input layout, extended keys and activation corrected. Exact labels precede fuzzy matches.
- Windows job cleanup terminated owned children after abrupt parent exit. Normal shutdown passed.
- Dependency consistency passed. USB microphone and High Definition Audio headphones detected.
- Tests cover memory/feedback, secrets, sensitive-action confirmation/expiry, provider failures, stale transcripts, bounded recovery and authenticated WebSocket access.

## Remaining limits

The selected Algieba audition was accepted. Human microphone recognition in noise, live voice stopping, interruption latency and long sessions still need evaluation. Free API quotas can trigger a different model or lower-quality local voice fallback. Arbitrary desktop tasks and Steam to Forza Horizon 5 are unverified. Cloud vision is off and untested; no tablet UI or outgoing tablet audio exists. Autostart remains disabled. This is a development assistant, not AGI or a guarantee of every possible PC task.

Latest verification: 64 tests passed in 2.15 seconds after configurable delivery was added. The saved key passed actual synthesis. Three actual conversational replies completed in 0.77–1.11 seconds, including everyday Hindi/Hinglish. Full voice startup/launch is checked separately below.

User selected candidate B: Algieba, smooth and calm. Its exact audition delivery instructions are saved in config.yaml. Full startup with this selected Gemini voice passed: microphone stream, Whisper and local brain ready; speech started; final phase LISTENING; no degraded events. This verifies startup and playback, not noisy-room recognition accuracy. A full interactive microphone-and-voice session was launched; metadata is in data/runtime-launch.json.
