"""Real scroll/video checks via Live's controller bridge; no microphone."""
import asyncio,json,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from core.config import load_config
from core.instance import InstanceLease
from core.live_assistant import LiveAssistant
from hands.executor import WindowsExecutor
from safety.secrets import redact

async def main():
    c=load_config();c.memory.enabled=False;c.personality.companion_enabled=False
    if '--no-cloud' in sys.argv:
        c.privacy.cloud_vision=False;c.privacy.live_screen_sharing=False
    a=LiveAssistant(c,WindowsExecutor(c.automation,c.privacy));lease=InstanceLease()
    results=[]
    goals=['YouTube kholo','scroll down','scroll up','play video number 2','YouTube kholo','4 wala video chalao','YouTube kholo','play video number 8']
    if '--scroll-only' in sys.argv:
        goals=goals[:3]
    if '--videos-only' in sys.argv:
        goals=[goals[0]]+goals[3:]
    try:
        for goal in goals:
            before=time.monotonic();await a._transcript('user',goal)
            result=await asyncio.wait_for(a._tool('desktopTask',{'request':goal}),60)
            obs=await a.executor.observe()
            item={'goal':goal,'result':result,'seconds':round(time.monotonic()-before,3),'url':obs.get('browser_url','')}
            results.append(item);print(redact(json.dumps(item,ensure_ascii=False)),flush=True)
            if not result['success']:
                break
    finally:
        await a.close();lease.close()
        Path('data/scroll-video-check.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
    return int(len(results)!=len(goals) or any(not r['result']['success'] for r in results))

if __name__=='__main__':
    raise SystemExit(asyncio.run(main()))
