import asyncio
from unittest.mock import patch
import pytest
from core.config import VoiceConfig
from core.events import EventBus
from voice.microphone import Microphone
from voice.commands import voice_command
from brain.intent import is_cancel


@pytest.mark.parametrize("phrase", ["ज़ोरिन, रुको।", "हेलो जोरिन, रुक जाओ।", "Zorin, stop talking!", "ज़ोरिन, बस।", "रुको।"])
def test_hindi_stop_is_admitted_while_busy(phrase):
    command = voice_command(phrase, busy=True)
    assert command is not None and is_cancel(command)


@pytest.mark.parametrize("phrase", ["मत रुको।", "रुको मत।", "don't stop", "stop music", "Zorintosh, open Chrome"])
def test_other_speech_is_not_an_assistant_stop(phrase):
    assert not is_cancel(phrase)
    assert voice_command(phrase, busy=True) is None


def test_hindi_address_preserves_the_command():
    assert voice_command("हेलो ज़ोरिन। Chrome खोलो।", busy=True) == "Chrome खोलो।"


@pytest.mark.parametrize("name", ["Zorin", "Zorian", "Zoiro"])
def test_comma_after_greeting_and_observed_name_spelling(name):
    assert voice_command(f"Hello, {name}. Chrome kholo.", busy=True) == "Chrome kholo."


async def test_pause_resume_invalidates_inflight_transcription_and_queued_audio():
    started, finish = asyncio.Event(), asyncio.Event()
    heard = []
    class STT:
        async def transcribe(self, pcm):
            started.set()
            await finish.wait()
            return "Open Chrome"
    async def on_text(text): heard.append(text)
    mic = Microphone(VoiceConfig(), STT(), EventBus(), on_text, lambda: None)
    worker = asyncio.create_task(mic._transcribe())
    try:
        mic.segments.put_nowait((mic.epoch, b"old audio"))
        await started.wait()
        mic.audio.put_nowait(bytes(960))
        mic.enabled = False
        mic.enabled = True
        finish.set()
        await asyncio.sleep(.01)
        assert mic.audio.empty()
        assert not heard
        assert mic.stats["stale_transcripts"] == 1
    finally:
        worker.cancel()
        await asyncio.gather(worker, return_exceptions=True)


async def test_cancellation_clears_partial_utterance_before_next_command():
    class Segmenter:
        def __init__(self, config): self.parts = []
        def feed(self, frame):
            self.parts.append(frame)
            return (b"".join(self.parts), False) if len(self.parts) == 2 else (None, False)
    mic = Microphone(VoiceConfig(), None, EventBus(), None, lambda: None)
    with patch("voice.microphone.Segmenter", Segmenter):
        worker = asyncio.create_task(mic._segment())
        try:
            mic.audio.put_nowait(b"old")
            await asyncio.sleep(.01)
            mic.invalidate_pending()
            mic.audio.put_nowait(b"new1")
            mic.audio.put_nowait(b"new2")
            await asyncio.sleep(.01)
            assert mic.segments.get_nowait() == (mic.epoch, b"new1new2")
        finally:
            worker.cancel()
            await asyncio.gather(worker, return_exceptions=True)


async def test_diagnostic_drain_finishes_the_final_inflight_transcript():
    started = asyncio.Event()
    heard = []
    class STT:
        async def transcribe(self, pcm):
            started.set()
            await asyncio.sleep(.08)
            return "Chrome kholo"
    async def on_text(text): heard.append(text)
    mic = Microphone(VoiceConfig(), STT(), EventBus(), on_text, lambda: None)
    async def capture(): await asyncio.Event().wait()
    mic.tasks = [asyncio.create_task(capture()), asyncio.create_task(mic._segment()), asyncio.create_task(mic._transcribe())]
    try:
        mic.segments.put_nowait((mic.epoch, bytes(960)))
        await started.wait()
        await mic.finish_capture(timeout=2)
        assert heard == ["Chrome kholo"]
        assert not mic.transcribing
    finally:
        await mic.close()


async def test_optional_speech_barge_in_keeps_its_triggering_utterance():
    class Segmenter:
        def __init__(self, config): self.parts = []
        def feed(self, frame):
            self.parts.append(frame)
            return (None, True) if len(self.parts) == 1 else (b"".join(self.parts), False)
    interruptions = []
    mic = Microphone(VoiceConfig(barge_in_mode="speech"), None, EventBus(), None, lambda: interruptions.append(True))
    with patch("voice.microphone.Segmenter", Segmenter):
        worker = asyncio.create_task(mic._segment())
        try:
            mic.audio.put_nowait(b"hello ")
            mic.audio.put_nowait(b"zorin")
            await asyncio.sleep(.01)
            assert interruptions == [True]
            assert mic.segments.get_nowait() == (1, b"hello zorin")
        finally:
            worker.cancel()
            await asyncio.gather(worker, return_exceptions=True)
