import time


class Proactive:
    """Relevance gating and per-event/global cooldowns; silence is the default."""
    WEIGHTS = {"startup": .90, "task_completed": .85, "repeated_failure": .94,
               "app_opened": .35, "returned": .78, "high_memory": .80, "wait_finished": .96}

    def __init__(self, config):
        self.config = config
        self.last_spoken = -1e12
        self.seen = {}

    def score(self, kind, *, relevant=False, busy=False):
        if busy or self.config.proactivity == 0:
            return 0.
        return min(1., self.WEIGHTS.get(kind, .1) + (.35 if relevant else 0) + (self.config.proactivity - .35) * .2)

    def accept(self, kind, *, key="", relevant=False, busy=False, now=None):
        now = time.monotonic() if now is None else now
        score = self.score(kind, relevant=relevant, busy=busy)
        if score < self.config.relevance_threshold or now - self.last_spoken < self.config.cooldown_seconds:
            return False
        event_key = (kind, key)
        if now - self.seen.get(event_key, -1e12) < self.config.cooldown_seconds * 3:
            return False
        self.last_spoken = now
        self.seen[event_key] = now
        if len(self.seen) > 500:
            self.seen = {k: v for k, v in self.seen.items() if now - v < 86400}
        return True
