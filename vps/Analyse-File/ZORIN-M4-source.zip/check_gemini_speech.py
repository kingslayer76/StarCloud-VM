"""Probe one short synthesis request; report sanitized status, no playback."""
import asyncio
import argparse
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.config import ROOT, load_config
from voice.tts import GeminiTTSProvider, SpeechProviderFailure


async def run(model=None):
    config = load_config().voice
    if model:
        config.gemini_tts_model = model
    config.gemini_tts_fallback_models = []  # Diagnose this model only.
    try:
        audio, rate = await GeminiTTSProvider(config).synthesize_async("हाँ, मैं सुन रहा हूँ। आराम से बताओ।")
        import soundfile as sf
        sf.write(ROOT / "data" / (config.gemini_tts_model + "-check.wav"), audio, rate)
        result = {"available": True, "audio_seconds": round(len(audio)/rate, 2)}
    except SpeechProviderFailure as error:
        result = {"available": False, "reason": str(error), "retry_seconds": error.cooldown}
    except RuntimeError as error:
        result = {"available": False, "reason": str(error)}
    except Exception as error:
        result = {"available": False, "reason": type(error).__name__}
    result["model"] = config.gemini_tts_model
    filename = "gemini-speech-fallback-health.json" if model else "gemini-speech-health.json"
    (ROOT / "data" / filename).write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", choices=["gemini-2.5-flash-preview-tts", "gemini-3.1-flash-tts-preview"])
    asyncio.run(run(parser.parse_args().model))
