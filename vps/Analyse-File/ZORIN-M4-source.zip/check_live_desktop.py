"""Synthetic audio -> Live understanding -> verified real YouTube action -> voice.

Uses an existing synthetic test recording. Never opens the microphone.
"""
import asyncio
import base64
import json
from pathlib import Path
import sys
import time
import numpy as np
import soundfile as sf
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.config import load_config
from core.events import EventBus
from core.instance import InstanceLease
from core.live_assistant import LiveAssistant
from hands.executor import WindowsExecutor


async def main():
    config = load_config()
    config.memory.enabled = False
    bus = EventBus()
    events = bus.subscribe()
    lease = InstanceLease()
    assistant = LiveAssistant(config, WindowsExecutor(config.automation, config.privacy), bus=bus)
    result = {"source": "synthetic speech recording", "microphone": False}
    try:
        await assistant.start(voice=False, proactive=False)
        started = time.monotonic()
        if '--notepad' in sys.argv:
            result['source'] = 'typed Open Notepad request'
            await assistant.submit('Open Notepad')
        else:
            audio, rate = sf.read('data/recognition-sample-youtube.wav', dtype='float32')
            if audio.ndim == 2:
                audio = audio.mean(axis=1)
            samples = np.interp(np.arange(round(len(audio)*16000/rate))*rate/16000, np.arange(len(audio)), audio)
            pcm = (np.clip(samples, -1, 1)*32767).astype('<i2').tobytes()
            await assistant.live.send({"realtimeInput": {"activityStart": {}}})
            for offset in range(0, len(pcm), 3200):
                await assistant.live.send({"realtimeInput": {"audio": {"data": base64.b64encode(pcm[offset:offset+3200]).decode(), "mimeType": "audio/pcm;rate=16000"}}})
                await asyncio.sleep(.1)
        ended = time.monotonic()
        assistant.live.last_send_at = ended
        if '--notepad' not in sys.argv:
            await assistant.live.send({"realtimeInput": {"activityEnd": {}}})
        rows = []
        async with asyncio.timeout(65):
            while True:
                event = await events.get()
                if event.type in {'assistant_text', 'recognized_speech', 'verification', 'current_action', 'latency', 'degraded'}:
                    row = {'type': event.type, 'elapsed': round(time.monotonic()-started, 3), **event.data}
                    rows.append(row)
                    print(json.dumps(row, ensure_ascii=False), flush=True)
                if event.type == 'assistant_text':
                    break
            while assistant.live.output.speaking:
                await asyncio.sleep(.1)
        result.update(outcome=assistant.state.outcome, transcript=assistant.last_user_text,
                      reply=assistant.last_response, events=rows,
                      audio_end_to_playback_seconds=round(assistant.live.output.first_played_at-ended, 3) if assistant.live.output.first_played_at else None,
                      underruns=assistant.live.output.underruns)
    except Exception as error:
        from safety.secrets import redact
        result['error'] = redact(str(error)) or type(error).__name__
    finally:
        await assistant.close()
        lease.close()
        filename = 'data/live-notepad-check.json' if '--notepad' in sys.argv else 'data/live-desktop-check.json'
        Path(filename).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
        print(json.dumps(result, ensure_ascii=False), flush=True)
    return int(result.get('outcome') != 'success')

if __name__ == '__main__':
    raise SystemExit(asyncio.run(main()))
