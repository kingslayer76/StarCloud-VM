"""Audition the official Indic Parler demo using only a synthetic test sentence."""
import asyncio
import io
import json
from pathlib import Path
import sys
import time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.config import ROOT, load_config
from core.state_machine import Cancellation
from voice.playback import Playback
from voice.tts import EdgeTTSProvider


async def run():
    import httpx
    import soundfile as sf
    origin = "https://ai4bharat-indic-parler-tts.hf.space"
    text = "अच्छा, तो आज भी पीसी ने तुम्हारा धैर्य टेस्ट किया? चलो, बताओ क्या हुआ, मैं सुन रहा हूँ।"
    style = "Rohit speaks in a warm, relaxed and expressive conversational voice, with natural changes in intonation and a slightly playful tone. Moderate pace, very clear close-up audio, no background noise."
    start = time.monotonic()
    async with httpx.AsyncClient(timeout=60, follow_redirects=True) as client:
        response = await client.post(origin + "/gradio_api/call/generate_finetuned", json={"data": [text, style]})
        response.raise_for_status()
        event_id = response.json()["event_id"]
        async with client.stream("GET", origin + "/gradio_api/call/generate_finetuned/" + event_id) as stream:
            stream.raise_for_status()
            event, output = "", None
            async for line in stream.aiter_lines():
                if line.startswith("event: "): event = line[7:]
                if line.startswith("data: ") and event == "error": raise RuntimeError("Official demo generation failed")
                if line.startswith("data: ") and event == "complete": output = json.loads(line[6:])[0]
        if not output: raise RuntimeError("No audio result from the official demo")
        response = await client.get(output["url"])
        if response.status_code == 404:
            # Gradio's call route can incorrectly duplicate its own API prefix
            # in returned URLs. Fetch this generation's file via its file API.
            response = await client.get(origin + "/gradio_api/file=" + output["path"])
        response.raise_for_status()
        audio, rate = sf.read(io.BytesIO(response.content), dtype="float32")
    path = ROOT / "data/voice-candidate-D.wav"
    sf.write(path, audio, rate)
    result = {"label": "D", "provider": "Official AI4Bharat Indic Parler demo", "speaker": "Rohit",
              "generation_seconds": round(time.monotonic()-start, 2), "audio_seconds": round(len(audio)/rate, 2), "path": str(path)}
    (ROOT / "data/voice-candidate-D.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result), flush=True)
    config = load_config().voice
    playback = Playback(config.output_device)
    announcement, sr = await EdgeTTSProvider(config).synthesize_async("Voice D. Expressive Hindi.")
    await playback.play(announcement, sr, Cancellation())
    await playback.play(audio, rate, Cancellation())


if __name__ == "__main__":
    asyncio.run(run())
