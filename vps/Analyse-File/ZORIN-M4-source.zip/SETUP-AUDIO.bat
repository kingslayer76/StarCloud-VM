@echo off
setlocal
cd /d "%~dp0"
title ZORIN-M4 - Audio Setup
if not exist ".venv\Scripts\python.exe" (
  echo Run setup.ps1 first.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -u scripts\audio_setup.py
set "ZORIN_EXIT=%errorlevel%"
pause
exit /b %ZORIN_EXIT%
