import argparse
import asyncio
import json
import sys
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
from core.config import load_config
from core.events import EventBus
from core.orchestrator import Assistant
from core.diagnostics import doctor
from hands.executor import WindowsExecutor
from safety.secrets import redact

HELP = """ZORIN-M4
Type naturally: Open Notepad | Open Notepad and type: hello boss.
Chrome kholo | Click the Settings icon | Scroll down | Volume 30
Remember that I prefer short replies.
/status             Current operation
/cancel             Stop remaining actions and speech
/confirm ID         Approve the exact pending action (60-second expiry)
/deny ID            Reject it
/quiet /unquiet     Suppress / restore proactive remarks
/memory            Show stored preferences
/voice-test        Speak a short voice test
/reconnect         Reconnect Gemini Live voice
/devices           List microphones and speakers
/mic off /mic on   Pause / resume microphone input
/screen on /screen off   Share / pause active-window images with Gemini
/forget-memory     Explicitly erase all stored memories, feedback and recipes
/quit              Shut down and release microphone
Voice capture is continuous while enabled. Use headphones for reliable barge-in.
Live mode uses Puck audio-to-audio with reply protection.
While he replies, say "Zorin, ..." or "stop" to interrupt. /cancel stops locally.
--cascade starts the previous Groq/Whisper + separate TTS pipeline.
"""


async def terminal_events(bus, debug=False):
    queue = bus.subscribe()
    try:
        while True:
            event = await queue.get()
            data = event.data
            if event.type in {"system_stats", "task_progress"}:
                continue
            if not debug and event.type in {"assistant_state", "speaking_state", "plan", "voice_filter"}:
                continue
            if event.type == "assistant_text":
                print(f"\nZORIN-M4 > {redact(data['text'])}", flush=True)
            elif event.type == "confirmation_required":
                a = data["action"]
                print(f"\n[APPROVAL] {a['kind']}: {redact(a['target'] or a['text'])}\n{data['reason']}\nType /confirm {data['id']} or /deny {data['id']}", flush=True)
            elif event.type == "recognized_speech":
                print(f"[HEARD] {redact(data['text'])}", flush=True)
            else:
                safe = " | ".join(f"{key}={redact(str(value))}" for key, value in data.items())
                print(f"[{event.type.upper()}] {safe}", flush=True)
    finally:
        bus.unsubscribe(queue)


async def terminal(assistant):
    from core.console import read_line
    while True:
        try:
            text = await read_line()
        except EOFError:
            return
        text = text.strip()
        if text in {"/quit", "/exit"}:
            return
        if text == "/help":
            print(HELP)
        elif text == "/devices":
            import sounddevice as sd
            print(sd.query_devices())
        elif text == "/memory":
            print(json.dumps(assistant.memory.preferences(), indent=2, ensure_ascii=False))
        elif text == "/forget-memory":
            if hasattr(assistant, "forget_memory"):
                await assistant.forget_memory()
                print("Local memory erased; starting a fresh Live session.")
                continue
            assistant.interrupt(silent=True)
            assistant.memory.forget()
            assistant.history.clear()
            assistant.persona.recent.clear()
            print("Local memories, feedback and recipes erased.")
        else:
            await assistant.submit(text)


async def run(args):
    config = load_config(args.config) if args.config else load_config()
    if args.devices:
        import sounddevice as sd
        print(sd.query_devices())
        return 0
    if args.text or args.command or args.smoke_desktop:
        config.voice.enabled = False
    if args.text:
        print("[MODE] TEXT ONLY: microphone and spoken replies are OFF. Run without --text for full voice.", flush=True)
    elif args.keyboard:
        print("[MODE] KEYBOARD + VOICE: type commands; ZORIN-M4 speaks replies.", flush=True)
    executor = WindowsExecutor(config.automation, config.privacy)
    if args.doctor:
        try:
            result = await doctor(config, executor, args.audio_probe)
            if args.json:
                print(json.dumps(result, indent=2))
            else:
                for item in result:
                    print(f"[{item['status']:<14}] {item['component']}: {item['detail']}")
            return 1 if any(r["status"] == "FAIL" for r in result) else 0
        finally:
            await executor.close()
    from core.instance import InstanceLease
    lease = InstanceLease()
    bus = EventBus()
    use_live = config.voice.enabled and config.voice.mode == "gemini_live" and not args.cascade
    if use_live:
        from core.live_assistant import LiveAssistant
        assistant = LiveAssistant(config, executor, bus=bus)
    else:
        assistant = Assistant(config, executor, bus=bus)
    logger = asyncio.create_task(terminal_events(bus, args.debug))
    websocket = None
    await asyncio.sleep(0)
    try:
        await assistant.start(voice=not args.text and not args.keyboard and not args.command and not args.smoke_desktop, proactive=not args.command and not args.smoke_desktop)
        if config.services.websocket_enabled:
            from services.websocket_server import serve
            websocket = asyncio.create_task(serve(assistant))
            websocket.add_done_callback(lambda t: print("[WEBSOCKET] stopped: " + type(t.exception()).__name__) if not t.cancelled() and t.exception() else None)
        if args.smoke_desktop:
            from brain.schemas import Plan, action
            await assistant.submit("Open Notepad")
            await assistant.task
            if assistant.state.outcome != "success":
                return 1
            observation = await executor.observe()
            back_to_editor = any(e["name"] == "Back" and e["type"] == "ButtonControl" for e in observation.get("elements", []))
            original_route = assistant.intent.route
            def smoke_route(text):
                preparation = [action("click", target="Back", expected_kind="element", expected_value="Text editor")] if back_to_editor else []
                return Plan(actions=preparation + [
                    action("key", text="ctrl+n", expected_kind="element", expected_value="Text editor"),
                    action("type_text", target="Text editor", text="This assistant actually works.",
                           expected_kind="text", expected_value="This assistant actually works.")])
            assistant.intent.route = smoke_route
            await assistant.submit("Open Notepad and type: This assistant actually works.")
            await assistant.task
            assistant.intent.route = original_route
            return 0 if assistant.state.outcome == "success" else 1
        if args.command:
            await assistant.submit(args.command)
            if assistant.task:
                await assistant.task
            return 1 if assistant.state.outcome in {"failed", "cancelled"} else 0
        if args.background:
            await asyncio.Event().wait()
        else:
            print(HELP)
            await terminal(assistant)
    finally:
        if websocket:
            websocket.cancel()
            await asyncio.gather(websocket, return_exceptions=True)
        await assistant.close()
        lease.close()
        logger.cancel()
        await asyncio.gather(logger, return_exceptions=True)
    return 0


def main():
    parser = argparse.ArgumentParser(description="ZORIN-M4 personal computer intelligence")
    parser.add_argument("--config")
    parser.add_argument("--doctor", action="store_true")
    parser.add_argument("--audio-probe", action="store_true", help="Doctor: capture one second in RAM, then discard")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--devices", action="store_true", help="List audio devices and exit")
    parser.add_argument("--debug", action="store_true", help="Show detailed internal state events")
    parser.add_argument("--text", action="store_true", help="No microphone or speech output")
    parser.add_argument("--keyboard", action="store_true", help="Typed commands with spoken replies; no microphone")
    parser.add_argument("--cascade", action="store_true", help="Use the previous STT + brain + TTS pipeline instead of Gemini Live")
    parser.add_argument("--command", help="Run one typed command, then exit")
    parser.add_argument("--background", action="store_true", help="Voice/service mode without console input")
    parser.add_argument("--smoke-desktop", action="store_true", help="Visibly open Notepad and type a harmless test sentence")
    args = parser.parse_args()
    try:
        return asyncio.run(run(args))
    except KeyboardInterrupt:
        print("\nZORIN-M4 stopped.")
        return 0
    except Exception as error:
        print(f"[STARTUP ERROR] {type(error).__name__}: {redact(str(error))}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
