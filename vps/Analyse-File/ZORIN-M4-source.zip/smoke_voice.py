"""Local synthetic speech round trip. Does not record or upload microphone audio."""
import argparse
import asyncio
import json
import sys
import time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.config import load_config, ROOT
import numpy as np
from core.events import EventBus
from core.state_machine import Cancellation
from voice.tts import KokoroProvider
from voice.stt import SpeechToText
from voice.playback import Playback
from voice.vad import Segmenter


async def run(play=False, vulkan=False, model=None):
    config = load_config()
    if model:
        config.voice.whisper_model = model
    if vulkan:
        config.voice.whisper_executable = "vendor/whisper-vulkan/whisper-server.exe"
        config.voice.whisper_url = "http://127.0.0.1:8180/inference"
    stt = SpeechToText(config.voice, EventBus())
    tts = KokoroProvider(config.voice)
    results = []
    try:
        print("Starting local Whisper", flush=True)
        await stt.start()
        for phrase in ["Open Notepad.", "Chrome kholo."]:
            print(f"Synthesizing: {phrase}", flush=True)
            start = time.monotonic()
            audio, rate = await asyncio.to_thread(tts.synthesize, phrase)
            synthesis_seconds = time.monotonic() - start
            if play:
                await Playback(config.voice.output_device).play(audio, rate, Cancellation())
            # Linear resampling is sufficient for this short smoke test; input capture is already 16 kHz.
            samples = np.interp(np.arange(round(len(audio)*16000/rate))*rate/16000, np.arange(len(audio)), audio)
            pcm = (np.clip(samples, -1, 1)*32767).astype(np.int16).tobytes()
            segmenter = Segmenter(config.voice)
            padded = pcm + bytes((-len(pcm)) % 960) + bytes(960 * ((config.voice.endpoint_ms+29)//30+6))
            segments = []
            for offset in range(0, len(padded), 960):
                segment, _ = segmenter.feed(padded[offset:offset+960])
                if segment:
                    segments.append(segment)
            start = time.monotonic()
            text = await stt.transcribe(pcm)
            item = {"input": phrase, "transcript": text, "vad_utterances": len(segments), "synthesis_seconds": round(synthesis_seconds, 3), "transcription_seconds": round(time.monotonic()-start, 3)}
            results.append(item)
            print(json.dumps(item, ensure_ascii=False), flush=True)
        (ROOT / "data").mkdir(exist_ok=True)
        (ROOT / "data/voice-smoke.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
        return 0 if all(r["transcript"] and r["vad_utterances"] for r in results) else 1
    finally:
        await stt.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--play", action="store_true")
    parser.add_argument("--vulkan", action="store_true")
    parser.add_argument("--model", help="Compare a different installed Whisper model")
    args = parser.parse_args()
    raise SystemExit(asyncio.run(run(args.play, args.vulkan, args.model)))
