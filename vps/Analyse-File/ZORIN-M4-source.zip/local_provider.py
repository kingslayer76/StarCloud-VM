from .base import ChatProvider


class LocalProvider(ChatProvider):
    name = "local"
