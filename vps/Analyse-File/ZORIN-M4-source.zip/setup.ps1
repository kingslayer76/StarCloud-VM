param(
    [string]$Python = 'python',
    [switch]$DownloadModels,
    [switch]$DownloadBrain,
    [switch]$SkipTests
)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
if (-not (Test-Path -LiteralPath '.venv\Scripts\python.exe')) {
    & $Python -c "import sys; assert (3,11) <= sys.version_info[:2] < (3,14), 'Use Python 3.11, 3.12 or 3.13'"
    if ($LASTEXITCODE -ne 0) { throw 'Install Python 3.12 from python.org, or pass -Python with its full path.' }
    & $Python -m venv .venv
    if ($LASTEXITCODE -ne 0) { throw 'Could not create .venv' }
}
& '.\.venv\Scripts\python.exe' -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed. Check network and retry setup.' }
if (-not (Test-Path -LiteralPath '.env')) { Copy-Item -LiteralPath '.env.example' -Destination '.env' }
if ($DownloadModels) {
    & '.\.venv\Scripts\python.exe' scripts\download_models.py
    if ($LASTEXITCODE -ne 0) { throw 'Model download failed; rerun setup.ps1 -DownloadModels to resume completed files.' }
    & '.\.venv\Scripts\python.exe' scripts\download_voice_upgrade.py
    if ($LASTEXITCODE -ne 0) { throw 'Whisper Turbo download failed; rerun setup.ps1 -DownloadModels.' }
    & '.\.venv\Scripts\python.exe' scripts\download_whisper_vulkan.py
    if ($LASTEXITCODE -ne 0) { Write-Warning 'Vulkan download failed. The CPU speech fallback remains installed.' }
}
if ($DownloadBrain) {
    & '.\.venv\Scripts\python.exe' scripts\download_brain.py
    if ($LASTEXITCODE -ne 0) { throw 'Local brain download failed; rerun with -DownloadBrain.' }
}
if (-not $SkipTests) {
    & '.\.venv\Scripts\python.exe' -m pytest -q
    if ($LASTEXITCODE -ne 0) { throw 'Tests failed. See output above.' }
}
& '.\.venv\Scripts\python.exe' main.py --doctor
Write-Host 'Start ZORIN-M4 with .\run.bat. Use .\run.bat --text for keyboard-only mode.'
