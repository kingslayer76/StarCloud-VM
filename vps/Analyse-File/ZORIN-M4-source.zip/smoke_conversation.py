"""Exercise actual model replies with short conversation history; no desktop input."""
import argparse
import asyncio
import json
from pathlib import Path
import sys
import time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.config import ROOT, load_config
from core.orchestrator import Assistant
from core.instance import InstanceLease


class NoHands:
    async def observe(self): return {"desktop": "read-only conversation test"}
    async def execute(self, *args): raise RuntimeError("Desktop actions are disabled in this diagnostic")
    async def close(self): pass


async def run(path=None):
    config = load_config(path) if path else load_config()
    config.voice.enabled = False
    config.memory.enabled = False
    lease = InstanceLease()
    assistant = Assistant(config, NoHands())
    results = []
    try:
        await assistant.start(voice=False, proactive=False)
        for prompt in ["Hello Zorin", "Bro, aaj ka din bahut tiring tha.", "I'm tired. Just listen; I don't need a solution right now."]:
            start = time.monotonic()
            await assistant.submit(prompt, source="voice")
            if assistant.task:
                await assistant.task
            reply = assistant.last_response
            valid = bool(reply) and assistant.state.outcome == "success" and not any(
                phrase in reply.casefold() for phrase in ["let me know if you need help", "how can i assist", "provider isn't available"])
            if assistant.persona.uses_hinglish(prompt):
                import re
                valid = valid and bool(re.search(r"[\u0900-\u097f]", reply)) and not any(word in reply for word in ["धैर्य", "प्रतीक्षा", "तत्पर", "आदेश"])
            result = {"prompt": prompt, "reply": reply, "basic_check_passed": valid,
                      "seconds": round(time.monotonic()-start, 2)}
            results.append(result)
            print(json.dumps(result, ensure_ascii=False), flush=True)
        (ROOT / "data/conversation-smoke.json").write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")
        return int(not all(item["basic_check_passed"] for item in results))
    finally:
        await assistant.close()
        lease.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config")
    args = parser.parse_args()
    raise SystemExit(asyncio.run(run(args.config)))
