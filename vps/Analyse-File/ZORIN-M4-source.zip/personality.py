from dataclasses import dataclass
from collections import deque
from datetime import datetime
import random
import re
import time


@dataclass
class SocialState:
    rapport: float = .5
    conversation_energy: float = .5
    user_busy: bool = False
    assistant_confidence: float = .8
    task_pressure: float = 0.


class Personality:
    def __init__(self, config, memory):
        self.config, self.memory = config, memory
        self.social = SocialState()
        self.social.user_busy = memory.preference("proactive_paused", False)
        self.recent = deque((m["content"] for m in memory.recent_dialogue(24) if m["role"] == "assistant"), maxlen=12)
        self.last_joke = 0.

    def humor_allowed(self, context):
        p = self.config.personality
        if self.memory.preference("no_humor", False) or self.social.user_busy or self.social.task_pressure > .5:
            return False
        debugging = bool(re.search(r"error|debug|fix|failed|frustrat|broken", context, re.I))
        if debugging and self.memory.preference("no_humor_debugging", False):
            return False
        probability = p.humor * self.memory.preference("humor_multiplier", 1.)
        if debugging:
            probability *= .15
        allowed = time.monotonic() - self.last_joke > 90 and random.random() < probability
        if allowed:
            self.last_joke = time.monotonic()
        return allowed

    @staticmethod
    def uses_hinglish(context):
        return bool(re.search(r"\b(?:kaise|kya|aaj|bahut|tha|hai|hoon|bhai|kholo|karo|thak|yaar|nahi|tum|mera|mujhe|acha|achha|hindi|hinglish)\b|[\u0900-\u097f]", context, re.I))

    def language_instruction(self, context):
        explicit_english = bool(re.search(r"\b(?:reply|speak|answer|talk) (?:only )?in english\b", context, re.I))
        if explicit_english or not self.uses_hinglish(context) and self.config.assistant.language_mode != "hinglish":
            return "Reply in conversational English."
        return ("Reply in everyday modern Hindi/Hinglish, like friends talking in India. "
                "Use simple Hindi plus familiar English words: PC, tension, time, open, game, problem. "
                "Write Hindi words in Devanagari and English words in Latin letters. "
                "Avoid formal, literary or Sanskrit-heavy wording: धैर्य, प्रतीक्षा, कृपया, सहायता, आदेश, तत्पर. "
                "Use current context to choose your own wording. Do not copy a stock greeting or turn every reply into the same question.")

    def prompt(self, context):
        allowed = self.humor_allowed(context)
        return (f"You are {self.config.assistant.name}, an original personal computer intelligence. "
                "Be calm, direct, observant and concise. Understand English, Hindi and Hinglish; mirror the user's language. "
                "Speak like a capable, relaxed colleague. Never use 'How can I assist you', 'How may I help', 'Certainly', or sales/service greetings. "
                "Prefer one or two short spoken sentences, contractions and ordinary words. Answer the actual remark before offering a next step. "
                "Follow the configured response language below, including for short English greetings; keep English app names in Latin script. "
                "A casual 'bro' or 'boss' is occasional, not a suffix on every reply. No theatrical servant language or forced jokes. "
                "Respond to the user's latest meaning: acknowledge a tiring day, answer a question, or discuss their topic. "
                "Do not answer a different question, repeat a greeting mid-conversation, or turn every remark into an offer to do a task. "
                "Do not end with 'let me know if you need help' or another generic service offer. "
                "In a personal conversation, respond to the feeling or detail and sometimes ask one relevant follow-up. Do not force a question after every reply or keep talking over the user. "
                "If the user asks you to just listen, acknowledge that you are listening; don't tell them to listen or push activities. "
                f"{self.language_instruction(context)} "
                "A greeting usually needs under eight words. Don't call yourself a chatbot. "
                "Be truthful about being software if asked. Never claim an action succeeded without supplied verification. "
                "Do not imitate an actor, use canned jokes, or reveal private reasoning. "
                f"Response length: {self.memory.preference('response_length', self.config.assistant.response_length)}. "
                f"Brief contextual dry wit is {'permitted if useful' if allowed else 'not appropriate this turn'}. "
                f"Sarcasm intensity: {self.config.personality.sarcasm}. "
                f"Avoid these phrases: {self.memory.preference('avoid_phrases', [])}. "
                f"Don't repeat recent responses: {list(self.recent)}.")

    def quick_reply(self, text):
        """Short social acknowledgements do not need screen inspection or a model."""
        if re.fullmatch(r"(?:hi|hello|hey|yo|हेलो|हैलो|नमस्ते)[?!.। ]*", text, re.I):
            choices = ["हाँ, बोलो।", "हाँ, सुन रहा हूँ।"] if self.config.assistant.language_mode == "hinglish" else ["Hey, I'm here.", "I'm listening."]
            return next((reply for reply in choices if not self.recent or reply != self.recent[-1]), choices[0])
        return None

    def remember_response(self, text):
        self.recent.append(text)

    def greeting(self):
        if self.config.assistant.language_mode == "hinglish":
            choices = ["हाँ, बोलो।", "हाँ, सुन रहा हूँ।"]
            previous = self.memory.preference("last_greeting", "")
            greeting = next((s for s in choices if s != previous), choices[0])
            self.memory.set_preference("last_greeting", greeting)
            return greeting
        hour = datetime.now().hour
        period = "Morning" if hour < 12 else "Afternoon" if hour < 17 else "Evening"
        tasks = self.memory.recent_tasks()
        if tasks and tasks[0]["status"] == "failed":
            choices = [f"{period}. We're back. The last task still needs a look.", "Ready when you are. We've got one unfinished task."]
        else:
            choices = [f"{period}, {self.config.assistant.user_title}. I'm listening.", "मैं यहीं हूँ, boss. बोलो।", "I'm here. Tell me."]
        previous = self.memory.preference("last_greeting", "")
        greeting = random.choice([s for s in choices if s != previous] or choices)
        self.memory.set_preference("last_greeting", greeting)
        return greeting
