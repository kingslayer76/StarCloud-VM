"""Generate synthetic bilingual samples; optionally play them. No microphone use."""
import argparse
import asyncio
import json
from pathlib import Path
import sys
import time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.config import ROOT, load_config
from core.state_machine import Cancellation
from voice.tts import EdgeTTSProvider, KokoroProvider
from voice.playback import Playback


async def run(play=False):
    import soundfile as sf
    config = load_config().voice
    edge = EdgeTTSProvider(config)
    local = KokoroProvider(config)
    playback = Playback(config.output_device)
    samples = [
        ("hindi", "हाँ, मैं सुन रहा हूँ। आराम से बोलो, जल्दी नहीं है। आज का दिन कैसा गया?"),
        ("english", "I'm here. Take your time. We can pick up where we left off."),
        ("hinglish", "ठीक है, boss. पहले Chrome खोलते हैं, फिर YouTube पर गाना ढूँढेंगे।"),
    ]
    results = []
    for name, text in samples:
        started = time.monotonic()
        audio, rate = await edge.synthesize_async(text)
        elapsed = time.monotonic() - started
        path = ROOT / f"data/tts-{name}.wav"
        sf.write(path, audio, rate)
        results.append({"sample": name, "provider": "edge", "generation_seconds": round(elapsed, 2),
                        "audio_seconds": round(len(audio)/rate, 2), "path": str(path)})
        if play:
            await playback.play(audio, rate, Cancellation())
    started = time.monotonic()
    audio, rate = await asyncio.to_thread(local.synthesize, samples[0][1])
    sf.write(ROOT / "data/tts-hindi-local.wav", audio, rate)
    results.append({"sample": "hindi", "provider": "kokoro", "generation_seconds": round(time.monotonic()-started, 2),
                    "audio_seconds": round(len(audio)/rate, 2)})
    (ROOT / "data/tts-smoke.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
    print(json.dumps(results, indent=2), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--play", action="store_true")
    asyncio.run(run(parser.parse_args().play))
