"""Read-only real-model checks: validate plans without executing their actions."""
import asyncio
import json
from pathlib import Path
import sys
import time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.config import load_config
from core.events import EventBus
from brain.local_runtime import LocalBrainRuntime
from brain.router import ProviderRouter
from brain.planner import Planner
from persona.personality import Personality
from memory.manager import Memory


async def run():
    config = load_config()
    bus = EventBus()
    events = bus.subscribe()
    runtime = LocalBrainRuntime(config.brain, bus)
    router = ProviderRouter(config.brain, bus)
    memory = Memory(":memory:", enabled=False)
    planner = Planner(router, Personality(config, memory), memory, config)
    results = []
    try:
        await runtime.start()
        for text in ["Hi", "Open Notepad and click Settings", "Steam kholo aur Forza Horizon 5 chalao"]:
            start = time.monotonic()
            try:
                plan = await planner.plan(text, [{"role": "user", "content": text}], {}, [])
                result = {"request": text, "valid": True, "plan": plan.model_dump(), "seconds": round(time.monotonic()-start, 2)}
            except Exception as error:
                result = {"request": text, "valid": False, "error": str(error), "reason": router.last_failure}
            results.append(result)
            print(json.dumps(result, ensure_ascii=False), flush=True)
            while not events.empty():
                event = events.get_nowait()
                if event.type == "provider":
                    print(event.data, flush=True)
            router.cooldown.clear()
        Path("data/planner-smoke.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
        return int(not all(r["valid"] for r in results))
    finally:
        await router.close()
        await runtime.close()
        memory.close()


if __name__ == "__main__":
    raise SystemExit(asyncio.run(run()))
