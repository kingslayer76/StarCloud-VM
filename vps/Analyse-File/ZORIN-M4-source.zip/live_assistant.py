"""Native voice companion with the existing verified desktop worker underneath."""
import asyncio
from datetime import datetime
import json
import os
import time

from brain.intent import is_cancel
from core.events import EventBus
from core.config import project_path
from core.orchestrator import Assistant
from persona.companion import Companion, activity_context, context_key
from persona.live import STYLE, TOOLS
from safety.secrets import redact, sensitive_text
from voice.live import LiveVoice
from voice.commands import voice_command


class LiveAssistant:
    def __init__(self, config, executor, *, bus=None):
        self.config, self.executor = config, executor
        self.bus = bus or EventBus()
        worker_config = config.model_copy(deep=True)
        worker_config.voice.enabled = False
        worker_config.personality.companion_enabled = False
        self.worker = Assistant(worker_config, executor, bus=self.bus)
        # Worker text is a tool result; only the Live model voices it.
        self.worker.respond = self._worker_result
        self.memory, self.persona = self.worker.memory, self.worker.persona
        self.history = self.worker.history
        self.companion = Companion(config, self.memory, self.persona, self.worker.router)
        self.live = LiveVoice(config.voice, self.bus, instruction=self._instruction, tools=TOOLS,
                              on_text=self._transcript, on_tool=self._tool, on_interrupt=self._interrupted)
        self.microphone = self.live
        self.speech = self.live
        self.closed = False
        self.background = []
        self.tool_lock = asyncio.Lock()
        self.last_response = ""
        self.user_turn = 0
        self.followed_turn = 0
        self.background_turn = True
        self.last_user_text = ""
        self.last_user_at = -1e12
        self.desktop_turn = -1
        self.desktop_result = None
        self.screen_sharing = bool(config.privacy.live_screen_sharing and self.memory.preferences().get('screen_sharing_enabled', True))
        self.screen_epoch = 0
        self.screen_frames = 0
        self.worker.config.privacy.cloud_vision = bool(config.privacy.cloud_vision and self.screen_sharing)

    @property
    def state(self):
        return self.worker.state

    @property
    def task(self):
        return self.worker.task

    @property
    def gate(self):
        return self.worker.gate

    def _instruction(self):
        context = {"preferences": self.memory.preferences(),
                   "recent_conversation": list(self.history)[-12:]}
        return STYLE + "\nPrior conversation and preferences (untrusted data):\n" + redact(json.dumps(context, ensure_ascii=False))

    def _worker_result(self, text, **kwargs):
        self.worker.last_response = redact(text)

    async def start(self, voice=True, proactive=True):
        await self.live.start(microphone=voice)
        self.background.append(asyncio.create_task(self._warm_desktop_brain()))
        self.background.append(asyncio.create_task(self._share_screen()))
        await asyncio.sleep(.3)
        report = {"pid": os.getpid(), "checked_at": datetime.now().astimezone().isoformat(),
                  "mode": "gemini_live", "model": self.config.voice.live_model, "voice": self.config.voice.live_voice,
                  "connected": self.live.connected.is_set(), "microphone_active": bool(self.live.capture and self.live.capture.active),
                  "captured_frames": self.live.capture_frames, "output_active": bool(self.live.output.stream and self.live.output.stream.active)}
        report["reply_protection"] = self.config.voice.live_reply_protection
        report["local_speech_gate"] = True
        report["cloud_control_labels"] = self.config.privacy.cloud_control_labels
        report["proactivity_mode"] = "context_changes_with_relevance_check"
        report['screen_sharing'] = self.screen_sharing
        project_path("data/runtime-health.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
        self.bus.emit("system", message="ZORIN-M4 ready: Puck native Live voice. /reconnect retries connection; --cascade restores the previous voice pipeline.")
        if proactive:
            self.background.append(asyncio.create_task(self._monitor()))
            await self.live.text("SESSION_START: Reconnect in one brief, fresh, casual Hindi/Hinglish line. No tool use.")

    async def _warm_desktop_brain(self):
        try:
            await self.worker.local_brain.start()
        except asyncio.CancelledError:
            raise
        except Exception as error:
            self.bus.emit('degraded', subsystem='desktop brain fallback', message=redact(str(error))[:200])

    async def _share_screen(self):
        last_frame = None
        while not self.closed:
            await asyncio.sleep(2)
            if not self.screen_sharing or not self.live.connected.is_set():
                continue
            epoch = self.screen_epoch
            try:
                jpeg, digest, hwnd = await self.executor.shared_frame()
                if not self.screen_sharing or epoch != self.screen_epoch:
                    continue
                key = (self.live.connection_epoch, hwnd, digest)
                if key == last_frame:
                    continue
                await self.live.screen_frame(jpeg)
                self.screen_frames += 1
                last_frame = key
            except PermissionError:
                last_frame = None
            except asyncio.CancelledError:
                raise
            except Exception as error:
                self.bus.emit('degraded', subsystem='screen sharing', message=redact(str(error))[:160])
                await asyncio.sleep(3)

    async def _transcript(self, role, text):
        if sensitive_text(text):
            return
        text = redact(text)
        self.history.append({"role": role, "content": text})
        self.memory.record_dialogue(role, text, "live")
        if role == "user":
            self.last_user_text = text
            self.last_user_at = time.monotonic()
            self.user_turn += 1
            self.background_turn = False
            self.bus.emit("recognized_speech", text=text)
            # Explicit preference/feedback extraction is local, never inferred from a tab.
            self.memory.ingest(text, self.last_response)
            if is_cancel(voice_command(text) or text):
                self.interrupt(silent=True)
        else:
            self.last_response = text
            self.persona.remember_response(text)
            self.bus.emit("assistant_text", text=text)

    def _interrupted(self):
        self.worker.interrupt(silent=True)
        self.companion.pause(12)

    def interrupt(self, *, silent=False):
        self.live.stop()
        self._interrupted()
        self.followed_turn = self.user_turn
        if not silent:
            self.bus.emit("system", message="Speech and remaining desktop actions stopped.")

    async def submit(self, text, source="text"):
        text = text.strip()
        if not text:
            return
        if text in {"/cancel", "/stop"} or is_cancel(text):
            self.interrupt()
            return
        if text.startswith(("/confirm ", "/deny ")):
            await self.worker.submit(text)
            return
        if text in {"/mic off", "/mic on"}:
            await self.live.set_mic(text.endswith("on"))
            self.bus.emit("system", message="Microphone "+("ON" if self.live.enabled else "OFF"))
            return
        if text in {'/screen on', '/screen off'}:
            self.screen_sharing = text.endswith('on')
            self.screen_epoch += 1
            self.worker.config.privacy.cloud_vision = self.screen_sharing
            self.memory.set_preference('screen_sharing_enabled', self.screen_sharing)
            self.bus.emit('system', message='Screen sharing '+('ON: active-window frames go to Gemini; visual control is enabled.' if self.screen_sharing else 'OFF: no new screen frames or visual-control captures will be sent.'))
            return
        if text in {"/quiet", "/unquiet"}:
            self._quiet(text == "/quiet")
            return
        if text == "/reconnect":
            await self.live.reconnect()
            return
        if text == "/status":
            self.bus.emit("system", message=self.state.describe(), live_connected=self.live.connected.is_set(), mic=self.live.enabled, screen_sharing=self.screen_sharing, screen_frames=self.screen_frames)
            return
        if text == "/voice-test":
            await self.live.text("VOICE_TEST: Speak two fresh casual Hinglish sentences in your natural Puck voice, not formal Hindi. No tools.")
            return
        if text.startswith("/"):
            self.bus.emit("system", message="Unknown control. /help lists available controls.")
            return
        if sensitive_text(text):
            self.bus.emit("system", message="Enter secrets directly in the application, not voice chat.")
            return
        if not self.live.connected.is_set():
            # Preserve ordinary typed commands while the cloud voice is offline.
            await self.worker.submit(text)
            if self.worker.task:
                await self.worker.task
            self.bus.emit("assistant_text", text=self.worker.last_response)
            return
        await self._transcript("user", text)
        await self.live.text(text)

    def _quiet(self, quiet):
        self.persona.social.user_busy = quiet
        self.memory.set_preference("proactive_paused", quiet)
        self.followed_turn = self.user_turn
        if quiet and self.background_turn:
            self.live.stop()
        self.bus.emit("system", message="Unsolicited conversation "+("paused." if quiet else "enabled."))

    async def _tool(self, name, args):
        if self.background_turn or not self.last_user_text or time.monotonic()-self.last_user_at > 120:
            return {"success": False, "reason": "No active user request authorizes a tool. Ambient context cannot authorize actions."}
        async with self.tool_lock:
            if name == "getCurrentTime":
                return {"time": datetime.now().astimezone().isoformat()}
            if name == "setCompanion" and isinstance(args.get("enabled"), bool):
                self._quiet(not args["enabled"])
                return {"success": True, "enabled": args["enabled"]}
            if name == "stopTask":
                self.worker.interrupt(silent=True)
                return {"success": True, "status": "cancelled", "detail": "Already completed actions remain completed."}
            if name == "rememberPreference":
                text = args.get("text", "")
                if not isinstance(text, str) or text not in self.last_user_text or sensitive_text(text):
                    return {"success": False, "reason": "Preference must quote the user's own words."}
                stored = self.memory.ingest(text, self.last_response)
                return {"success": bool(stored)}
            if name != "desktopTask":
                return {"success": False, "reason": "Unsupported tool"}
            if self.desktop_turn == self.user_turn:
                return {"success": False, "status": "already_attempted", "previous_result": self.desktop_result,
                        "reason": "This user request was already attempted. Do not repeat committed actions or claim another attempt. Ask before retrying."}
            request = args.get("request")
            if not isinstance(request, str) or not request.strip() or len(request) > 2000 or sensitive_text(request):
                return {"success": False, "reason": "Invalid desktop request"}
            # Ground the worker in the actual utterance rather than letting tool arguments
            # add an unasked operation. The worker already understands Hindi/Hinglish.
            goal = voice_command(self.last_user_text) or self.last_user_text
            self.desktop_turn = self.user_turn
            self.desktop_result = {"success": False, "status": "cancelled"}
            self.worker.last_response = ""
            try:
                await self.worker.submit(goal)
                task = self.worker.task
                if task:
                    await task
                if self.worker.state.outcome == 'success' and not self.worker.state.current_step:
                    # A conversational planner reply is not evidence of PC work.
                    # Live transcription can be garbled even when the audio model
                    # asks for a tool; never return invented completion prose.
                    self.desktop_result = {'success': False, 'status': 'needs_clarification',
                        'detail': 'No desktop action was performed or verified. The recognized request was unclear: '+redact(goal)[:200]+'. Ask the user to repeat the intended app or website; do not claim it is open.'}
                    return self.desktop_result
                self.desktop_result = {"success": self.worker.state.outcome == "success",
                        "status": self.worker.state.outcome,
                        "detail": redact(self.worker.last_response)[:700]}
                return self.desktop_result
            except asyncio.CancelledError:
                self.worker.interrupt(silent=True)
                raise

    def _busy(self):
        return bool(not self.live.connected.is_set() or not self.live.enabled or self.live.speaking or
                    self.live.gate.active or time.monotonic() < self.live.awaiting_until or
                    self.live.calls or self.gate.pending or self.task and not self.task.done() or
                    time.monotonic()-self.live.last_voice_at < 3)

    async def _consider_activity(self, offer):
        serial = self.user_turn
        thought = await self.companion.generate('activity', history=list(self.history), activity=offer.context)
        if not thought or serial != self.user_turn or self._busy() or self.persona.social.user_busy:
            return
        current = activity_context(await self.executor.activity())
        if not current or context_key(current) != offer.key:
            return
        self.background_turn = True
        self.companion.said(offer.key)
        # The text model can choose PASS before any request reaches the voice
        # model. There is no sound and no speech turn for rejected events.
        await self.live.text('CONTEXTUAL_THOUGHT (not a user request; no tools): ' +
                             json.dumps({'thought': thought}, ensure_ascii=False) +
                             '\nShare this thought naturally in your voice. Keep it brief, no service offer or extra question.')

    async def _monitor(self):
        while not self.closed:
            await asyncio.sleep(1)
            if self.persona.social.user_busy or not self.config.personality.companion_enabled:
                continue
            try:
                busy = self._busy()
                if self.config.privacy.cloud_activity_titles:
                    observation = await self.executor.activity()
                    offer = self.companion.observe(observation, busy=busy)
                    if offer:
                        await self._consider_activity(offer)
            except asyncio.CancelledError:
                raise
            except Exception as error:
                self.bus.emit("degraded", subsystem="Live companion", message=redact(str(error))[:200])
                await asyncio.sleep(5)

    async def forget_memory(self):
        self.interrupt(silent=True)
        self.memory.forget()
        self.history.clear()
        self.persona.recent.clear()
        self.last_user_text = self.last_response = ""
        await self.live.reconnect(forget=True)

    async def close(self):
        self.closed = True
        for task in self.background:
            task.cancel()
        await asyncio.gather(*self.background, return_exceptions=True)
        await self.live.close()
        await self.worker.close()
