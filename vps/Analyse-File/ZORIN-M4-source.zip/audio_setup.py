"""Select microphone/speaker devices and run a local, non-executing voice check."""
import asyncio
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import sounddevice as sd
import yaml
from core.config import ROOT, load_config
from scripts.listen_check import run as listen_check


def choose(kind):
    devices = sd.query_devices()
    apis = sd.query_hostapis()
    print(f"\nAvailable {kind} devices (the same device can appear under several audio drivers):")
    for index, device in enumerate(devices):
        if device[f"max_{kind}_channels"]:
            print(f"  {index}: {device['name']} [{apis[device['hostapi']]['name']}]")
    while True:
        value = input(f"{kind.title()} number, or Enter for Windows default: ").strip()
        if not value:
            return None
        try:
            index = int(value)
            if index < 0 or index >= len(devices) or not devices[index][f"max_{kind}_channels"]:
                raise ValueError
            device = devices[index]
            selector = f"{device['name']}, {apis[device['hostapi']]['name']}"
            sd.query_devices(selector, kind)
            return selector
        except (ValueError, sd.PortAudioError):
            print("Choose a listed device with the right input/output direction.")


def main():
    print("ZORIN-M4 audio setup. Connect your headset/microphone before starting.")
    print("Windows default follows the devices selected in Windows Sound settings.")
    microphone = choose("input")
    speaker = choose("output")
    configuration = ROOT / "config.yaml"
    data = yaml.safe_load(configuration.read_text(encoding="utf-8"))
    data["voice"]["input_device"] = microphone
    data["voice"]["output_device"] = speaker
    # Validate the selected formats before changing the saved configuration.
    sd.check_input_settings(device=microphone, channels=1, dtype="int16", samplerate=16000)
    sd.check_output_settings(device=speaker, channels=1, samplerate=24000)
    configuration.write_text(yaml.safe_dump(data, sort_keys=False, allow_unicode=True), encoding="utf-8")
    load_config()
    print("\nSaved. After the spoken announcement, say 'Hello Zorin' and 'Chrome kholo'.")
    print("This test only transcribes; it does not open apps or save audio.")
    result = asyncio.run(listen_check(30))
    if result:
        print("\nNo speech was transcribed. Check the physical mute switch, microphone connection, and Windows microphone permissions.")
        print("If peak level stays near zero, try the microphone you are actually speaking into.")
    else:
        print("\nVoice input passed. Start RUN-ZORIN-VOICE.bat to use the assistant.")
    return result


if __name__ == "__main__":
    raise SystemExit(main())
