from collections import deque
import math


class Segmenter:
    """16 kHz PCM16, 30 ms frames. Keeps pre-roll and bounds utterance memory."""
    def __init__(self, config, classifier=None):
        if classifier is None:
            import webrtcvad
            import numpy as np
            vad = webrtcvad.Vad(config.vad_aggressiveness)
            def classifier(frame, rate):
                samples = np.frombuffer(frame, dtype=np.int16).astype(np.float32)
                return float(np.sqrt(np.mean(samples*samples))) >= config.energy_threshold and vad.is_speech(frame, rate)
        self.classifier = classifier
        self.config = config
        self.preroll = deque(maxlen=6)
        self.frames = []
        self.speech_ms = 0
        self.silence_ms = 0
        self.started = False
        self.barged = False
        self.attack = deque(maxlen=max(1, math.ceil(config.barge_in_ms / 30)))

    def feed(self, frame):
        if len(frame) != 960:
            raise ValueError("VAD needs exactly 30 ms of mono 16 kHz PCM16")
        voiced = self.classifier(frame, 16000)
        self.attack.append(bool(voiced))
        barge = False
        if not self.started:
            self.preroll.append(frame)
            if not voiced:
                return None, False
            self.started = True
            self.frames = list(self.preroll)
            self.preroll.clear()
        else:
            self.frames.append(frame)
        self.speech_ms += 30 if voiced else 0
        self.silence_ms = 0 if voiced else self.silence_ms + 30
        if not self.barged and len(self.attack) == self.attack.maxlen and sum(self.attack) >= math.ceil(.8 * self.attack.maxlen):
            self.barged = True
            barge = True
        if self.silence_ms >= self.config.endpoint_ms or len(self.frames)*30 >= self.config.max_segment_seconds*1000:
            active_ms = max(30, len(self.frames)*30 - self.silence_ms)
            segment = b"".join(self.frames) if self.speech_ms >= self.config.min_speech_ms and self.speech_ms / active_ms >= .4 else None
            self.frames, self.speech_ms, self.silence_ms, self.started, self.barged = [], 0, 0, False, False
            self.attack.clear()
            return segment, barge
        return None, barge
