import asyncio
import base64
from dataclasses import asdict
import hmac
import json
import os
from pydantic import Field
from typing import Literal
from core.config import Strict
from voice.vad import Segmenter


class Incoming(Strict):
    type: Literal["text_command", "interrupt", "cancel", "confirmation", "microphone_audio"]
    text: str = Field(default="", max_length=8000)
    id: str = Field(default="", max_length=32)
    approved: bool = False
    audio: str = Field(default="", max_length=1280)


async def serve(assistant):
    from websockets.asyncio.server import serve as websocket_serve
    cfg = assistant.config.services
    token = os.getenv(cfg.token_env, "")
    if len(token) < 24:
        raise ValueError("WebSocket needs a random token of at least 24 characters in .env")

    async def handler(socket):
        events = None
        tasks = []
        try:
            auth = json.loads(await asyncio.wait_for(socket.recv(), 5))
            if not isinstance(auth, dict) or not isinstance(auth.get("token"), str) or not hmac.compare_digest(auth["token"], token):
                await socket.close(1008, "Authentication required")
                return
            events = assistant.bus.subscribe(64)
            segments = asyncio.Queue(maxsize=2)
            vad = Segmenter(assistant.config.voice)
            epoch = 0

            async def sender():
                while True:
                    await socket.send(json.dumps(asdict(await events.get()), ensure_ascii=False))

            async def transcriber():
                while True:
                    segment_epoch, pcm = await segments.get()
                    text = await assistant.stt.transcribe(pcm)
                    if text and segment_epoch == epoch:
                        assistant.bus.emit("recognized_speech", text=text)
                        await assistant.submit(text, source="voice")

            tasks = [asyncio.create_task(sender()), asyncio.create_task(transcriber())]
            await socket.send(json.dumps({"type": "assistant_state", "data": {"phase": assistant.state.phase}}))
            async for message in socket:
                try:
                    incoming = Incoming.model_validate_json(message)
                    if incoming.type == "text_command":
                        epoch += 1
                        await assistant.submit(incoming.text)
                    elif incoming.type in {"interrupt", "cancel"}:
                        epoch += 1
                        assistant.interrupt(silent=incoming.type == "interrupt")
                    elif incoming.type == "confirmation":
                        assistant.gate.resolve(incoming.id, incoming.approved)
                    elif incoming.type == "microphone_audio":
                        frame = base64.b64decode(incoming.audio, validate=True)
                        segment, barge = vad.feed(frame)
                        if barge and assistant.config.voice.barge_in_mode == "speech":
                            epoch += 1
                            if assistant.config.voice.allow_barge_in:
                                assistant.barge_in()
                        if segment:
                            if segments.full():
                                segments.get_nowait()
                            segments.put_nowait((epoch, segment))
                except ValueError:
                    await socket.send(json.dumps({"type": "error", "data": {"message": "Invalid message schema/audio frame"}}))
        except (asyncio.TimeoutError, ValueError):
            await socket.close(1008, "Invalid authentication")
        finally:
            if events:
                assistant.bus.unsubscribe(events)
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)

    # No browser-origin access; future tablet uses a native authenticated client/tunnel.
    async with websocket_serve(handler, cfg.websocket_host, cfg.websocket_port,
                               origins=[None], max_size=16384, max_queue=8, ping_interval=20):
        assistant.bus.emit("system", message=f"Authenticated WebSocket listening on loopback:{cfg.websocket_port}")
        await asyncio.Future()
