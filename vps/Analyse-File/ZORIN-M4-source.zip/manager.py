import json
import re
import time
from memory.database import connect
from safety.secrets import redact, sensitive_text


class Memory:
    def __init__(self, path, enabled=True):
        self.db = connect(path if enabled else ":memory:")

    def remember(self, content, category="preference", explicit=True, source="user", importance=.8):
        if sensitive_text(content):
            return False
        with self.db:
            self.db.execute("INSERT INTO memories(content,category,confidence,source,created_at,importance,explicit) VALUES(?,?,?,?,?,?,?) ON CONFLICT(content) DO UPDATE SET confidence=max(confidence,excluded.confidence),importance=max(importance,excluded.importance)",
                            (content, category, .99 if explicit else .60, source, time.time(), importance, int(explicit)))
        return True

    def set_preference(self, key, value, confidence=.99):
        with self.db:
            self.db.execute("INSERT INTO preferences VALUES(?,?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,confidence=excluded.confidence,updated_at=excluded.updated_at", (key, json.dumps(value), confidence, time.time()))

    def preference(self, key, default=None):
        row = self.db.execute("SELECT value FROM preferences WHERE key=?", (key,)).fetchone()
        return json.loads(row[0]) if row else default

    def preferences(self):
        return {r["key"]: json.loads(r["value"]) for r in self.db.execute("SELECT key,value FROM preferences")}

    def retrieve(self, query, limit=8):
        words = set(re.findall(r"\w{3,}", query.casefold()))
        rows = self.db.execute("SELECT * FROM memories ORDER BY importance DESC,created_at DESC LIMIT 500").fetchall()
        def score(row):
            overlap = len(words & set(re.findall(r"\w{3,}", row["content"].casefold())))
            recency = 1 / (1 + (time.time() - row["created_at"]) / 86400)
            return overlap * 2 + row["importance"] + row["confidence"] + recency * .2
        selected = sorted(rows, key=score, reverse=True)[:limit]
        with self.db:
            self.db.executemany("UPDATE memories SET usage_count=usage_count+1,last_used_at=? WHERE id=?", [(time.time(), r["id"]) for r in selected])
        return [dict(r) for r in selected]

    def ingest(self, text, last_response=""):
        """Explicit local learning; inferred facts never masquerade as user statements."""
        lower = text.casefold()
        if sensitive_text(text):
            return None
        if lower.startswith(("याद रखना", "याद रखो", "याद रख लेना")):
            self.remember(text)
            if "छोटे जवाब" in text and "पसंद नहीं" not in text:
                self.set_preference("response_length", "short")
            return "याद रखूँगा।"
        if "short replies" in lower or "long replies" in lower and any(x in lower for x in ["don't", "hate", "dislike"]):
            self.set_preference("response_length", "short")
            self.remember(text)
            return "Short replies. Got it."
        if any(x in lower for x in ["don't make jokes", "no jokes", "stop joking"]):
            key = "no_humor_debugging" if any(x in lower for x in ["error", "fix", "debug"]) else "no_humor"
            self.set_preference(key, True)
            self.remember(text)
            return "Understood. I'll keep it straight."
        if lower.startswith(("remember that ", "remember ", "i prefer ", "i don't like ", "i hate ")):
            self.remember(text)
            return "Remembered."
        negative = any(x in lower for x in ["stop saying that", "that wasn't funny", "don't say that"])
        positive = any(x in lower for x in ["exactly how i want you to talk", "that was funny", "i like that joke"])
        if negative or positive:
            with self.db:
                self.db.execute("INSERT INTO feedback(response,positive,note,created_at) VALUES(?,?,?,?)", (redact(last_response), int(positive), text, time.time()))
            factor = self.preference("humor_multiplier", 1.)
            self.set_preference("humor_multiplier", min(1.5, factor + .1) if positive else max(0., factor - .3))
            if negative and last_response:
                phrases = self.preference("avoid_phrases", [])
                self.set_preference("avoid_phrases", (phrases + [last_response])[-20:])
            return "Noted."
        return None

    def record_app(self, app, purpose=""):
        with self.db:
            self.db.execute("INSERT INTO app_usage VALUES(?,?,1,?) ON CONFLICT(app,purpose) DO UPDATE SET count=count+1,last_used_at=excluded.last_used_at", (app, purpose, time.time()))

    def learned_app(self, purpose):
        row = self.db.execute("SELECT app,count FROM app_usage WHERE purpose=? ORDER BY count DESC LIMIT 1", (purpose,)).fetchone()
        return row[0] if row and row[1] >= 3 else None

    def app_context(self):
        return [dict(r) for r in self.db.execute("SELECT * FROM app_usage ORDER BY last_used_at DESC LIMIT 8")]

    def recent_tasks(self):
        return [dict(r) for r in self.db.execute("SELECT goal,status,summary FROM task_history ORDER BY id DESC LIMIT 4")]

    def record_dialogue(self, role, content, source="conversation"):
        if role not in {"user", "assistant"} or sensitive_text(content):
            return
        with self.db:
            self.db.execute("INSERT INTO dialogue(role,content,source,created_at) VALUES(?,?,?,?)", (role, redact(content)[:1200], source, time.time()))
            self.db.execute("DELETE FROM dialogue WHERE id NOT IN (SELECT id FROM dialogue ORDER BY id DESC LIMIT 60)")

    def recent_dialogue(self, limit=12):
        rows = self.db.execute("SELECT role,content FROM dialogue ORDER BY id DESC LIMIT ?", (min(60, max(1, limit)),)).fetchall()
        return [dict(row) for row in reversed(rows)]

    def topic_recent(self, key, seconds=600):
        row = self.db.execute("SELECT last_spoken FROM conversation_topics WHERE topic_key=?", (key,)).fetchone()
        return bool(row and time.time()-row[0] < seconds)

    def remember_topic(self, key):
        with self.db:
            self.db.execute("INSERT INTO conversation_topics VALUES(?,?) ON CONFLICT(topic_key) DO UPDATE SET last_spoken=excluded.last_spoken", (key, time.time()))
            self.db.execute("DELETE FROM conversation_topics WHERE last_spoken < ?", (time.time()-86400,))

    def record_action(self, action, success, summary):
        table = "successful_actions" if success else "failed_actions"
        with self.db:
            self.db.execute(f"INSERT INTO {table}(kind,target,summary,created_at) VALUES(?,?,?,?)", (action.kind, redact(action.target), redact(summary), time.time()))

    def reflect(self, goal, actions, success, summary, reusable=False):
        goal = redact(goal)
        with self.db:
            self.db.execute("INSERT INTO task_history(goal,status,summary,created_at) VALUES(?,?,?,?)", (goal, "success" if success else "failed", redact(summary), time.time()))
            if len(actions) > 1 or not success:
                self.db.execute("INSERT INTO episodes(summary,created_at) VALUES(?,?)", (redact(f"{goal}: {summary}"), time.time()))
            # Only app/focus/wait recipes are safe for automatic reuse. Other verified
            # procedures remain in history for contextual replanning, not blind replay.
            if success and reusable and actions:
                recipe = json.dumps([a.model_dump() for a in actions])
                replay_safe = all(a.kind in {"open_app", "focus_window", "wait"} for a in actions)
                preconditions = json.dumps({"desktop": "interactive Windows", "automatic_replay": replay_safe,
                                            "review": "Re-detect every target and verify every result"})
                old = self.db.execute("SELECT recipe,version FROM skills WHERE name=?", (goal.casefold(),)).fetchone()
                version = old[1] + int(old[0] != recipe) if old else 1
                self.db.execute("INSERT INTO skills VALUES(?,?,?,1,?,?) ON CONFLICT(name) DO UPDATE SET recipe=excluded.recipe,version=excluded.version,success_count=success_count+1,last_success=excluded.last_success,preconditions=excluded.preconditions", (goal.casefold(), recipe, version, time.time(), preconditions))

    def recipe(self, goal, replay_only=True):
        row = self.db.execute("SELECT recipe,preconditions FROM skills WHERE name=?", (goal.casefold(),)).fetchone()
        if row and replay_only and row[1].startswith("{") and not json.loads(row[1]).get("automatic_replay"):
            return None
        return json.loads(row[0]) if row else None

    def forget(self):
        with self.db:
            for table in ["memories", "preferences", "user_profile", "episodes", "task_history", "app_usage", "feedback", "skills", "relationships_between_facts", "failed_actions", "successful_actions", "dialogue", "conversation_topics"]:
                self.db.execute(f"DELETE FROM {table}")
        self.db.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        self.db.execute("VACUUM")

    def close(self):
        self.db.close()
