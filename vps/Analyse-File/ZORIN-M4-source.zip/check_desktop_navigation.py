"""Exercise the real controller without opening a microphone or speaking."""
import asyncio
import json
from pathlib import Path
import sys
import time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.config import load_config
from core.instance import InstanceLease
from core.orchestrator import Assistant
from core.events import EventBus
from hands.executor import WindowsExecutor
from safety.secrets import redact


async def main():
    config=load_config()
    config.voice.enabled=False
    config.personality.companion_enabled=False
    config.memory.enabled=False
    bus=EventBus(); events=bus.subscribe()
    executor=WindowsExecutor(config.automation,config.privacy)
    lease=InstanceLease()
    assistant=Assistant(config,executor,bus=bus)
    results=[]
    try:
        for goal in ['Open YouTube on Chrome','click on the fourth video' if '--fourth' in sys.argv else 'click on the first video']:
            start=time.monotonic()
            await assistant.submit(goal)
            if assistant.task:
                await asyncio.wait_for(assistant.task,45)
            result={'request':goal,'outcome':assistant.state.outcome,
                    'seconds':round(time.monotonic()-start,3),'reply':assistant.last_response}
            result['events']=[]
            while not events.empty():
                event=events.get_nowait()
                if event.type in {'current_action','verification','provider','recovery'}:
                    result['events'].append({'type':event.type,**event.data})
            obs=await executor.observe()
            result['foreground']={k:obs.get(k) for k in ['title','process','browser_url']}
            results.append(result)
            print(redact(json.dumps(result,ensure_ascii=False)),flush=True)
            if assistant.state.outcome!='success':
                break
            await asyncio.sleep(1)
    finally:
        await assistant.close();lease.close()
        filename = 'data/desktop-fourth-video-check.json' if '--fourth' in sys.argv else 'data/desktop-navigation-check.json'
        Path(filename).write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
    return int(len(results)!=2 or any(r['outcome']!='success' for r in results))

if __name__=='__main__':
    raise SystemExit(asyncio.run(main()))
