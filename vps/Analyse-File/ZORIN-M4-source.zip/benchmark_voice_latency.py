"""Measure synthetic speech recognition and reply generation; no desktop actions."""
import asyncio
import json
from pathlib import Path
import sys
import time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.config import ROOT, load_config
from core.events import EventBus
from voice.stt import SpeechToText
from voice.tts import GoogleTTSProvider


async def run():
    import numpy as np
    import soundfile as sf
    config = load_config()
    config.voice.local_stt_fallback = False
    stt = SpeechToText(config.voice, EventBus())
    tts = GoogleTTSProvider(config.voice)
    results = []
    try:
        for case, text in [('youtube', 'हेलो ज़ोरिन, YouTube खोलो।'), ('chrome', 'हेलो ज़ोरिन, Chrome खोलो।'),
                           ('stop', 'ज़ोरिन, रुको।'), ('chat', 'आज का दिन थोड़ा heavy था।')]:
            path = ROOT / f'data/recognition-sample-{case}.wav'
            if path.exists():
                audio, rate = sf.read(path, dtype='float32')
            else:
                audio, rate = await asyncio.to_thread(tts.synthesize, text)
                sf.write(path, audio, rate)
            samples = np.interp(np.arange(round(len(audio)*16000/rate))*rate/16000, np.arange(len(audio)), audio)
            pcm = (np.clip(samples, -1, 1)*32767).astype('<i2').tobytes()
            for model in ['whisper-large-v3', 'whisper-large-v3-turbo']:
                config.voice.groq_stt_model = model
                started = time.monotonic()
                transcript = await stt.transcribe(pcm)
                row = {'case': case, 'model': model, 'transcript': transcript, 'seconds': round(time.monotonic()-started, 3)}
                results.append(row)
                print(json.dumps(row, ensure_ascii=False), flush=True)
                (ROOT/'data/cloud-stt-benchmark.json').write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding='utf-8')
    finally:
        await stt.close()


if __name__ == '__main__':
    asyncio.run(run())
