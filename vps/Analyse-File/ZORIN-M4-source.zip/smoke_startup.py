"""Start and stop the full voice runtime, with no desktop actions or audio storage."""
import asyncio
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.config import ROOT, load_config
from core.events import EventBus
from core.instance import InstanceLease
from core.orchestrator import Assistant
from hands.executor import WindowsExecutor


async def run():
    config = load_config()
    config.memory.enabled = False
    lease = InstanceLease()
    bus = EventBus()
    events = bus.subscribe()
    assistant = Assistant(config, WindowsExecutor(config.automation, config.privacy), bus=bus)
    async def listen_only(text, source="text"):
        pass  # This startup diagnostic must never execute a recognized command.
    assistant.submit = listen_only
    try:
        print("Loading microphone, local speech and local reasoning...", flush=True)
        await assistant.start(voice=True, proactive=False)
        assistant.respond("Zorin M four is ready. Voice output is on.")
        await assistant.speech.task
        await asyncio.sleep(.1)
        speaking_started = False
        degraded = []
        while not events.empty():
            event = events.get_nowait()
            if event.type == "speaking_state" and event.data.get("speaking"):
                speaking_started = True
            if event.type == "degraded":
                degraded.append(event.data)
        result = {"microphone_stream_ready": assistant.microphone.ready.is_set(),
                  "whisper_ready": assistant.stt.ready, "local_brain_ready": assistant.local_brain.ready,
                  "speech_started": speaking_started, "final_phase": assistant.state.phase,
                  "degraded": degraded, "audio_saved": False,
                  "voice_backend": assistant.speech.last_backend,
                  "gemini_attempts": assistant.speech.providers["gemini"].last_attempts,
                  "note": "Microphone readiness is not proof of recognized human speech."}
        print(json.dumps(result, indent=2), flush=True)
        (ROOT / "data/startup-smoke.json").write_text(json.dumps(result, indent=2))
        return int(not all([result["microphone_stream_ready"], result["whisper_ready"], result["local_brain_ready"], speaking_started]) or bool(degraded))
    finally:
        await assistant.close()
        lease.close()


if __name__ == "__main__":
    raise SystemExit(asyncio.run(run()))
