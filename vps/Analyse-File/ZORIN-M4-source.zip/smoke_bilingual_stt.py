"""Compare local decoding on synthetic speech. Never execute actions."""
import asyncio
import json
from pathlib import Path
import sys
import time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.config import ROOT, load_config
from core.events import EventBus
from voice.tts import GoogleTTSProvider
from voice.stt import SpeechToText
from voice.commands import voice_command
from brain.intent import IntentRouter, is_cancel
from memory.manager import Memory
from persona.personality import Personality


async def run():
    import numpy as np
    import soundfile as sf
    config = load_config()
    config.voice.whisper_url = "http://127.0.0.1:8180/inference"
    stt = SpeechToText(config.voice, EventBus())
    tts = GoogleTTSProvider(config.voice)
    memory = Memory(":memory:", enabled=False)
    intents = IntentRouter(config.automation, memory)
    results = []
    cases = [("chrome", "हेलो ज़ोरिन, Chrome खोलो।"), ("stop", "ज़ोरिन, रुको।"),
             ("chat", "आज का दिन थोड़ा heavy था।")]
    try:
        await stt.start()
        for case, phrase in cases:
            path = ROOT / f"data/recognition-sample-{case}.wav"
            if path.exists():
                audio, rate = sf.read(path, dtype="float32")
            else:
                audio, rate = await asyncio.to_thread(tts.synthesize, phrase)
                sf.write(path, audio, rate)
            samples = np.interp(np.arange(round(len(audio)*16000/rate))*rate/16000, np.arange(len(audio)), audio)
            pcm = (np.clip(samples, -1, 1)*32767).astype("<i2").tobytes()
            for language in ["en", "auto"]:
                config.voice.whisper_language = language
                started = time.monotonic()
                transcript = await stt.transcribe(pcm)
                command = voice_command(transcript, busy=case=="stop")
                plan = intents.route(command) if command and case=="chrome" else None
                passed = bool(plan and plan.actions and plan.actions[0].target == "Google Chrome") if case=="chrome" else (
                    bool(command and is_cancel(command)) if case=="stop" else Personality.uses_hinglish(transcript))
                result = {"case": case, "input": phrase, "language": language, "transcript": transcript,
                          "command_understood": passed, "seconds": round(time.monotonic()-started, 2)}
                results.append(result)
                (ROOT / "data/bilingual-stt-smoke.json").write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")
                print(json.dumps(result, ensure_ascii=False), flush=True)
        (ROOT / "data/bilingual-stt-smoke.json").write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")
        return int(not all(row["command_understood"] for row in results if row["language"] == "auto"))
    finally:
        await stt.close()
        memory.close()


if __name__ == "__main__":
    raise SystemExit(asyncio.run(run()))
