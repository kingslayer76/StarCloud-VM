import os
import httpx


class ProviderFailure(Exception):
    def __init__(self, provider, reason, cooldown=30):
        super().__init__(f"{provider}: {reason}")
        self.cooldown = cooldown
        self.reason = reason


class ChatProvider:
    name = "compatible"

    def __init__(self, config, timeout=18, transport=None):
        self.config = config
        self.client = httpx.AsyncClient(timeout=timeout, transport=transport)

    @property
    def configured(self):
        return bool(self.config.model and (self.name == "local" or os.getenv(self.config.key_env)))

    async def complete(self, messages, json_mode=True):
        key = os.getenv(self.config.key_env, "")
        headers = {"Authorization": f"Bearer {key}"} if key else {}
        body = {"model": self.config.model, "messages": messages, "max_completion_tokens": 1200}
        if self.name == "groq" and self.config.model in {"openai/gpt-oss-120b", "openai/gpt-oss-20b"} and not json_mode:
            body["reasoning_effort"] = "low"
            body["include_reasoning"] = False
            body["temperature"] = .7
        if self.name == "local":
            body["chat_template_kwargs"] = {"enable_thinking": False}
            body["temperature"] = .65
            if not json_mode:
                body["max_completion_tokens"] = 180
        if json_mode:
            body["response_format"] = {"type": "json_object"}
            if self.name == "local":
                from brain.schemas import generation_schema
                body["response_format"] = {"type": "json_schema", "json_schema": {
                    "name": "zorin_plan", "strict": True, "schema": generation_schema()}}
        try:
            response = await self.client.post(self.config.base_url.rstrip("/") + "/chat/completions", headers=headers, json=body,
                                              timeout=90 if self.name == "local" else self.client.timeout)
            if response.status_code in (401, 403):
                raise ProviderFailure(self.name, "credentials rejected", 300)
            if response.status_code == 429:
                raise ProviderFailure(self.name, "quota/rate limit", 60)
            if response.status_code >= 500:
                raise ProviderFailure(self.name, "provider outage", 30)
            if response.status_code >= 400:
                raise ProviderFailure(self.name, f"request rejected ({response.status_code}); check model/config", 60)
            content = response.json()["choices"][0]["message"]["content"]
            if not isinstance(content, str) or not content.strip():
                raise ValueError("empty response")
            return content
        except httpx.TimeoutException as error:
            raise ProviderFailure(self.name, "timeout", 20) from error
        except httpx.RequestError as error:
            raise ProviderFailure(self.name, "connection unavailable", 15) from error
        except (KeyError, IndexError, ValueError) as error:
            raise ProviderFailure(self.name, "invalid response", 15) from error

    async def close(self):
        await self.client.aclose()
