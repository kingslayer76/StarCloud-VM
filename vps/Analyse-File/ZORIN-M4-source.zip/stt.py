import asyncio
import io
import os
import subprocess
import wave
import time
from urllib.parse import urlparse
import httpx
from core.config import project_path
from core.child_process import spawn_managed


def wav_bytes(pcm):
    buffer = io.BytesIO()
    with wave.open(buffer, "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(16000)
        wav.writeframes(pcm)
    return buffer.getvalue()


class SpeechToText:
    def __init__(self, config, bus, transport=None):
        self.config, self.bus = config, bus
        self.client = httpx.AsyncClient(timeout=40, transport=transport)
        self.process = None
        self.ready = False
        self.cooldowns = {}
        self.last_result = {}

    async def start(self):
        if self.config.stt_provider != "local_whisper" and not self.config.local_stt_fallback:
            return
        parsed = urlparse(self.config.whisper_url)
        if parsed.hostname not in {"127.0.0.1", "localhost", "::1"}:
            raise ValueError("Local Whisper must use a loopback endpoint")
        origin = f"{parsed.scheme}://{parsed.netloc}"
        try:
            response = await self.client.get(origin, timeout=1)
            if response.status_code < 500:
                self.ready = True
                return
        except httpx.HTTPError:
            pass
        executable, model = project_path(self.config.whisper_executable), project_path(self.config.whisper_model)
        cpu_executable = project_path("vendor/whisper/whisper-server.exe")
        if not model.exists() or not executable.exists() and not cpu_executable.exists():
            self.bus.emit("degraded", subsystem="STT", message="Local Whisper files missing. Run setup.ps1 -DownloadModels.")
            return
        candidates = list(dict.fromkeys([executable, cpu_executable]))
        for candidate in candidates:
            if not candidate.exists():
                continue
            try:
                await self._launch(candidate, model, parsed)
                return
            except RuntimeError:
                if self.process and self.process.poll() is None:
                    self.process.terminate()
                    await asyncio.to_thread(self.process.wait, 3)
                self.bus.emit("degraded", subsystem="STT", message="Local speech backend failed; trying CPU fallback")
        raise RuntimeError("No local Whisper backend became ready")

    async def _launch(self, executable, model, parsed):
        origin = f"{parsed.scheme}://{parsed.netloc}"
        self.process = spawn_managed([str(executable), "-m", str(model), "--host", parsed.hostname,
                                         "--port", str(parsed.port or 8178), "-l", self.config.whisper_language,
                                         "-t", str(self.config.whisper_threads), "-bs", str(self.config.whisper_beam_size),
                                         "-bo", "1", "--inference-path", parsed.path],
                                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        for _ in range(100):
            if self.process.poll() is not None:
                raise RuntimeError("Whisper server exited during startup")
            try:
                if (await self.client.get(origin, timeout=.5)).status_code < 500:
                    self.bus.emit("system", message="Local Whisper ready")
                    self.ready = True
                    return
            except httpx.HTTPError:
                pass
            await asyncio.sleep(.3)
        raise RuntimeError("Whisper did not become ready within 30 seconds")

    async def transcribe(self, pcm):
        blob = wav_bytes(pcm)
        providers = [self.config.stt_provider]
        if self.config.stt_provider == "local_whisper" and self.config.cloud_stt_fallback:
            providers.append("groq")
        if self.config.stt_provider == "groq" and self.config.local_stt_fallback:
            providers.append("local_whisper")
        started = time.monotonic()
        for provider in providers:
            if self.cooldowns.get(provider, 0) > time.monotonic():
                continue
            try:
                if provider == "local_whisper":
                    response = await self.client.post(self.config.whisper_url,
                        files={"file": ("speech.wav", blob, "audio/wav")},
                        data={"response_format": "json", "language": self.config.whisper_language,
                              "temperature": "0", "temperature_inc": "0", "beam_size": str(self.config.whisper_beam_size),
                              "best_of": "1", "prompt": self.config.transcription_prompt})
                else:
                    key = os.getenv("GROQ_API_KEY")
                    if not key:
                        continue
                    data = {"model": self.config.groq_stt_model, "response_format": "verbose_json",
                            "temperature": "0", "prompt": self.config.transcription_prompt}
                    if self.config.whisper_language != "auto":
                        data["language"] = self.config.whisper_language
                    response = await self.client.post("https://api.groq.com/openai/v1/audio/transcriptions",
                        headers={"Authorization": f"Bearer {key}"}, files={"file": ("speech.wav", blob, "audio/wav")},
                        data=data, timeout=self.config.cloud_stt_timeout)
                if response.status_code in {401, 403, 429}:
                    retry = response.headers.get("retry-after", "60")
                    self.cooldowns[provider] = time.monotonic() + (max(60, min(float(retry), 86400)) if retry.replace(".", "", 1).isdigit() else 60)
                response.raise_for_status()
                payload = response.json()
                segments = payload.get("segments", [])
                # Whisper can hallucinate fluent words on silence. Require both
                # poor acoustic confidence and high no-speech probability to reject.
                rejected = bool(segments) and all(s.get("no_speech_prob", 0) > .6 and s.get("avg_logprob", 0) < -1 for s in segments)
                text = "" if rejected else payload.get("text", "").strip()
                self.last_result = {"provider": provider, "model": self.config.groq_stt_model if provider == "groq" else "local_whisper",
                                    "seconds": round(time.monotonic()-started, 3), "audio_seconds": round(len(pcm)/32000, 2),
                                    "rejected_as_noise": rejected}
                self.bus.emit("latency", stage="recognition", **self.last_result)
                return text
            except (httpx.HTTPError, ValueError):
                self.cooldowns[provider] = max(self.cooldowns.get(provider, 0), time.monotonic()+15)
                self.bus.emit("degraded", subsystem="STT", message=f"{provider} transcription unavailable")
        return ""

    async def close(self):
        await self.client.aclose()
        if self.process and self.process.poll() is None:
            self.process.terminate()
            try:
                await asyncio.to_thread(self.process.wait, 3)
            except subprocess.TimeoutExpired:
                self.process.kill()
