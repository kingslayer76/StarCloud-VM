"""Prevent two microphone/controller loops from competing on the same desktop."""
import socket


class InstanceLease:
    def __init__(self, port=8177):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        try:
            self.socket.bind(("127.0.0.1", port))
            self.socket.listen(1)
        except OSError as error:
            self.socket.close()
            raise RuntimeError("ZORIN-M4 is already running. Use /quit in its existing window before restarting.") from error

    def close(self):
        self.socket.close()
