from core.config import Config, BrainConfig
from core.events import EventBus
from brain.router import ProviderRouter
from brain.planner import Planner
from brain.schemas import Plan
from memory.manager import Memory
from persona.personality import Personality


async def test_approved_labels_enable_cloud_planning_without_private_observation():
    class Router:
        async def complete(self, messages, **kwargs):
            self.messages, self.options = messages, kwargs
            return Plan(reply='Ready')
    config = Config()
    config.privacy.cloud_control_labels = True
    memory = Memory(':memory:', enabled=False)
    router = Router()
    try:
        planner = Planner(router, Personality(config, memory), memory, config)
        observation = {'hwnd':12,'title':'YouTube','process':'chrome.exe',
                       'focused_text':'PRIVATE_FIELD','windows':[{'title':'PRIVATE_WINDOW'}],
                       'elements':[{'name':'Settings','type':'ButtonControl','rect':[1,2,3,4]},
                                   {'name':'PRIVATE_DOCUMENT','type':'DocumentControl'}]}
        await planner.plan('Click Settings', [], observation, [])
        assert router.options['local_only'] is False
        assert 'Settings' in str(router.messages)
        assert 'PRIVATE_' not in str(router.messages)
        assert 'PRIVATE_DOCUMENT' in str(router.options['local_messages'])
    finally:
        memory.close()


async def test_private_screen_plan_uses_local_provider_even_when_cloud_is_healthy():
    class Provider:
        configured = True
        def __init__(self): self.requests = []
        async def complete(self, messages):
            self.requests.append(messages)
            return "local plan"
    cloud, local = Provider(), Provider()
    router = ProviderRouter(BrainConfig(primary_provider="groq", fallback_providers=["local"]), EventBus(), {"groq": cloud, "local": local})
    result = await router.complete([{"content": "screen hidden"}], local_messages=[{"content": "Settings button visible"}], local_only=True)
    assert result == "local plan"
    assert not cloud.requests
    assert local.requests == [[{"content": "Settings button visible"}]]


async def test_cloud_plan_can_correct_bad_url_before_falling_back():
    class Provider:
        configured=True
        def __init__(self): self.requests=[]
        async def complete(self,messages):
            self.requests.append(messages)
            target='YouTube' if len(self.requests)==1 else 'https://www.youtube.com/'
            import json
            return json.dumps({'actions':[{'kind':'navigate','target':target,'expected':{'kind':'url','value':target}}]})
    provider=Provider()
    router=ProviderRouter(BrainConfig(primary_provider='groq',fallback_providers=[]),EventBus(),{'groq':provider})
    plan=await router.complete([{'role':'user','content':'Open YouTube'}],Plan.model_validate_json)
    assert plan.actions[0].target=='https://www.youtube.com/'
    assert len(provider.requests)==2
    assert 'No actions from this plan were executed' in provider.requests[1][-1]['content']


async def test_planner_requests_local_context_when_screen_sharing_is_off():
    class Router:
        options = None
        async def complete(self, messages, **kwargs):
            self.options = kwargs
            return Plan(reply="Ready", actions=[], complete=True)
    config = Config()
    memory = Memory(":memory:", enabled=False)
    router = Router()
    try:
        planner = Planner(router, Personality(config, memory), memory, config)
        await planner.plan("Click Settings", [], {"hwnd": 12, "elements": [{"name": "Settings", "type": "ButtonControl"}]}, [])
        assert router.options["local_only"] is True
        assert "Settings" in str(router.options["local_messages"])
    finally:
        memory.close()


async def test_explicit_open_and_click_finishes_after_two_verified_actions(tmp_path):
    from core.orchestrator import Assistant
    from hands.executor import Outcome
    class Speech:
        speaking = False
        def say(self, text): pass
        def stop(self): pass
        async def close(self): pass
    class Desktop:
        actions = []
        async def observe(self): return {"hwnd": 123, "title": "Notepad", "process": "notepad.exe", "fingerprint": "test"}
        async def execute(self, action, *args):
            self.actions.append(action)
            return Outcome(True, "Verified", await self.observe())
        async def close(self): pass
    config = Config()
    config.voice.enabled = False
    config.memory.database = str(tmp_path / "memory.db")
    desktop = Desktop()
    assistant = Assistant(config, desktop, providers={}, speech=Speech())
    try:
        await assistant.submit("Open Notepad and click Settings")
        await assistant.task
        assert [(a.kind, a.target) for a in desktop.actions] == [("open_app", "Notepad"), ("click", "Settings")]
        assert assistant.state.outcome == "success"
    finally:
        await assistant.close()
