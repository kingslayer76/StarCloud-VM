"""Synthetic screen-input check: sends only an image generated here, no PC capture."""
import asyncio,json,sys
from io import BytesIO
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PIL import Image,ImageDraw,ImageFont
from core.config import load_config
from core.events import EventBus
from voice.live import LiveVoice

async def main():
    c=load_config();done=asyncio.Event();result={}
    async def text(role,message):
        if role=='assistant':result['reply']=message;done.set()
    async def no_tools(*args):return {'success':False}
    live=LiveVoice(c.voice,EventBus(),instruction=lambda:'Read the test image accurately. This is a screen-input test.',tools=[],on_text=text,on_tool=no_tools,on_interrupt=lambda:None)
    pic=Image.new('RGB',(800,500),'white');draw=ImageDraw.Draw(pic)
    font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',90)
    draw.text((70,160),'CODE 4826',font=font,fill='black')
    out=BytesIO();pic.save(out,format='JPEG')
    try:
        await live.start(microphone=False,playback=False)
        await live.screen_frame(out.getvalue())
        await asyncio.sleep(1.2)
        await live.text('Read the four-digit code in the image. Say only the digits in English.')
        await asyncio.wait_for(done.wait(),30)
        reply=result.get('reply','').lower()
        result['success']='4826' in reply.replace(' ','') or all(word in reply for word in ['four','eight','two','six'])
    except Exception as error:
        from safety.secrets import redact
        result['error']=redact(str(error));result['success']=False
    finally:
        await live.close()
    Path('data/live-screen-packet-check.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result),flush=True)
    return int(not result['success'])

if __name__=='__main__':raise SystemExit(asyncio.run(main()))
