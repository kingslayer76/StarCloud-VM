import re
import unicodedata
from brain.schemas import Plan, Action, action
from brain.desktop_language import clean_request, website_request, search_request, ordinal_request, scroll_request


def corrected(text):
    # A revision discards the earlier instruction. Literal typed payloads are preserved.
    if re.search(r"\btype(?: exactly)?\s*:", text, re.I):
        return text.strip()
    parts = re.split(r"\b(?:actually|instead|forget that|rehne de)\b\s*[,.:;-]?\s*", text, flags=re.I)
    return parts[-1].strip() if len(parts) > 1 and parts[-1].strip() else text.strip()


def normalize_hindi(text):
    # Multilingual Whisper may produce Devanagari for code-switched app commands.
    substitutions = {"क्रोम": "Chrome", "नोटपैड": "Notepad", "नोटपेड": "Notepad", "स्टीम": "Steam",
                     "यूट्यूब": "YouTube", "यू ट्यूब": "YouTube", "वीडियो": "video", "खोलो": "kholo", "खोल दो": "khol do", "खोल": "khol", "।": "."}
    for original, replacement in substitutions.items():
        text = text.replace(original, replacement)
    return text


def is_cancel(text):
    text = unicodedata.normalize("NFKC", text)
    return bool(re.fullmatch(r"\s*(?:(?:wait|actually)[,. ]*)?(?:cancel(?: that)?|stop(?: talking)?|wait(?: a second)?|be quiet|rehne de|bas|ruko|ruk ja(?:o)?|रुको|रुक(?: जाओ)?|बस|स्टॉप|कैंसल|रहने दो|रहने दे)[।.!?,\s]*", text, re.I))


class IntentRouter:
    def __init__(self, config, memory):
        self.config, self.memory = config, memory

    def open_action(self, name):
        name = name.strip(" .,")
        alias = self.config.app_aliases.get(name.casefold())
        learned = self.memory.learned_app(name.casefold())
        search = alias.search if alias else learned or name
        expected = alias.window if alias else learned or name
        return action("open_app", target=search, expected_kind="window", expected_value=expected, timeout=15, fallback="redetect")

    def route(self, text):
        text = corrected(text)
        if not re.search(r"\btype(?: exactly)?\s*:", text, re.I):
            text = clean_request(normalize_hindi(text))
        # Exact payload is separated before splitting command clauses.
        typed = re.fullmatch(r"open (.+?) and type(?: exactly)?\s*:\s*(.+)", text, re.I | re.S)
        if typed:
            app, payload = typed.groups()
            return Plan(actions=[self.open_action(app), action("type_text", text=payload, target="", expected_kind="text", expected_value=payload)])
        single_type = re.fullmatch(r"type(?: exactly)?\s*:\s*(.+)", text, re.I | re.S)
        if single_type:
            return Plan(actions=[action("type_text", text=single_type[1], expected_kind="text", expected_value=single_type[1])])
        website_url = website_request(text) or search_request(text)
        if website_url:
            return Plan(actions=[self.open_action("chrome"),
                action("navigate", target=website_url, expected_kind="url", expected_value=website_url, timeout=12)])
        ordinal = ordinal_request(text)
        if ordinal:
            category, index = ordinal
            return Plan(actions=[action("click_index", target=category, amount=index,
                                        expected_kind="url_changed" if category == "video" else "changed")])
        if re.fullmatch(r"you\s*tube (?:poll|pol)[.! ]*", text, re.I):
            # This observed mishearing is ambiguous: ask, never silently turn it
            # into permission for an action or invent words the microphone missed.
            return Plan(reply="YouTube खोलना है? एक बार 'YouTube खोलो' बोलो।")
        # Explicit app + named-control instructions have a complete, observable
        # meaning. Each action still passes safety checks and fresh verification.
        # Do not send them through another planning round after the click succeeds.
        app_click = re.fullmatch(r"(?:open|launch) (.+?)\s+(?:and|then|and then)\s+((?:click|double click|right click|hover(?: over)?) .+)", text, re.I)
        if not app_click:
            app_click = re.fullmatch(r"(.+?)\s+(?:kholo|khol do|khol)\s+(?:aur|phir)\s+((?:click|double click|right click|hover(?: over)?) .+)", text, re.I)
        if app_click:
            app, control_command = app_click.groups()
            if not re.search(r"\b(?:and|then|aur|phir)\b", app, re.I) and not re.search(r"\b(?:and|then|aur|phir)\b", control_command, re.I):
                click_plan = self.route(control_command)
                if click_plan and len(click_plan.actions) == 1 and click_plan.actions[0].kind in {"click", "double_click", "right_click", "hover"}:
                    return Plan(actions=[self.open_action(app), click_plan.actions[0]], complete=True)
        match = re.fullmatch(r"(?:open|launch) ([\w .'-]{1,80})[.!]?", text, re.I)
        if not match:
            match = re.fullmatch(r"([\w .'-]{1,80}) (?:kholo|khol|khol do|open kar|खोलो)[.!]?", text, re.I)
        if match and not re.search(r"\b(and|then|aur|search|launch|open|on|in|using|with|pe|par|pa|mein|me|yesterday|kal)\b|पर|पे|में", match[1], re.I):
            return Plan(actions=[self.open_action(match[1])])
        match = re.fullmatch(r"(?:click|double click|right click|hover(?: over)?) (?:the )?(.+?)(?: icon| button)?[.!]?", text, re.I)
        if match:
            kind = "double_click" if text.lower().startswith("double") else "right_click" if text.lower().startswith("right") else "hover" if text.lower().startswith("hover") else "click"
            return Plan(actions=[action(kind, target=match[1], expected_kind="cursor" if kind == "hover" else "changed")])
        amount = scroll_request(text)
        if amount is not None:
            return Plan(actions=[action("scroll", amount=amount)])
        match = re.fullmatch(r"volume (\d{1,3})[.!]?", text, re.I)
        if match and int(match[1]) <= 100:
            return Plan(actions=[action("volume", amount=int(match[1]), expected_kind="volume", expected_value=match[1])])
        simple = {"mute": "volume_mute", "pause": "media_play_pause", "close this": "alt+f4"}
        normalized = text.casefold().strip(" .!")
        if normalized in simple:
            return Plan(actions=[action("key", text=simple[normalized])])
        if normalized in {"screenshot", "take a screenshot"}:
            return Plan(actions=[action("screenshot", expected_kind="capture")])
        recipe = self.memory.recipe(text)
        if recipe:
            return Plan(actions=[Action.model_validate(a) for a in recipe])
        return None
