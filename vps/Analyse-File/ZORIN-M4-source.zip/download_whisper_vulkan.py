"""Install a pinned community CI build of upstream whisper.cpp beside the CPU build."""
import json
import zipfile
from pathlib import Path
from download_models import ROOT, fetch, sha256


def main():
    archive = ROOT / "vendor/whisper-vulkan-1.8.4.zip"
    source = "https://github.com/jiang1997/whisper.cpp-release/releases/download/v1.8.4.1/whisper-1.8.4-windows-x64.zip"
    fetch(source, archive, "4b1b36343feb55ec3deace6a7dd18cc217f43a55e4ecce76ccd4ee3595c0b642")
    folder = ROOT / "vendor/whisper-vulkan"
    folder.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as zipped:
        for info in zipped.infolist():
            if not info.is_dir() and Path(info.filename).suffix.lower() in {".exe", ".dll"}:
                (folder / Path(info.filename).name).write_bytes(zipped.read(info))
    (folder / "provenance.json").write_text(json.dumps({"upstream": "ggml-org/whisper.cpp", "version": "1.8.4",
        "builder": "jiang1997/whisper.cpp-release", "release": "v1.8.4.1", "sha256": sha256(archive),
        "workflow": "https://github.com/jiang1997/whisper.cpp-release/blob/main/.github/workflows/build.yml"}, indent=2))
    print("Vulkan Whisper installed beside CPU runtime. Select its executable in config.yaml after testing.")


if __name__ == "__main__":
    main()
