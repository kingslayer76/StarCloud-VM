"""Read-only accessibility scroll geometry diagnostic."""
import sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from perception.windows import Desktop
d=Desktop()
try:
    root=d.content_control(); rows=[]
    for control in d.walk(root,limit=800,seconds=2):
        try:
            pattern=control.GetScrollPattern()
            if pattern and pattern.VerticallyScrollable:
                r=control.BoundingRectangle
                rows.append({'type':control.ControlTypeName,'percent':pattern.VerticalScrollPercent,'rect':[r.left,r.top,r.right,r.bottom]})
        except Exception:
            continue
    print(json.dumps(rows))
finally:
    d.close()
