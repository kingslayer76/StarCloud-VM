import asyncio
import importlib
import os
import platform
import sqlite3
import sys
from core.config import project_path


async def doctor(config, executor, audio_probe=False):
    results = []
    def record(name, status, detail):
        results.append({"component": name, "status": status, "detail": detail})
    record("Python", "OK" if sys.version_info >= (3, 11) else "FAIL", platform.python_version())
    try:
        with sqlite3.connect(":memory:") as db:
            db.execute("SELECT 1").fetchone()
        record("SQLite", "OK", sqlite3.sqlite_version)
    except Exception as error:
        record("SQLite", "FAIL", type(error).__name__)
    try:
        import sounddevice as sd
        input_info = sd.query_devices(config.voice.input_device, "input")
        sd.check_input_settings(device=config.voice.input_device, channels=1, dtype="int16", samplerate=16000)
        record("Microphone", "OK", input_info["name"] + " (format supported; not a speech-quality test)")
        if audio_probe:
            import numpy as np
            pcm = sd.rec(16000, samplerate=16000, channels=1, dtype="int16", device=config.voice.input_device, blocking=False)
            await asyncio.sleep(1.2)
            sd.stop()
            rms = float(np.sqrt(np.mean(pcm.astype(np.float32)**2)))
            record("Microphone capture", "OK" if rms >= config.voice.energy_threshold else "WARN", f"1 second captured in RAM; RMS={rms:.1f}; audio discarded. Below-threshold input can mean silence; speak during listen_check.py to test speech.")
    except Exception as error:
        record("Microphone", "FAIL", type(error).__name__)
    try:
        info = sd.query_devices(config.voice.output_device, "output")
        sd.check_output_settings(device=config.voice.output_device, channels=1, samplerate=24000)
        record("Audio output", "OK", info["name"] + " (format supported)")
    except Exception as error:
        record("Audio output", "FAIL", type(error).__name__)
    try:
        observation = await asyncio.wait_for(executor.observe(), 12)
        record("UI Automation", "OK" if not observation.get("secure_desktop") else "WARN", f"{len(observation.get('windows', []))} windows; {len(observation.get('elements', []))} accessible controls")
        record("Mouse/keyboard", "READY", "SendInput loaded; use --smoke-desktop to test actual input")
    except Exception as error:
        record("UI Automation", "FAIL", type(error).__name__)
    whisper_ok = all(project_path(p).exists() for p in [config.voice.whisper_executable, config.voice.whisper_model])
    record("Whisper", "READY" if whisper_ok else "MISSING", "Local binary/model present" if whisper_ok else "Run setup.ps1 -DownloadModels")
    tts_ok = all(project_path(p).exists() for p in [config.voice.kokoro_model, config.voice.kokoro_voices])
    record("Kokoro TTS", "READY" if tts_ok else "MISSING", "Local model/voices present" if tts_ok else "SAPI fallback available on Windows")
    if config.voice.tts_provider == "gemini":
        record("Gemini TTS", "CONFIGURED" if os.getenv("GEMINI_API_KEY", "").strip() else "NEEDS KEY",
               config.voice.gemini_tts_model + "; voice=" + config.voice.gemini_tts_voice + "; live synthesis must be tested separately")
    elif config.voice.tts_provider in {"google", "edge"}:
        record("Online TTS", "CONFIGURED", config.voice.tts_provider + "; reply text sent online, availability requires a live test")
    for name, provider in config.brain.providers.items():
        ready = bool(provider.model and (name == "local" or os.getenv(provider.key_env)))
        record(name.capitalize(), "CONFIGURED" if ready else "NOT CONFIGURED", "Reachability not tested; keys are never displayed")
    return results
