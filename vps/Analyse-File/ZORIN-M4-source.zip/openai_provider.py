from .base import ChatProvider


class OpenAIProvider(ChatProvider):
    name = "openai"
