# ZORIN-M4

A Windows voice companion using Gemini Live native audio, local memory, and verified desktop actions. The voice system is adapted from the user's AI Studio ZIP; its React UI, HUD, themes and browser proxy are not imported.

## Start on this computer

Double-click **RUN-ZORIN-VOICE.bat** in `I:\ZORIN-M4`. The dependencies and local models are already installed here. Wait for **ZORIN-M4 ready**, then speak or type.

```powershell
cd I:\ZORIN-M4
.\run.bat
```

Examples:

- “Hello Zorin.”
- “Chrome kholo.”
- “YouTube kholo.” / “यूट्यूब खोलो।”
- “Open YouTube on Chrome.” / “Click on the fourth video.”
- “Zorin, Chrome pe YouTube khol.” / “Chrome par YouTube search kar.”
- “Open Notepad and type: hello boss.”
- “Click Settings.”
- “Scroll down.” / “Volume 30.”
- “Actually rehne de, Steam khol.”
- “Wait, cancel that.”
- “Remember that I prefer short replies.”

The microphone listens continuously while enabled. There is no wake-word gate: spoken commands can execute immediately. Use headphones to keep the assistant's own voice and media audio out of the microphone. Avoid switching windows while it is carrying out a desktop task; it stops when focus changes unexpectedly.

| Launcher | Microphone | Spoken replies |
| --- | --- | --- |
| `RUN-ZORIN-VOICE.bat` or `run.bat` | On | On |
| `RUN-KEYBOARD-WITH-VOICE.bat` or `run.bat --keyboard` | Off | On |
| `run.bat --text` | Off | Off |
| `SETUP-AUDIO.bat` | Diagnostic only | Test announcement |

**`--text` explicitly disables voice.** Close with `/quit` or Ctrl+C. Closing the console also releases the local model servers. A second assistant instance is rejected to prevent duplicate microphone capture and actions.

## Microphone and voice

The default is **Gemini 3.1 Flash Live Preview + Puck**, matching the model and speaker in `zorion---m4-ai-assistant.zip`. It uses one continuous audio-to-audio connection, with 16 kHz microphone input and 24 kHz speech playback. It does not wait for separate Groq transcription, text reasoning and TTS requests. Delivery is adapted from the archive: confident, expressive, playful and casual, with everyday Hindi/Hinglish instead of formal Hindi. The UI and its unverified browser-success acknowledgements were not imported. The original ZIP is untouched.

Run `run.bat` or `RUN-ZORIN-VOICE.bat`. `run.bat --keyboard` uses Live speech with typed input and no microphone. `run.bat --text` runs the existing text controller. `run.bat --cascade` restores the previous voice pipeline described below. Live mode needs the saved `GEMINI_API_KEY`; it does not silently replace Puck with another voice if Google is unavailable. Connection failures are shown and retried; `/reconnect` reconnects explicitly. Typed desktop commands remain available during an established session's network outage. Initial connection failure exits with an error.

**Data flow:** microphone audio passes through a local speech/noise gate before admitted speech is streamed to Google. During replies, candidate interruptions are held and checked with the previously approved Groq speech-recognition service; only an assistant address or explicit stop command admits them to Gemini. Audio is not saved locally. Recent dialogue and explicit preferences are included for continuity. With the user's existing `cloud_activity_titles: true` choice, settled app/tab titles and process names can also be sent; page contents, screenshots and typed fields are not part of these ambient updates. Use `/mic off`, `/mic on`, `/quiet` and `/unquiet`. `/forget-memory` erases local memories and starts a new Live session without reusing the old session handle; it cannot retroactively erase data already sent to the provider.

**Screen sharing is now separately enabled with explicit permission.** Changed active-window images are sent to Google Gemini Live at most once every two seconds, resized to fit 1280×960. These images include visible page contents. `/screen off` pauses new images and disables visual click fallback; `/screen on` restores both. The preference persists. Protected/password and excluded private/security/terminal windows are skipped; this is not automatic redaction of everything visible in an ordinary page. Frames stay in RAM locally. The title-only activity prompts described above remain a separate path. Video frames use Google's [documented Live video input](https://ai.google.dev/gemini-api/docs/live-api/get-started-websocket#send-video).

The Live microphone gate now uses a 100-RMS minimum, VAD mode 2, a noise-relative threshold and a lower continuation threshold to preserve quieter syllables. Admitted speech receives bounded 2× input gain; gate decisions still use raw audio. Reply interruptions still need sustained speech plus a recognized assistant address or stop phrase. The user's normal-volume check admitted one utterance; it did not transcribe words, and is not proof of perfect recognition.

Live speech is generated in context, not selected from fixed jokes or cached acknowledgements. A settled app/tab change can prompt a relevance check that chooses a specific thought or silence before sending anything to the voice model. The previous 20-second conversational-pause trigger is removed. New speech, changed context and quiet mode discard pending comments. Timing controls limit interruptions; they do not schedule a remark every interval. Quiet mode persists. There are still model inference and code: this is not AGI, consciousness, or a guarantee of no repetition. The exact voice delivery can vary.

Tools call the existing verified local controller, wait for its outcome, and report failures honestly. Ambient events cannot authorize desktop actions. A single user request cannot execute twice because the model repeats a tool call. Sensitive-action confirmations, local `/cancel`, and focus protection remain. Confirmed model interruptions clear queued audio and stop remaining actions. While ZORIN is replying, begin with "Zorin, ..." or say "stop" / "ruko". Ordinary background conversation is rejected rather than pausing playback. When he is quiet, ordinary speech still works without an address. Use headphones: the Python audio device path does not inherit the browser's echo cancellation/noise suppression from the ZIP. Server automatic VAD is disabled. Local WebRTC VAD, a noise-relative energy threshold, sustained speech checks, preserved onset audio and a minimum 600 ms end silence control speech boundaries. Real-room microphone accuracy still needs user validation. This is not speaker identification: a clear nearby voice while idle, or another person explicitly saying the stop command, can still be admitted.

A persistent playback stream buffers 200 ms before starting and queues subsequent audio continuously. In the initial 125 ms-buffer probe, Puck started playing at 0.765 s and 1.297 s after two text prompts with zero underruns. These are text-input timings, not microphone-to-answer guarantees. Actual desktop work and verification add their own delay. See `TEST_REPORT.md` for failures and limitations. Google account quotas and preview availability apply; no billing changes have been made. [Official Live capabilities](https://ai.google.dev/gemini-api/docs/live-api/capabilities), [session resumption](https://ai.google.dev/gemini-api/docs/live-api/session-management).

Configuration: `voice.mode`, `voice.live_model`, `voice.live_voice`, `voice.live_endpoint_ms`, `voice.live_reply_protection`, `voice.live_min_energy`; delivery lives in `persona/live.py`. `SETUP-AUDIO.bat` still selects the shared microphone/output devices, but its old voice audition tests the cascade voice. Use `/voice-test` inside a Live session to hear Puck, or run `.venv\Scripts\python.exe -X utf8 scripts\check_live_voice.py --play` with ZORIN closed. That standalone probe uses synthetic text and does not open the microphone or execute desktop actions.

The following provider, cache and standalone Whisper details apply only to `--cascade`:

### Previous pipeline: --cascade

The selected provider is **Gemini 3.1 Flash TTS Preview**, using **Algieba** with the smooth, calm delivery chosen by the user. If that model is unavailable or reaches its quota, the configured Gemini 2.5 Flash TTS fallback uses the same speaker and delivery instructions. The console reports the actual backend; matching settings do not guarantee identical delivery across models. This computer's saved Google AI Studio key has passed real synthesis and conversation checks. On another installation, add your own key to `.env` as `GEMINI_API_KEY`, then restart. `gemini_tts_voice` and `gemini_tts_style` select the speaker and delivery. The brain uses everyday Hindi with familiar English words, avoiding literary/Sanskrit-heavy wording. Voice auditions and user feedback are recorded in TEST_REPORT.md.

Gemini TTS sends reply text and delivery instructions to Google. At the user's choice, recognition now sends detected speech segments to Groq's `whisper-large-v3` using the saved `GROQ_API_KEY`, with local Whisper as fallback. Voice activity detection remains local and microphone audio is not saved to disk. To keep recognition entirely local, set `stt_provider: local_whisper` and leave `cloud_stt_fallback: false`. Cloud recognition has a five-second request timeout and failed providers cool down before another attempt. See [Groq speech recognition](https://console.groq.com/docs/speech-to-text). Google's Developer API lists a limited free tier; account quotas apply. Do not enable billing if you want to stay on the free tier. See [Google speech generation](https://ai.google.dev/gemini-api/docs/generate-content/speech-generation) and [Developer API pricing](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.1-flash-tts-preview).

Alternatives under `voice.tts_provider`: `google` means Google Translate through gTTS (no key, no selectable male/emotion preset); `edge` uses Microsoft's online Hindi/Indian English voices (no key); `kokoro` uses local voices. Online services receive reply text. The user found Translate and the auditioned Microsoft voices too robotic. Kokoro is the configured offline fallback, using `hm_omega` for Hindi and `bm_george` for English. Fallback use is reported in the console.

Gemini 3.1 streams each reply through one continuous output stream, starting after a small initial audio buffer. This avoids waiting for the entire reply to finish generating. The actual Hindi test began playback at 1.968 seconds and completed without buffer underruns; initial latency and network delays still vary. The 2.5 fallback uses a complete audio buffer because that Developer API model does not support TTS streaming. If a stream fails after audio has arrived, the text remains visible and the reply is not repeated in another voice. See [Google's streaming speech documentation](https://ai.google.dev/gemini-api/docs/generate-content/speech-generation#streaming-speech-generation).

Fixed acknowledgements such as “हाँ, बोलो।” and “हो गया।” are cached after successful synthesis and reused across restarts with the same voice settings. Only a fixed allowlist of non-personal phrases is saved in `data/voice-cache`; conversation audio is not saved. Changing the speaker or delivery invalidates the old cache. Local recognition fallback uses Whisper **large-v3-turbo q5_0** on Vulkan, with a CPU backend fallback.

After saving the key, run `.venv\Scripts\python.exe -X utf8 scripts\smoke_google_tts.py --gemini` to audition actual Gemini speech. Without `--gemini`, this tests Google Translate speech. Neither test captures the microphone or performs desktop actions.

Run **SETUP-AUDIO.bat** to select a microphone and speaker, save them in `config.yaml`, and run a spoken test. Device selections use names and audio-driver names, not unstable device indices. Press Enter to follow the Windows default instead. Re-run setup after replacing a selected device.

Useful diagnostics:

```powershell
.\run.bat --devices
.\.venv\Scripts\python.exe scripts\listen_check.py --seconds 30
.\.venv\Scripts\python.exe scripts\smoke_voice.py --vulkan --play
.\run.bat --doctor --audio-probe
```

The listening check announces itself, prints microphone levels and recognized phrases, and does not execute commands or save audio. A near-zero level while you are speaking usually means the wrong input, a physical mute, a disconnected microphone, or a Windows permission/driver problem. A supported audio format alone does not prove the microphone can hear you.

If you cannot hear replies, select the actual output in audio setup. Windows may switch to monitor HDMI audio when headphones disconnect. `/voice-test` tests speech in an active assistant session. `/mic off` pauses incoming microphone frames and `/mic on` resumes them. Pausing, resuming and cancellation invalidate pending audio and partial utterances so old speech cannot become a new command later.

Voice settings live under `voice` in `config.yaml`: `tts_provider`, `gemini_tts_voice`, `gemini_tts_model`, `edge_hindi_voice`, `edge_english_voice`, `kokoro_voice`, `kokoro_hindi_voice`, `input_device`, `output_device`, `energy_threshold`, `endpoint_ms`, `allow_barge_in`, and `barge_in_mode`. `tts_speed` controls Kokoro only. The current energy threshold is 180 in PCM16 RMS units. Do not lower it to compensate for a microphone producing no useful signal.

The default **confirmed** interruption mode waits for recognized words: sound alone cannot cut off a reply. During desktop work, address it with “Zorin, ...” or use a stop/cancel phrase. In companion conversation, a natural follow-up can interrupt without repeating its name; echo filtering still applies. Recognition adds interruption latency; `/cancel` is immediate. The optional `speech` mode permits earlier interruption after sustained voice activity and is more vulnerable to background audio. Completed actions are not undone.

The sentence endpoint is 600 ms, with a 300 ms minimum speech duration and a 360 ms sustained activity check. Sparse noise bursts are rejected. Recognition uses automatic language detection and a Hindi/Hinglish vocabulary hint including YouTube, Chrome and Zorin. Local fallback retains beam size 3. Previous local automatic-language tests took about 4.4–4.7 seconds on three short synthetic samples; Groq's selected full Whisper model took 0.235–0.359 seconds on four synthetic samples and understood YouTube, Chrome, a stop phrase and casual Hindi. This measures recognition, not total response latency or real microphone accuracy. Hindi stop phrases such as “रुको” and “रुक जाओ” are recognized as cancellation commands. M4 and Zorin are both accepted as names. A transcript of “YouTube poll” asks for clarification instead of silently guessing an action. This is not speaker identification: intelligible background voices may still be recognized while idle.

## Fresh installation

Use Windows 10/11 x64 and Python 3.11–3.13; Python 3.12 is the tested version. Allow several GB of disk space for models, archives, and the virtual environment. The tested machine has 16 GB RAM and an RX 580 8 GB GPU.

```powershell
powershell -ExecutionPolicy Bypass -File .\setup.ps1 -DownloadModels -DownloadBrain
```

If Python is not on PATH:

```powershell
.\setup.ps1 -Python 'C:\Path\To\python.exe' -DownloadModels -DownloadBrain
```

Setup creates `.venv`, installs dependencies, creates `.env` if absent, downloads requested model/runtime assets, runs tests, and prints diagnostics. Downloads reuse completed files; interrupted partial files are downloaded again. `requirements-lock.txt` records the tested installation; `requirements.txt` gives supported version ranges. Setup does not enable Windows autostart.

## Desktop reasoning and cascade provider fallback

This installation includes Qwen3-4B-Instruct-2507 Q4_K_M served by llama.cpp on loopback port 8179 with Vulkan acceleration and an 8192-token context. The local brain works without a cloud key. Provider order is Groq, Gemini, then local; unavailable providers trigger bounded fallback. Adding `GEMINI_API_KEY` also makes the configured Gemini reasoning provider eligible. Ordinary conversation uses plain spoken replies; desktop tasks retain structured plans. Deterministic commands remain available if reasoning fails.

Optional provider keys go in `.env`, never in source files or chat. A key being present is not proof that the service accepts it. Cloud conversation sends conversation and selected memory context to the chosen provider. With companion mode enabled, greetings and normal task replies use model-generated wording rather than rotating stock phrases. Ordinary conversation skips action-schema generation. Groq GPT-OSS uses low reasoning effort for conversation. Hinglish is the configured reply language. Full textual screen context remains off; separately approved Live image sharing and visual targeting are enabled. Console LATENCY events separate recognition, reasoning and speech-generation time.

The user separately approved `privacy.cloud_control_labels: true`: cloud planning can receive visible interactive control names/types/positions and the foreground app/title. Edit/combo fields, document bodies, field values, other windows, URLs and screenshots are excluded from this textual observation payload; the separately enabled image-sharing path can show visible content. If both control-label and textual screen-context sharing are disabled, observed-control planning stays local. The small local model has limited reasoning ability and may produce poor plans or take several seconds under load. Schema validation, fresh observations, action checks and bounded retries do not make every workflow reliable. On a computer without a compatible GPU, set `brain.local_gpu_layers: 0`; CPU reasoning will be slower.

For YouTube and other Chromium pages, ZORIN prefers the named page accessibility document over an empty WebView wrapper. If a site exposes no usable links, approved Gemini screen vision can locate a visible target with a fresh active-window image; the result is discarded if the window changes before the physical click. Visual boxes use the documented 0–1000 image coordinate scale. Page scrolling is accepted only after a coherent screenshot or accessibility-anchor movement is verified.

Numerical worker pools default to two threads to reduce memory pressure alongside other desktop apps. Advanced users can set `ZORIN_BLAS_THREADS` to a value from 1 to 4 before launch. This is separate from the configured Whisper/llama and ONNX inference threads.

## Desktop actions and limits

Windows UI Automation supplies foreground/window/control names, bounds and focused text. Password controls are excluded. Desktop actions use actual mouse movement and SendInput keyboard input, then check the result. Named controls must resolve unambiguously. Installed applications launch through their exact Windows registered app identity; this avoids Start search choosing a web result. Existing windows are reused. Known apps such as Chrome, Notepad and Steam also require the expected foreground process, so a matching web-page title cannot pass app-launch verification.

Supported primitives include open/focus app, Chrome URL navigation, named and ordinal clicks, double/right-click, hover, drag, scroll, literal text, approved key chords, wait, volume and screenshots. “Open YouTube on Chrome” resolves the app and website separately; an unknown full sentence cannot become a Windows Start search. Navigation focuses Chrome's address bar, replaces and checks its exact value, presses Enter, and verifies the resulting URL. Existing Chrome windows avoid installed-app catalogue refresh.

Hinglish browser qualifiers include pe/par/pa/mein and their Hindi forms. “Chrome pe YouTube khol” opens the site; “Chrome par YouTube search kar” searches Google for YouTube in Chrome. A garbled transcript such as “Jori new call” is not silently reinterpreted as an opening command. Live tools cannot report desktop success when no action ran. Cloud planning gets one schema-correction attempt before provider fallback, and Live mode warms the local backup brain in the background.

“Click the fourth video” counts identifiable YouTube watch/Shorts cards from the current viewport, top to bottom and left to right, counting thumbnail/title duplicates once. Bounded downward scrolling can reveal later cards; the click uses the target's freshly measured position and verifies its URL. Other websites without identifiable video controls are not supported by this video selector. Generic link/button/tab/item ordinals select among currently visible controls. The planner returns short strict-JSON batches and observes again after switching apps. Typing requires a verified editable field. Changed focus, missing targets, ambiguous controls and unverified results stop the task. Generic “changed” verification is weaker than verifying a specific destination.

Security/credential interfaces and terminal typing are blocked. Sensitive commits such as sending, deleting or account changes require an expiring confirmation tied to the action and screen state. Use `/confirm ID` or `/deny ID`. The application cannot bypass UAC or control the secure desktop. It does not run arbitrary model-generated shell commands.

Visual targeting is enabled on this installation. When accessibility cannot locate a click target or exposes no video cards, the current window image can go to the configured Gemini image model. Targets require confidence of at least 0.85, a fresh screen/focus check and outcome verification. The configured model is `gemini-2.5-flash-lite`; the previous image model timed out. Live screen understanding and visual coordinate targeting have separate checks in TEST_REPORT.md. Missing/offscreen targets and custom-rendered apps can remain unsupported. A schema-valid plan is not proof of execution.

Scrolling moves the pointer over measured page content and checks coherent vertical pixel movement or matching control-label positions; a changed toolbar alone does not verify scrolling. Video enumeration starts inside the page document to reach nested cards. Forms such as “play video number 8”, “4 wala video chalao”, “neeche scroll karo” and “upar scroll karo” are supported. At a page boundary, an unverified scroll is reported instead of claiming movement. Chrome navigation removes selected inline history-autocomplete before checking its exact typed destination.

## Memory, personality and proactivity (cascade details)

`data/assistant.db` is a local SQLite database. Explicit preferences, selected memories, task outcomes, app use, feedback and successful procedures persist across restarts. Context retrieval uses relevance, importance, confidence and recency. Repeated app use can inform preferred-app selection. Complex recipes are re-planned against the current screen; only app/focus/wait recipes qualify for automatic reuse.

Companion mode watches minimal foreground metadata once a second. After an app or tab title stays stable for two seconds, a model decides whether a relevant observation, curious question or brief joke is worthwhile. It can choose silence. This layer never executes actions. The title is checked again before speaking, so switching away or starting a command discards a stale comment. Comments are at least 12 seconds apart, and the same topic is suppressed for ten minutes. Timing rules limit interruptions; wording comes from the model, not a phrase list.

Only the active title and app name are shared under `privacy.cloud_activity_titles`, which the user enabled separately. Page bodies, typed fields, other window titles and screenshots are not included in activity prompts. Protected/password interfaces and detected private-browsing titles are skipped. Titles are untrusted data and cannot authorize actions. Set the option false to use the local model for activity comments instead.

Task completion wording is prepared while the action runs and spoken only after successful verification. Novel Gemini audio may also be prepared in RAM, overlapping generation with the work. Failed/cancelled tasks discard the prepared success reply. Provider failures can still result in a simple fallback acknowledgement. This does not remove cloud quota or service latency.

The most recent 60 dialogue turns and recently discussed topic hashes persist locally. They support continuity and repetition checks; a window title alone is not evidence of a personal preference. Explicit preferences such as “याद रखना, मुझे छोटे जवाब पसंद हैं” remain supported. `/quiet` or “अभी मत बोलो” pauses proactive remarks across restarts; `/unquiet` or “बात करते रहो” resumes them. There is no continuous screen recording.

`/memory` lists preferences. `/forget-memory` erases local memories, preferences, feedback, learned recipes and task records. It does not erase backups you made. Microphone and personal conversation audio are not saved; only fixed synthetic acknowledgement clips may be cached. Screenshots remain in RAM unless `privacy.save_screenshots` is enabled. Secret detection/redaction is a safeguard, not a guarantee: enter secrets directly in the application instead of speaking or typing them to ZORIN-M4.

## Controls and diagnostics

| Control | Purpose |
| --- | --- |
| `/help` | Command reference |
| `/status` | Current task phase |
| `/cancel` | Stop remaining actions and speech |
| `/confirm ID`, `/deny ID` | Resolve the current approval |
| `/quiet`, `/unquiet` | Control proactive remarks |
| `/voice-test`, `/devices` | Audio troubleshooting |
| `/mic off`, `/mic on` | Pause/resume microphone input |
| `/screen off`, `/screen on` | Pause/resume active-window images and visual targeting |
| `/memory`, `/forget-memory` | Inspect preferences or erase memory |
| `/quit` | Clean shutdown |

```powershell
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m pip check
.\run.bat --doctor
.\run.bat --smoke-desktop
.\.venv\Scripts\python.exe scripts\smoke_planner.py
```

`--smoke-desktop` opens Notepad, creates a new document and visibly types a harmless sentence. It leaves the unsaved test document for inspection. Do not move focus during the test. `smoke_planner.py` validates real-model responses without executing them. See `TEST_REPORT.md` for observed results and unverified requirements.

## Backend and future clients

`core` coordinates state, cancellation and events; `brain` plans and routes providers; `voice` captures, segments, transcribes and speaks; `perception` reads the desktop; `hands` executes and verifies; `safety` checks actions and approvals; `memory` stores durable context; `persona` controls tone and proactivity.

The optional WebSocket server is disabled. To enable it, set `services.websocket_enabled: true` and put a random token of at least 24 characters in `ZORIN_WS_TOKEN` in `.env`. It binds to loopback only (default port 8765), rejects browser origins, and requires `{"token":"..."}` as the first message within five seconds. Use an authenticated tunnel/native client for a future remote tablet; do not expose the server directly to the internet.

Messages: `text_command` with `text`; `interrupt`; `cancel`; `confirmation` with `id` and `approved`; `microphone_audio` with base64 `audio` containing exactly one 30 ms mono PCM16 16 kHz frame (960 bytes). Outgoing events contain `type`, `data`, and `timestamp`: text, recognized speech, speaking/state, current action, verification, progress, confirmation, provider and system stats. There is no tablet UI or outgoing audio-stream protocol yet; speech plays on the host PC.

Optional startup: set `assistant.autostart: true`, then explicitly run `scripts\autostart.py` with the venv Python. It creates a minimized sign-in shortcut. Set it false and rerun that script to remove the shortcut. Autostart is currently off.

## Local runtime sources

- [llama.cpp b10865](https://github.com/ggml-org/llama.cpp/releases/tag/b10865), Vulkan Windows runtime.
- [Qwen3-4B-Instruct-2507](https://huggingface.co/Qwen/Qwen3-4B-Instruct-2507), using the [LM Studio community GGUF](https://huggingface.co/lmstudio-community/Qwen3-4B-Instruct-2507-GGUF). The previous model remains installed for rollback.
- [whisper.cpp](https://github.com/ggml-org/whisper.cpp), multilingual recognition. Official b4938 CPU build is retained as a fallback.
- [whisper.cpp Vulkan build workflow](https://github.com/jiang1997/whisper.cpp-release), community Windows CI build v1.8.4.1 of upstream whisper.cpp. This is a community binary, not the official upstream Windows release. Its pinned SHA-256 and source provenance are recorded by `scripts/download_whisper_vulkan.py` under `vendor/whisper-vulkan`.
- [Kokoro ONNX model assets](https://github.com/thewh1teagle/kokoro-onnx/releases/tag/model-files-v1.0), local TTS model and voice presets.

Download scripts retain provenance and checksums. Runtime binaries/model licenses belong to their respective upstream projects. The tested fast speech path uses the Vulkan build; if startup fails, the program tries the retained CPU build, which is slower on this machine.
