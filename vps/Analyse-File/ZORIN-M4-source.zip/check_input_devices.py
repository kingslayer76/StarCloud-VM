"""List matching input endpoints and whether they accept the Live 16 kHz format."""
import json
import sounddevice as sd

devices = sd.query_devices()
apis = sd.query_hostapis()
rows = []
for index, device in enumerate(devices):
    if not device["max_input_channels"] or "Microphone (Usb Audio Device)" not in device["name"]:
        continue
    try:
        sd.check_input_settings(device=index, channels=1, dtype="int16", samplerate=16000)
        status = "supports_16000"
    except Exception as error:
        status = str(error).split(":", 1)[0]
    rows.append({"index": index, "api": apis[device["hostapi"]]["name"],
                 "default_samplerate": device["default_samplerate"], "status": status})
print(json.dumps(rows))
