import asyncio
import pytest
from core.config import VoiceConfig, BrainConfig
from core.events import EventBus
from voice.vad import Segmenter
from voice.microphone import Microphone
from voice.commands import voice_command
from brain.router import ProviderRouter


def test_scattered_noise_does_not_accumulate_into_an_interruption():
    segmenter = Segmenter(VoiceConfig(), classifier=lambda frame, rate: frame[0] == 1)
    results = [segmenter.feed(bytes([1 if i % 5 == 0 else 0]) * 960) for i in range(100)]
    results += [segmenter.feed(bytes(960)) for _ in range(30)]
    assert not any(barge for _, barge in results)
    assert not any(segment for segment, _ in results)


def test_short_pause_does_not_split_one_instruction():
    segmenter = Segmenter(VoiceConfig(), classifier=lambda frame, rate: frame[0] == 1)
    segments = []
    for voiced in [1]*15 + [0]*16 + [1]*20 + [0]*28:
        segment, _ = segmenter.feed(bytes([voiced])*960)
        if segment:
            segments.append(segment)
    assert len(segments) == 1


async def test_confirmed_mode_does_not_cancel_on_vad_or_invalidate_pending_text():
    from unittest.mock import patch
    class VAD:
        def __init__(self, config): pass
        def feed(self, frame): return b"utterance", True
    calls = []
    microphone = Microphone(VoiceConfig(), None, EventBus(), None, lambda: calls.append("cancel"))
    with patch("voice.microphone.Segmenter", VAD):
        worker = asyncio.create_task(microphone._segment())
        microphone.audio.put_nowait(bytes(960))
        await asyncio.sleep(.01)
        worker.cancel()
        await asyncio.gather(worker, return_exceptions=True)
    assert not calls
    assert microphone.epoch == 0
    assert microphone.segments.get_nowait() == (0, b"utterance")


def test_only_addressed_speech_or_stop_interrupts_a_busy_assistant():
    assert voice_command("random background words", busy=True) is None
    assert voice_command("Hello Zorin. Open YouTube.", busy=True) == "Open YouTube."
    assert voice_command("Zorin, wait, cancel that.", busy=True) == "wait, cancel that."
    assert voice_command("stop", busy=True) == "stop"
    assert voice_command("Hello Zorin.") == "Hello"
    assert voice_command("Kaise ho?") == "Kaise ho?"


def test_playback_echo_does_not_become_a_command():
    assert voice_command("I'm here, boss. Bolo.", speaking=True, last_reply="I'm here, boss. Bolo.") is None


async def test_restarted_local_server_clears_old_failure_cooldown():
    class Provider:
        configured = True
        async def complete(self, messages): return "ready"
    router = ProviderRouter(BrainConfig(primary_provider="local", fallback_providers=[]), EventBus(), {"local": Provider()})
    router.cooldown["local"] = 1e20
    async def recovered(): return True
    router.local_recovery = recovered
    assert await router.complete([]) == "ready"


async def test_conversation_does_not_request_an_action_schema():
    class Provider:
        configured = True
        json_mode = None
        async def complete(self, messages, json_mode=True):
            self.json_mode = json_mode
            return "Long day, huh?"
    provider = Provider()
    router = ProviderRouter(BrainConfig(primary_provider="local", fallback_providers=[]), EventBus(), {"local": provider})
    assert await router.complete([], conversation=True) == "Long day, huh?"
    assert provider.json_mode is False


async def test_multi_sentence_reply_uses_one_continuous_audio_buffer():
    from unittest.mock import AsyncMock
    from voice.tts import SpeechOutput
    speech = SpeechOutput(VoiceConfig(tts_provider="edge", tts_fallbacks=[]), EventBus())
    provider = type("Provider", (), {"synthesize_async": AsyncMock(return_value=([0.0], 24000))})()
    speech.providers["edge"] = provider
    speech.playback.play = AsyncMock()
    try:
        speech.say("First sentence. Second sentence. तीसरा वाक्य।")
        await speech.task
        provider.synthesize_async.assert_awaited_once_with("First sentence. Second sentence. तीसरा वाक्य।")
        speech.playback.play.assert_awaited_once()
        assert not speech.speaking
    finally:
        await speech.close()


def test_hindi_local_fallback_uses_hindi_voice_and_phonemizer():
    from unittest.mock import Mock
    from voice.tts import KokoroProvider
    provider = KokoroProvider(VoiceConfig())
    provider.engine = Mock()
    provider.synthesize("हाँ, Chrome खोलते हैं।")
    assert provider.engine.create.call_args.kwargs["voice"] == "hm_omega"
    assert provider.engine.create.call_args.kwargs["lang"] == "hi"
    provider.synthesize("I'm listening.")
    assert provider.engine.create.call_args.kwargs["lang"] == "en-gb"


async def test_online_voice_failure_falls_back_without_repeating_partial_speech():
    from unittest.mock import Mock, AsyncMock
    from voice.tts import SpeechOutput
    speech = SpeechOutput(VoiceConfig(tts_provider="edge", tts_fallbacks=["kokoro"]), EventBus())
    speech.providers["edge"].synthesize_async = AsyncMock(side_effect=TimeoutError)
    speech.providers["kokoro"].synthesize = Mock(return_value=([0.0], 24000))
    speech.playback.play = AsyncMock()
    try:
        speech.say("मैं सुन रहा हूँ।")
        await speech.task
        speech.providers["kokoro"].synthesize.assert_called_once_with("मैं सुन रहा हूँ।")
        speech.playback.play.assert_awaited_once()
        assert "edge" in speech.failed_until
    finally:
        await speech.close()


async def test_cancelling_online_generation_does_not_start_fallback_or_playback():
    from unittest.mock import Mock, AsyncMock
    from voice.tts import SpeechOutput
    speech = SpeechOutput(VoiceConfig(tts_provider="edge", tts_fallbacks=["kokoro"]), EventBus())
    entered = asyncio.Event()
    async def waiting(text):
        entered.set()
        await asyncio.Event().wait()
    speech.providers["edge"].synthesize_async = waiting
    speech.providers["kokoro"].synthesize = Mock()
    speech.playback.play = AsyncMock()
    try:
        speech.say("A reply.")
        await entered.wait()
        speech.stop()
        await speech.task
        speech.providers["kokoro"].synthesize.assert_not_called()
        speech.playback.play.assert_not_awaited()
    finally:
        await speech.close()


async def test_gemini_tts_decodes_complete_pcm_and_sends_only_reply(monkeypatch):
    import base64
    import json
    import httpx
    import numpy as np
    from voice.tts import GeminiTTSProvider
    monkeypatch.setenv("GEMINI_API_KEY", "test-key")
    def handle(request):
        body = json.loads(request.content)
        assert request.headers["x-goog-api-key"] == "test-key"
        assert "gemini-3.1-flash-tts-preview:generateContent" in str(request.url)
        assert body["generationConfig"]["responseModalities"] == ["AUDIO"]
        assert body["contents"][0]["parts"][0]["text"].endswith("हाँ, बोलो। क्या हुआ?")
        return httpx.Response(200, json={"candidates": [{"finishReason": "STOP", "content": {"parts": [{
            "inlineData": {"mimeType": "audio/L16; rate=24000; channels=1",
                           "data": base64.b64encode(np.array([0, 16384, -16384], dtype="<i2").tobytes()).decode()}}]}}]})
    audio, rate = await GeminiTTSProvider(VoiceConfig(), httpx.MockTransport(handle)).synthesize_async("हाँ, बोलो। क्या हुआ?")
    assert rate == 24000
    assert audio.tolist() == [0, .5, -.5]


@pytest.mark.parametrize("payload", [{"candidates": []}, {"candidates": [{"finishReason": "MAX_TOKENS"}]},
                                      {"candidates": [{"finishReason": "STOP", "content": {"parts": []}}]}])
async def test_gemini_tts_rejects_empty_or_unfinished_generation(monkeypatch, payload):
    import httpx
    from voice.tts import GeminiTTSProvider
    monkeypatch.setenv("GEMINI_API_KEY", "test-key")
    provider = GeminiTTSProvider(VoiceConfig(), httpx.MockTransport(lambda r: httpx.Response(200, json=payload)))
    with pytest.raises(RuntimeError):
        await provider.synthesize_async("Hello.")


async def test_gemini_missing_key_does_not_make_a_network_request(monkeypatch):
    import httpx
    from voice.tts import GeminiTTSProvider
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    def unexpected(request): raise AssertionError("Network should not be called")
    with pytest.raises(RuntimeError, match="GEMINI_API_KEY"):
        await GeminiTTSProvider(VoiceConfig(), httpx.MockTransport(unexpected)).synthesize_async("Hello.")


@pytest.mark.parametrize("quota_id,expected", [("SpeechRequestsPerMinute-FreeTier", 90), ("SpeechRequestsPerDay-FreeTier", 3600)])
async def test_gemini_quota_failure_preserves_retry_delay(monkeypatch, quota_id, expected):
    import httpx
    from voice.tts import GeminiTTSProvider, SpeechProviderFailure
    monkeypatch.setenv("GEMINI_API_KEY", "test-key")
    data = {"error": {"details": [
        {"@type": "type.googleapis.com/google.rpc.RetryInfo", "retryDelay": "90s"},
        {"@type": "type.googleapis.com/google.rpc.QuotaFailure", "violations": [{"quotaId": quota_id}]}]}}
    provider = GeminiTTSProvider(VoiceConfig(), httpx.MockTransport(lambda r: httpx.Response(429, json=data)))
    with pytest.raises(SpeechProviderFailure) as raised:
        await provider.synthesize_async("Hello.")
    assert raised.value.cooldown == expected


async def test_gemini_model_fallback_keeps_voice_and_respects_primary_cooldown(monkeypatch):
    import httpx
    import base64
    import json
    from voice.tts import GeminiTTSProvider
    monkeypatch.setenv("GEMINI_API_KEY", "test-key")
    seen = []
    def handle(request):
        seen.append(str(request.url))
        voice = json.loads(request.content)["generationConfig"]["speechConfig"]["voiceConfig"]["prebuiltVoiceConfig"]["voiceName"]
        assert voice == "Algieba"
        if "3.1" in str(request.url):
            return httpx.Response(429, json={"error": {}})
        return httpx.Response(200, json={"candidates": [{"finishReason": "STOP", "content": {"parts": [{
            "inlineData": {"mimeType": "audio/L16;rate=24000", "data": base64.b64encode(bytes(48)).decode()}}]}}]})
    provider = GeminiTTSProvider(VoiceConfig(), httpx.MockTransport(handle))
    await provider.synthesize_async("First reply.")
    await provider.synthesize_async("Second reply.")
    assert provider.last_model == "gemini-2.5-flash-preview-tts"
    assert len(seen) == 3
    assert sum("3.1" in url for url in seen) == 1
