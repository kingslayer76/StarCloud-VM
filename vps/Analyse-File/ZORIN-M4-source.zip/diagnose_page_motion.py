"""Local screenshots and UIA measurements around real controller scrolling."""
import asyncio, json, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from core.config import load_config
from core.state_machine import Cancellation
from brain.schemas import Action
from hands.executor import WindowsExecutor

async def main():
    c=load_config();e=WindowsExecutor(c.automation,c.privacy)
    try:
        obs=await e.observe()
        if obs.get('process','').lower()!='chrome.exe' or 'youtube.com' not in obs.get('browser_url',''):
            raise RuntimeError('Requires YouTube foreground')
        def inspect():
            d=e.desktop;root=d.content_control();r=root.BoundingRectangle
            kinds={};links=[]
            for x in d.walk(root,limit=3000,seconds=3):
                k=x.ControlTypeName;kinds[k]=kinds.get(k,0)+1
                if k=='HyperlinkControl' and len(links)<12:
                    links.append({'name':x.Name[:80],'url':d.control_value(x),'offscreen':x.IsOffscreen})
            return {'root':root.ControlTypeName,'rect':[r.left,r.top,r.right,r.bottom], 'kinds':kinds,'links':links,'cards':len(d.indexed_controls('video')),'pointer':e.input.position()}
        results=[]
        for label,amount in [('before',0),('down',-3),('up',3)]:
            result={}
            if amount:
                outcome=await e.execute(Action(kind='scroll',amount=amount,expected={'kind':'changed'}),Cancellation(),goal='scroll '+label)
                result={'success':outcome.success,'summary':outcome.summary}
            result.update(await e.call(inspect));result['stage']=label
            png,_=await e.capture();Path('data/motion-'+label+'.png').write_bytes(png)
            results.append(result)
        Path('data/page-motion-check.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
        print(json.dumps(results),flush=True)
    finally:
        await e.close()
if __name__=='__main__':asyncio.run(main())
