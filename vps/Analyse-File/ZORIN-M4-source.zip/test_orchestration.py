import asyncio
import pytest
from core.config import Config
from core.orchestrator import Assistant
from hands.executor import Outcome
from brain.schemas import Plan, action


class SilentSpeech:
    speaking = False
    def stop(self): self.speaking = False
    def say(self, text): pass
    async def close(self): pass


class FakeDesktop:
    def __init__(self, fail=False, delay=0):
        self.actions = []
        self.fail, self.delay = fail, delay
    async def observe(self):
        return {"title": "Notepad", "process": "notepad.exe", "fingerprint": "initial", "windows": []}
    async def execute(self, a, token, goal="", approved_fingerprint=None):
        if self.delay:
            await asyncio.sleep(self.delay)
        token.check()
        self.actions.append(a)
        return Outcome(not self.fail, "Expected result missing" if self.fail else "Verified", await self.observe())
    async def close(self): pass


def create(tmp_path, desktop):
    config = Config()
    config.memory.database = str(tmp_path / "assistant.db")
    config.voice.enabled = False
    return Assistant(config, desktop, providers={}, speech=SilentSpeech())


async def test_no_internet_local_multistep(tmp_path):
    desktop = FakeDesktop()
    app = create(tmp_path, desktop)
    try:
        await app.submit("Open Notepad and type: This assistant actually works.")
        await app.task
        assert [a.kind for a in desktop.actions] == ["open_app", "type_text"]
        assert app.last_response == "हो गया।"
    finally:
        await app.close()


async def test_unverified_action_stops_plan(tmp_path):
    desktop = FakeDesktop(fail=True)
    app = create(tmp_path, desktop)
    try:
        await app.submit("Open Notepad and type: hello")
        await app.task
        assert len(desktop.actions) == 1
        assert app.last_response.startswith("Stopped here:")
        assert app.memory.db.execute("SELECT status FROM task_history").fetchone()[0] == "failed"
    finally:
        await app.close()


async def test_interrupt_prevents_remaining_actions(tmp_path):
    desktop = FakeDesktop(delay=.2)
    app = create(tmp_path, desktop)
    try:
        await app.submit("Open Notepad and type: hello")
        await asyncio.sleep(.01)
        await app.submit("Wait, cancel that.")
        await asyncio.sleep(.25)
        assert not desktop.actions
        assert app.state.cancel_requested
    finally:
        await app.close()


async def test_correction_replaces_pending_goal(tmp_path):
    desktop = FakeDesktop(delay=.05)
    app = create(tmp_path, desktop)
    try:
        await app.submit("Open Chrome")
        await asyncio.sleep(.005)
        await app.submit("Actually rehne de, Steam khol.")
        await app.task
        assert [a.target for a in desktop.actions] == ["Steam"]
    finally:
        await app.close()


async def test_no_configured_brain_degrades(tmp_path):
    app = create(tmp_path, FakeDesktop())
    try:
        await app.submit("Explain this complex error")
        await app.task
        assert "App commands" in app.last_response
        await app.submit("Open Notepad")
        await app.task
        assert app.last_response == "हो गया।"
    finally:
        await app.close()


async def test_pending_sensitive_action_cancellation(tmp_path):
    app = create(tmp_path, FakeDesktop())
    try:
        await app.submit("Click Send")
        for _ in range(50):
            if app.gate.pending: break
            await asyncio.sleep(.01)
        assert app.gate.pending
        assert not app.executor.actions
        app.interrupt(silent=True)
        await asyncio.sleep(.01)
        assert not app.executor.actions
    finally:
        await app.close()


async def test_dynamic_planner_reobserves_between_batches(tmp_path):
    desktop = FakeDesktop()
    app = create(tmp_path, desktop)
    calls = []
    async def plan(goal, history, observation, outcomes):
        calls.append(list(outcomes))
        return Plan(actions=[action("open_app", target="Notepad" if not outcomes else "Calculator", expected_kind="window", expected_value="Notepad" if not outcomes else "Calculator")], complete=bool(outcomes))
    app.planner.plan = plan
    try:
        await app.submit("Prepare two applications for work")
        await app.task
        assert len(calls) == 2
        assert calls[1][0]["success"] is True
        assert len(desktop.actions) == 2
    finally:
        await app.close()


async def test_window_change_during_planning_does_not_send_input(tmp_path):
    class ChangingDesktop(FakeDesktop):
        hwnd = 10
        async def observe(self):
            return {**await super().observe(), "hwnd": self.hwnd}
    desktop = ChangingDesktop()
    app = create(tmp_path, desktop)
    async def plan(*args):
        desktop.hwnd = 20
        return Plan(actions=[action("click", target="Settings")])
    app.planner.plan = plan
    try:
        await app.submit("Please find the preferences button")
        await app.task
        assert not desktop.actions
        assert "active window changed" in app.last_response
        assert app.state.outcome == "failed"
    finally:
        await app.close()


async def test_speech_completion_restores_listening(tmp_path):
    from core.state_machine import Phase
    app = create(tmp_path, FakeDesktop())
    queue = app.bus.subscribe()
    worker = asyncio.create_task(app._speech_state(queue))
    try:
        app.bus.emit("speaking_state", speaking=True)
        await asyncio.sleep(0)
        assert app.state.phase == Phase.SPEAKING
        app.bus.emit("speaking_state", speaking=False)
        await asyncio.sleep(0)
        assert app.state.phase == Phase.LISTENING
    finally:
        worker.cancel()
        await asyncio.gather(worker, return_exceptions=True)
        await app.close()


async def test_missing_target_replans_once_and_learns_only_verified_actions(tmp_path):
    class MissingControl(FakeDesktop):
        async def execute(self, a, token, goal="", approved_fingerprint=None):
            self.actions.append(a)
            return Outcome(a.target != "Missing", "LookupError: Missing target" if a.target == "Missing" else "Verified", await self.observe())
    desktop = MissingControl()
    app = create(tmp_path, desktop)
    calls = []
    async def plan(goal, history, observation, outcomes):
        calls.append(list(outcomes))
        return Plan(actions=[action("click", target="Missing" if not outcomes else "Back")])
    app.planner.plan = plan
    try:
        await app.submit("Navigate to the document view")
        await app.task
        assert app.state.outcome == "success"
        assert len(calls) == 2
        assert calls[1][0]["success"] is False
        recipe = app.memory.recipe("Navigate to the document view", replay_only=False)
        assert [step["target"] for step in recipe] == ["Back"]
    finally:
        await app.close()


async def test_delayed_playback_echo_is_ignored_after_speech_finishes(tmp_path):
    import time
    app = create(tmp_path, FakeDesktop())
    app.last_response = "I'm here, boss. Tell me what happened."
    app.last_speech_ended = time.monotonic()
    try:
        await app.submit("Tell me what happened.", source="voice")
        assert app.task is None
        assert not app.history
    finally:
        await app.close()
