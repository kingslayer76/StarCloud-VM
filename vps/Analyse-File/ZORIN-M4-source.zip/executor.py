import asyncio
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from core.state_machine import Cancellation, CancelledAction
from hands.verifier import verify
from safety.risk import assess

APP_PROCESSES = {'chrome':'chrome.exe','google chrome':'chrome.exe','notepad':'notepad.exe',
                 'steam':'steam.exe','downloads':'explorer.exe','obs studio':'obs64.exe'}


@dataclass
class Outcome:
    success: bool
    summary: str
    observation: dict


class WindowsExecutor:
    """A single COM/input thread serializes physical actions across cancellation."""
    def __init__(self, config, privacy):
        self.config, self.privacy = config, privacy
        self.pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="zorin-desktop")
        self.desktop = None
        self.input = None
        from perception.apps import AppCatalogue
        self.catalogue = AppCatalogue()

    def initialize(self):
        if self.desktop is None:
            from perception.windows import Desktop
            from hands.input import Input
            self.desktop = Desktop()
            self.input = Input(self.config.mouse_speed)

    async def call(self, function, *args):
        return await asyncio.get_running_loop().run_in_executor(self.pool, function, *args)

    def _observe(self):
        self.initialize()
        return self.desktop.observe()

    async def observe(self):
        return await self.call(self._observe)

    def _activity(self):
        self.initialize()
        return self.desktop.activity()

    async def activity(self):
        return await self.call(self._activity)

    async def capture(self):
        from perception.screen import capture_window
        return await self.call(capture_window, self.desktop)

    async def shared_frame(self):
        from perception.screen import shared_frame
        def capture():
            self.initialize()
            return shared_frame(self.desktop)
        return await self.call(capture)

    async def execute(self, action, token, goal="", approved_fingerprint=None):
        return await self.call(self._execute, action, token, goal, approved_fingerprint)

    async def execute_visual(self, action, visual, bbox, fingerprint, token, goal, approved=None):
        return await self.call(self._visual, action, visual, bbox, fingerprint, token, goal, approved)

    def _video_at(self, index, token, guard):
        """Count distinct cards from this viewport, retaining overlap while scrolling."""
        from perception.selection import video_key
        seen = []
        previous = None
        for attempt in range(5):
            guard()
            rows = self.desktop.indexed_controls('video')
            guard()
            if not rows and not seen:
                raise LookupError('Video cards are not exposed by accessibility; visual targeting is needed.')
            snapshot = [(video_key(r['url']), tuple(r['rect'])) for r in rows]
            for row in rows:
                key = video_key(row['url'])
                if key not in seen:
                    seen.append(key)
                if len(seen) >= index and key == seen[index-1]:
                    return row
            if not rows or snapshot == previous or attempt == 4:
                break
            previous = snapshot
            # Wheel input goes over an observed card, never the browser toolbar.
            rect = rows[0]['rect']
            self.input.move((rect[0]+rect[2])//2, (rect[1]+rect[3])//2, token)
            guard()
            self.input.scroll(-4, token)
            token.wait(.25)
        raise ValueError(f'Found {len(seen)} distinct video cards from the starting view; could not safely locate number {index}. Name the video or scroll to it.')

    def _focus(self, title, token, process=None):
        try:
            self.desktop.focus_window(title, token, **({'process':process} if process else {}))
        except RuntimeError:
            token.check()
            if self.desktop.secure_desktop():
                raise PermissionError("Cannot focus on a protected desktop")
            # A brief Alt press permits normal foreground activation. Keep input
            # queues separate; AttachThreadInput can hang on an unresponsive app.
            self.input.key("alt", token)
            self.desktop.focus_window(title, token, **({'process':process} if process else {}))
            token.wait(.15)

    def _focus_handle(self, hwnd, token):
        try:
            self.desktop.focus_handle(hwnd, token)
        except RuntimeError:
            token.check()
            if self.desktop.secure_desktop():
                raise PermissionError('Cannot focus on a protected desktop')
            self.input.key('alt', token)
            self.desktop.focus_handle(hwnd, token)

    def _visual(self, action, visual, bbox, fingerprint, token, goal, approved):
        token.check()
        before = self.desktop.observe()
        if before["fingerprint"] != fingerprint:
            return Outcome(False, "Screen changed after vision; target must be located again", before)
        if visual._reference_png is not None:
            from perception.screen import capture_window, same_visual_frame
            current, current_bbox=capture_window(self.desktop)
            if tuple(current_bbox)!=tuple(bbox) or not same_visual_frame(visual._reference_png,current):
                return Outcome(False,'Visible screen changed while vision was locating the target; no click was sent.',before)
        decision = assess(action, before, goal)
        if decision.mode == "deny" or decision.mode == "confirm" and approved != fingerprint:
            return Outcome(False, "Visual action needs current authorization", before)
        if action.kind not in {"click", "double_click", "right_click", "hover"} or not visual.found or visual.confidence < .85:
            return Outcome(False, "No sufficiently confident visual target", before)
        x = round(bbox[0] + visual.x * (bbox[2] - bbox[0] - 1))
        y = round(bbox[1] + visual.y * (bbox[3] - bbox[1] - 1))
        self.input.move(x, y, token)
        token.check()
        if self.desktop.secure_desktop() or self.desktop.user32.GetForegroundWindow() != before["hwnd"]:
            return Outcome(False, "Window focus changed before visual input", before)
        if action.kind != "hover":
            self.input.click(token, "right" if action.kind == "right_click" else "left", 2 if action.kind == "double_click" else 1)
        return self._wait_verified(action, token, before, {"cursor_reached": self.input.position() == (x, y),
            'visual_video': action.expected.kind=='url_changed' and action.amount>0})

    def _execute(self, action, token, goal, approved_fingerprint):
        self.initialize()
        token.check()
        before = self.desktop.observe()
        decision = assess(action, before, goal)
        if decision.mode == "deny":
            return Outcome(False, decision.reason, before)
        if decision.mode == "confirm" and approved_fingerprint != before["fingerprint"]:
            return Outcome(False, "Confirmation required or screen changed since approval", before)
        evidence = {}
        original_hwnd = before.get("hwnd")

        def guard():
            token.check()
            if self.desktop.secure_desktop() or self.desktop.user32.GetForegroundWindow() != original_hwnd:
                raise RuntimeError("Focus changed; stopped before further input")
            focus = self.desktop.auto.GetFocusedControl()
            if focus and focus.IsPassword:
                raise PermissionError("Password field became focused")

        try:
            if action.kind == "open_app":
                # An existing matching window is focused; otherwise use visible Start search.
                app_process = APP_PROCESSES.get(action.target.casefold())
                matches = [w for w in before.get("windows", []) if action.expected.value.casefold() in w["title"].casefold()
                           and (not app_process or w.get('process', app_process).casefold() == app_process)]
                active_app = app_process and before.get('process', '').casefold() == app_process and any(w.get('hwnd') == before.get('hwnd') for w in matches)
                if active_app:
                    evidence["strategy"] = "current application window"
                elif len(matches) == 1:
                    try:
                        self._focus(action.expected.value, token, app_process)
                    except RuntimeError:
                        registered_app=self.catalogue.resolve(action.target)
                        if not registered_app:
                            raise
                        token.check()
                        self.catalogue.launch_registered(registered_app)
                        evidence['strategy']='Windows registered application activation'
                elif len(matches) > 1:
                    if not app_process:
                        raise LookupError("Multiple matching windows; specify which one")
                    # Opening an app can reuse its topmost existing window. Exact
                    # document/window selection still uses focus_window's ambiguity check.
                    try:
                        self._focus_handle(matches[0]['hwnd'], token)
                        evidence['strategy'] = 'topmost existing application window'
                    except RuntimeError:
                        registered_app=self.catalogue.resolve(action.target)
                        if not registered_app:
                            raise
                        token.check()
                        self.catalogue.launch_registered(registered_app)
                        evidence['strategy']='Windows registered application activation'
                else:
                    registered_app = self.catalogue.resolve(action.target)
                    if registered_app:
                        token.check()
                        self.catalogue.launch_registered(registered_app)
                        evidence['strategy'] = 'Windows registered application activation'
                        return self._wait_verified(action, token, before, evidence)
                    known_names = {alias.search.casefold() for alias in self.config.app_aliases.values()}
                    if not registered_app and action.target.casefold() not in known_names:
                        raise ValueError("This is not an identified installed application. Interpret the task or name an installed app; do not search the whole request in Start.")
                    self.input.key("win+s", token)
                    deadline = time.monotonic() + 4
                    search_state = self.desktop.observe()
                    while search_state.get("process", "").casefold() not in {"searchhost.exe", "searchapp.exe", "startmenuexperiencehost.exe"}:
                        if time.monotonic() > deadline:
                            if registered_app:
                                token.check()
                                self.catalogue.launch_registered(registered_app)
                                evidence["strategy"] = "registered app activation after Search focus failure"
                                break
                            raise RuntimeError("Windows Search did not gain focus; no text was typed")
                        token.wait(.15)
                        search_state = self.desktop.observe()
                    if evidence.get("strategy"):
                        return self._wait_verified(action, token, before, evidence)
                    search_hwnd = search_state["hwnd"]
                    def search_guard():
                        token.check()
                        if self.desktop.secure_desktop() or self.desktop.user32.GetForegroundWindow() != search_hwnd:
                            raise RuntimeError("Search lost focus; launch stopped")
                    self.input.key("ctrl+a", token)
                    self.input.type_text(action.target, token, search_guard)
                    deadline = time.monotonic() + 5
                    result = None
                    while time.monotonic() < deadline:
                        search_guard()
                        search_state = self.desktop.observe()
                        candidates = [e for e in search_state.get("elements", [])
                                      if action.target.casefold() in e["name"].casefold()
                                      and e["type"] in {"ListItemControl", "ButtonControl", "HyperlinkControl"}
                                      and e["enabled"]]
                        if candidates:
                            # The app result must be observed separately from the query edit box.
                            result = candidates[0]
                            break
                        token.wait(.2)
                    if not result:
                        if not registered_app:
                            raise LookupError("No identifiable result and app name is not uniquely registered in Windows")
                        # Some Search WebViews expose no children. The query is restricted to
                        # an exact installed application; keyboard activation is then verified by window.
                        search_guard()
                        self.input.key("enter", token)
                        evidence["strategy"] = "registered-app keyboard fallback"
                    else:
                        search_guard()
                        rect = result["rect"]
                        self.input.move((rect[0]+rect[2])//2, (rect[1]+rect[3])//2, token)
                        search_guard()
                        self.input.click(token)
            elif action.kind == "navigate":
                if before.get('process', '').casefold() != 'chrome.exe':
                    raise RuntimeError('Bring Chrome to the foreground before browser navigation.')
                guard()
                self.input.key('ctrl+l', token)
                deadline = time.monotonic()+2
                address = self.desktop.auto.GetFocusedControl()
                while not address or address.Name != 'Address and search bar':
                    guard()
                    if time.monotonic() >= deadline:
                        raise RuntimeError('Chrome address bar did not gain focus; no URL was typed.')
                    token.wait(.05)
                    address = self.desktop.auto.GetFocusedControl()
                def address_guard():
                    guard()
                    current = self.desktop.auto.GetFocusedControl()
                    if not current or current.Name != 'Address and search bar':
                        raise RuntimeError('Address bar lost focus; navigation stopped.')
                address_guard()
                self.input.key('ctrl+a', token)
                self.input.type_text(action.target, token, address_guard)
                address_guard()
                # Chrome may append a SELECTED history-completion suffix. Delete
                # removes that suffix; at the end of exact input it does nothing.
                # Do not accept or navigate to the browser's suggested old URL.
                self.input.key('delete', token)
                address_guard()
                # Chrome can replace the edit accessibility object while typing.
                # Read the current focused edit and allow its value to settle;
                # never press Enter based on the stale pre-typing object.
                settle=time.monotonic()+.8
                while self.desktop.control_value(self.desktop.auto.GetFocusedControl()) != action.target:
                    address_guard()
                    if time.monotonic()>=settle:
                        raise RuntimeError('The address was not replaced exactly; Enter was not pressed.')
                    token.wait(.05)
                address_guard()
                self.input.key('enter', token)
            elif action.kind == "click_index":
                selected = (self._video_at(action.amount, token, guard) if action.target == 'video'
                            else self.desktop.locate_index(action.target, action.amount))
                control = selected['control']
                named_action = action.model_copy(update={'kind': 'click', 'target': selected['name'] or action.target})
                selected_decision = assess(named_action, before, goal)
                if selected_decision.mode == 'deny' or selected_decision.mode == 'confirm' and approved_fingerprint != before['fingerprint']:
                    return Outcome(False, "The selected control requires review; ask for it by name: "+named_action.target, before)
                rect = selected['rect']
                guard()
                self.input.move((rect[0]+rect[2])//2, (rect[1]+rect[3])//2, token)
                guard()
                fresh = control.BoundingRectangle
                if control.IsOffscreen or not control.IsEnabled or [fresh.left, fresh.top, fresh.right, fresh.bottom] != rect:
                    raise RuntimeError("The selected item moved before the click. Stopped without clicking.")
                self.input.click(token)
                evidence['target_url'] = selected.get('url', '')
                evidence['strategy'] = f"visible {action.target} {action.amount}: {selected['name'][:100]}"
            elif action.kind == "focus_window":
                self._focus(action.target, token)
            elif action.kind in {"click", "double_click", "right_click", "hover", "drag"}:
                control = self.desktop.locate(action.target)
                rect = control.BoundingRectangle
                x, y = (rect.left + rect.right)//2, (rect.top + rect.bottom)//2
                guard()
                self.input.move(x, y, token)
                guard()
                if action.kind == "drag":
                    end = self.desktop.locate(action.destination).BoundingRectangle
                    self.input.button("left")
                    try:
                        self.input.move((end.left+end.right)//2, (end.top+end.bottom)//2, token)
                    finally:
                        self.input.button("left", up=True)
                elif action.kind != "hover":
                    self.input.click(token, "right" if action.kind == "right_click" else "left", 2 if action.kind == "double_click" else 1)
                evidence["cursor_reached"] = self.input.position() == (x, y)
            elif action.kind == "type_text":
                if action.target:
                    control = self.desktop.locate(action.target)
                    rect = control.BoundingRectangle
                    self.input.move((rect.left+rect.right)//2, (rect.top+rect.bottom)//2, token)
                    self.input.click(token)
                    token.wait(.1)
                guard()
                if action.target == 'Address and search bar':
                    # Clicking the omnibox collapses Ctrl+L's selection. Always
                    # replace its whole value; never append a URL to the old one.
                    self.input.key('ctrl+a', token)
                    guard()
                    evidence['replace_address'] = True
                focus = self.desktop.auto.GetFocusedControl()
                if not focus or focus.IsPassword or focus.ControlTypeName not in {"EditControl", "DocumentControl"}:
                    raise RuntimeError("No verified editable document/text field has focus")
                self.input.type_text(action.text, token, guard)
            elif action.kind == "key":
                guard()
                volume = None
                if action.text.lower() == "volume_mute":
                    from pycaw.pycaw import AudioUtilities
                    volume = AudioUtilities.GetSpeakers().EndpointVolume
                    old_mute = bool(volume.GetMute())
                self.input.key(action.text, token)
                if volume:
                    token.wait(.08)
                    evidence["media_changed"] = bool(volume.GetMute()) != old_mute
            elif action.kind == "scroll":
                guard()
                from perception.screen import scroll_sample, scrolled, anchors_scrolled
                content=self.desktop.content_control()
                anchors=self.desktop.scroll_anchors(content)
                rect=content.BoundingRectangle
                bbox=(rect.left,rect.top,rect.right,rect.bottom)
                sample=scroll_sample(bbox)
                self.input.move((rect.left+rect.right)//2,(rect.top+rect.bottom)//2,token)
                guard()
                self.input.scroll(action.amount, token)
                deadline=time.monotonic()+2
                moved=False
                while time.monotonic()<deadline:
                    token.wait(.15)
                    guard()
                    if scrolled(sample,scroll_sample(bbox),action.amount):
                        moved=True
                        break
                if not moved:
                    guard()
                    moved=anchors_scrolled(anchors,self.desktop.scroll_anchors(content),action.amount)
                if not moved:
                    # Some web panels swallow wheel input. A focused page can
                    # use Page Up/Down without clicking a video or editable field.
                    guard()
                    try:
                        content.SetFocus()
                        focus=self.desktop.auto.GetFocusedControl()
                        if focus and focus.ControlTypeName=='DocumentControl' and not focus.IsPassword:
                            sample=scroll_sample(bbox)
                            anchors=self.desktop.scroll_anchors(content)
                            guard()
                            self.input.key('pagedown' if action.amount<0 else 'pageup',token)
                            token.wait(.35)
                            guard()
                            moved=scrolled(sample,scroll_sample(bbox),action.amount) or anchors_scrolled(anchors,self.desktop.scroll_anchors(content),action.amount)
                    except (LookupError, AttributeError):
                        pass
                return Outcome(moved,'Verified page scroll' if moved else 'No page scroll could be verified; the page may be at its boundary or the pointer may be over a non-scrolling panel.',self.desktop.observe())
            elif action.kind == "volume":
                from pycaw.pycaw import AudioUtilities
                volume = AudioUtilities.GetSpeakers().EndpointVolume
                volume.SetMasterVolumeLevelScalar(action.amount / 100, None)
                evidence["volume"] = round(volume.GetMasterVolumeLevelScalar()*100)
            elif action.kind == "screenshot":
                from perception.screen import capture_window
                blob, _ = capture_window(self.desktop)
                evidence["capture_bytes"] = len(blob)
                if self.privacy.save_screenshots:
                    from core.config import ROOT
                    path = ROOT / "data" / "screenshots"
                    path.mkdir(parents=True, exist_ok=True)
                    (path / f"capture-{time.time_ns()}.png").write_bytes(blob)
            elif action.kind == "wait":
                token.wait(.1)
            return self._wait_verified(action, token, before, evidence)
        except CancelledAction:
            raise
        except Exception as error:
            try:
                after = self.desktop.observe()
            except Exception:
                after = before
            return Outcome(False, f"{type(error).__name__}: {error}", after)

    def _wait_verified(self, action, token, before, evidence):
        deadline = time.monotonic() + action.timeout
        after = before
        def verified():
            result = verify(action.expected, before, after, evidence)
            if action.kind in {"open_app", "focus_window"}:
                title = action.expected.value or action.target
                result = result and title.casefold() in after.get("title", "").casefold()
                app_process = APP_PROCESSES.get(action.target.casefold())
                if app_process:
                    result = result and after.get('process', '').casefold() == app_process
            return result
        ok = False
        activation_focus_attempted = False
        while True:
            token.check()
            try:
                after = self.desktop.observe()
            except Exception as error:
                # Browser navigation can invalidate accessibility objects after
                # Enter has already been delivered. Retry only the observation;
                # never repeat the input or treat the old screen as verification.
                if type(error).__name__ != "COMError":
                    raise
                if time.monotonic() >= deadline:
                    break
                token.wait(.2)
                continue
            if after.get("secure_desktop") or after.get("password_focused"):
                return Outcome(False, "Protected interface appeared during verification", after)
            ok = verified()
            if not ok and action.kind == 'open_app' and evidence.get('strategy') == 'Windows registered application activation' and not activation_focus_attempted:
                app_process = APP_PROCESSES.get(action.target.casefold())
                candidates = [w for w in after.get('windows', []) if action.expected.value.casefold() in w['title'].casefold()
                              and (not app_process or w.get('process','').casefold() == app_process)]
                if candidates and (app_process or len(candidates) == 1):
                    activation_focus_attempted = True
                    self._focus_handle(candidates[0]['hwnd'], token)
                    continue
            if ok or time.monotonic() >= deadline:
                break
            token.wait(.2)
        strategy = f" ({evidence['strategy']})" if evidence.get("strategy") else ""
        return Outcome(ok, "Verified " + action.kind + strategy if ok else "Action was attempted but its expected result could not be verified", after)

    async def close(self):
        if self.desktop:
            await self.call(self.desktop.close)
        self.pool.shutdown(wait=False, cancel_futures=True)
