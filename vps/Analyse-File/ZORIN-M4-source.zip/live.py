"""Gemini Live native audio transport: 16 kHz in, uninterrupted 24 kHz out.

No browser UI, synthetic success acknowledgements, microphone recordings or secrets
in URLs. All callbacks run on the event loop except the bounded audio buffers.
"""
import asyncio
import base64
from collections import deque
import json
import os
import threading
import time

from safety.secrets import redact
from voice.live_gate import LiveSpeechGate
from voice.commands import voice_command

ENDPOINT = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"


class PCMOutput:
    """One persistent device stream, not one stream per model audio packet."""
    def __init__(self, device=None):
        self.device = device
        self.pending = deque()
        self.lock = threading.Lock()
        self.samples = 0
        self.started = False
        self.complete = False
        self.stream = None
        self.first_played_at = None
        self.underruns = 0

    @property
    def speaking(self):
        return self.samples > 0

    def push(self, data):
        if len(data) % 2:
            raise ValueError("Invalid PCM16 packet")
        with self.lock:
            if self.samples + len(data)//2 > 24000*60:
                raise ValueError("Live playback buffer exceeded 60 seconds")
            self.pending.append(bytes(data))
            self.samples += len(data)//2
            self.complete = False

    def finish(self):
        with self.lock:
            self.complete = True

    def clear(self):
        with self.lock:
            self.pending.clear()
            self.samples = 0
            self.started = False
            self.complete = False

    def read(self, frames):
        with self.lock:
            if not self.started:
                if self.samples < 24000//5 and not self.complete:
                    return bytes(frames*2)
                self.started = bool(self.samples)
            take = min(self.samples, frames)
            chunks = []
            remaining = take*2
            while remaining:
                part = self.pending.popleft()
                chunks.append(part[:remaining])
                if len(part) > remaining:
                    self.pending.appendleft(part[remaining:])
                remaining -= len(chunks[-1])
            self.samples -= take
            if take and self.first_played_at is None:
                self.first_played_at = time.monotonic()
            if take < frames and self.started and not self.complete:
                self.underruns += 1
                self.started = False  # Rebuffer after a network stall.
            if not self.samples and self.complete:
                self.started = False
            return b"".join(chunks) + bytes((frames-take)*2)

    def open(self):
        import sounddevice as sd
        def callback(outdata, frames, timing, status):
            outdata[:] = self.read(frames)
        self.stream = sd.RawOutputStream(samplerate=24000, channels=1, dtype="int16",
                                        blocksize=480, latency="low", device=self.device, callback=callback)
        self.stream.start()

    def close(self):
        if self.stream:
            self.stream.stop()
            self.stream.close()
            self.stream = None
        self.clear()


class LiveVoice:
    def __init__(self, config, bus, *, instruction, tools, on_text, on_tool, on_interrupt):
        self.config, self.bus = config, bus
        self.instruction, self.tools = instruction, tools
        self.on_text, self.on_tool, self.on_interrupt = on_text, on_tool, on_interrupt
        self.output = PCMOutput(config.output_device)
        self.socket = None
        self.connected = asyncio.Event()
        self.closed = False
        self.enabled = True
        self.audio = asyncio.Queue(maxsize=20)  # At most two seconds of mic backlog.
        self.tasks = []
        self.calls = {}
        self.seen_calls = set()
        self.resume_handle = None
        self.input_text = ""
        self.output_text = ""
        self.last_spoken_text = ""
        self.generating = False
        self.suppress_output = False
        self.last_voice_at = -1e12
        self.last_turn_at = time.monotonic()
        self.last_send_at = None
        self.transcribing = False
        self.capture = None
        self.epoch = 0
        self.connection_epoch = 0
        self.capture_frames = 0
        self.gate = LiveSpeechGate(config)
        self.activity_open = False
        self.awaiting_until = 0.
        self.echo_until = 0.
        self.interruption_task = None
        self.interruption_stt = None
        self.accepted_interruptions = 0
        self.rejected_interruptions = 0

    @property
    def speaking(self):
        return self.output.speaking or self.generating

    def setup(self):
        value = {
            "model": "models/"+self.config.live_model,
            "generationConfig": {"responseModalities": ["AUDIO"],
                "speechConfig": {"voiceConfig": {"prebuiltVoiceConfig": {"voiceName": self.config.live_voice}}},
                "thinkingConfig": {"thinkingLevel": "MINIMAL"}},
            "systemInstruction": {"parts": [{"text": self.instruction()}]},
            "tools": self.tools,
            "inputAudioTranscription": {}, "outputAudioTranscription": {},
            "realtimeInputConfig": {"automaticActivityDetection": {"disabled": True}},
            "sessionResumption": {"handle": self.resume_handle} if self.resume_handle else {},
            "contextWindowCompression": {"slidingWindow": {}},
        }
        return {"setup": value}

    async def start(self, microphone=True, playback=True):
        if not os.getenv("GEMINI_API_KEY"):
            raise RuntimeError("GEMINI_API_KEY is missing from .env")
        if playback:
            self.output.open()
        self.tasks = [asyncio.create_task(self._connection()), asyncio.create_task(self._send_audio())]
        await asyncio.wait_for(self.connected.wait(), 20)
        if microphone:
            import sounddevice as sd
            loop = asyncio.get_running_loop()
            def callback(data, frames, timing, status):
                epoch = self.epoch
                if self.enabled and self.connected.is_set() and not self.closed:
                    loop.call_soon_threadsafe(self._enqueue, bytes(data), epoch)
            try:
                self.capture = sd.RawInputStream(samplerate=16000, blocksize=1600, channels=1,
                                                dtype="int16", device=self.config.input_device, callback=callback)
                self.capture.start()
            except Exception as error:
                # A saved endpoint can disappear or be held by another app after
                # Windows audio devices are re-enumerated. Retry the Windows
                # default once so Live voice can still connect and report the
                # microphone problem instead of aborting the whole assistant.
                if self.config.input_device is None:
                    raise
                self.bus.emit("degraded", subsystem="microphone", message="Selected input endpoint unavailable; trying Windows default")
                try:
                    self.capture = sd.RawInputStream(samplerate=16000, blocksize=1600, channels=1,
                                                    dtype="int16", device=None, callback=callback)
                    self.capture.start()
                except Exception:
                    self.capture = None
                    raise error
            self.bus.emit("voice", message="Microphone ON with local noise gate. While I reply, say 'Zorin, ...' or 'stop' to interrupt; interruption candidates use Groq recognition. /mic off pauses capture.")

    def _enqueue(self, frame, epoch):
        if self.closed or not self.enabled or epoch != self.epoch or not self.connected.is_set():
            return
        if self.audio.full():
            self.audio.get_nowait()
        self.capture_frames += 1
        self.audio.put_nowait((epoch, frame))

    def invalidate_pending(self):
        self.epoch += 1
        self.gate.reset()
        if self.interruption_task:
            self.interruption_task.cancel()
        while not self.audio.empty():
            self.audio.get_nowait()

    async def set_mic(self, enabled):
        self.enabled = enabled
        self.invalidate_pending()
        if not enabled and self.connected.is_set() and self.activity_open:
            await self.send({"realtimeInput": {"activityEnd": {}}})
            self.activity_open = False

    async def send(self, message):
        if not self.connected.is_set() or self.socket is None:
            raise ConnectionError("Live voice disconnected; use /reconnect or wait for reconnection")
        await self.socket.send(json.dumps(message))

    async def text(self, text):
        self.last_send_at = time.monotonic()
        self.awaiting_until = time.monotonic()+15
        await self.send({"realtimeInput": {"text": text}})

    async def screen_frame(self, jpeg):
        await self.send({'realtimeInput': {'video': {'data':base64.b64encode(jpeg).decode(), 'mimeType':'image/jpeg'}}})

    def amplify_speech(self, pcm):
        # Applied only after the local gate admits speech, never to gate decisions.
        import numpy as np
        samples=np.frombuffer(pcm,dtype='<i2').astype(np.float32)
        if not len(samples):
            return pcm
        peak=float(np.max(np.abs(samples)))
        gain=min(self.config.live_input_gain,30000/max(1,peak))
        return (samples*gain).clip(-32768,32767).astype('<i2').tobytes()

    async def _send_audio(self):
        while not self.closed:
            epoch, frame = await self.audio.get()
            if epoch != self.epoch or not self.enabled or not self.connected.is_set():
                continue
            try:
                await self.process_microphone(frame, epoch)
            except ConnectionError:
                self.invalidate_pending()
            except Exception as error:
                self.bus.emit("degraded", subsystem="microphone gate", message=redact(str(error))[:200])
                self.invalidate_pending()

    async def process_microphone(self, frame, epoch):
        if self.output.speaking:
            self.echo_until = time.monotonic()+.4
        protected = self.config.live_reply_protection and (
            self.speaking or bool(self.calls) or time.monotonic() < max(self.awaiting_until, self.echo_until))
        for kind, data in self.gate.feed(frame, protected=protected):
            if epoch != self.epoch or not self.enabled:
                return
            if kind == 'start':
                await self.send({"realtimeInput": {"activityStart": {}}})
                self.activity_open = True
                self.last_voice_at = time.monotonic()
            elif kind == 'audio':
                data = self.amplify_speech(data)
                await self.send({"realtimeInput": {"audio": {"data": base64.b64encode(data).decode(), "mimeType": "audio/pcm;rate=16000"}}})
                self.last_voice_at = time.monotonic()
            elif kind == 'end':
                await self.send({"realtimeInput": {"activityEnd": {}}})
                self.activity_open = False
                self.awaiting_until = time.monotonic()+15
                self.last_send_at = time.monotonic()
            elif kind == 'candidate':
                if not self.interruption_task or self.interruption_task.done():
                    self.interruption_task = asyncio.create_task(self._confirm_interruption(data, epoch, self.connection_epoch))

    async def _confirm_interruption(self, pcm, epoch, connection_epoch):
        """Keep speaking until a candidate contains an address or explicit stop."""
        if not os.getenv("GROQ_API_KEY"):
            self.rejected_interruptions += 1
            return
        if self.interruption_stt is None:
            from voice.stt import SpeechToText
            config = self.config.model_copy(update={"stt_provider": "groq", "local_stt_fallback": False,
                                                    "cloud_stt_timeout": 3.})
            self.interruption_stt = SpeechToText(config, self.bus)
        try:
            text = await self.interruption_stt.transcribe(pcm)
            if epoch != self.epoch or connection_epoch != self.connection_epoch or not self.enabled or self.closed:
                return
            admitted = voice_command(text or '', busy=True, speaking=True,
                                     last_reply=self.output_text or self.last_spoken_text)
            if not admitted:
                self.rejected_interruptions += 1
                self.bus.emit("voice_filter", message="Background speech ignored during reply")
                return
            # Do not splice a delayed candidate into a newer, already active utterance.
            if self.activity_open or self.gate.active:
                return
            self.accepted_interruptions += 1
            self.output.clear()
            self.on_interrupt()
            await self.send({"realtimeInput": {"activityStart": {}}})
            self.activity_open = True
            await self.send({"realtimeInput": {"audio": {"data": base64.b64encode(pcm).decode(), "mimeType": "audio/pcm;rate=16000"}}})
            await self.send({"realtimeInput": {"activityEnd": {}}})
            self.activity_open = False
            self.awaiting_until = time.monotonic()+15
        except asyncio.CancelledError:
            raise
        except Exception as error:
            self.bus.emit("degraded", subsystem="interruption check", message=redact(str(error))[:200])

    async def _connection(self):
        from websockets.asyncio.client import connect
        failures = 0
        while not self.closed:
            try:
                async with connect(ENDPOINT, additional_headers={"x-goog-api-key": os.environ["GEMINI_API_KEY"]},
                                   open_timeout=15, max_size=8*1024*1024, ping_interval=20) as socket:
                    self.socket = socket
                    self.connection_epoch += 1
                    await socket.send(json.dumps(self.setup()))
                    first = json.loads(await asyncio.wait_for(socket.recv(), 15))
                    if "setupComplete" not in first:
                        raise RuntimeError("Gemini rejected Live session setup: "+redact(str(first))[:350])
                    failures = 0
                    self.connected.set()
                    self.suppress_output = False
                    self.bus.emit("voice_backend", provider="gemini_live", model=self.config.live_model, voice=self.config.live_voice)
                    async for raw in socket:
                        await self.handle(json.loads(raw))
            except asyncio.CancelledError:
                raise
            except Exception as error:
                failures += 1
                self.bus.emit("degraded", subsystem="Gemini Live", message=redact(str(error))[:350])
            finally:
                self.connected.clear()
                self.socket = None
                self.generating = False
                self.activity_open = False
                self.awaiting_until = self.echo_until = 0.
                self.output.clear()
                self.invalidate_pending()
                self.input_text = self.output_text = ""
                for task in list(self.calls.values()):
                    task.cancel()
                await asyncio.gather(*list(self.calls.values()), return_exceptions=True)
                self.calls.clear()
                self.on_interrupt()
            if not self.closed:
                await asyncio.sleep(min(30, 2**min(failures+1, 5)))

    async def handle(self, message):
        resume = message.get("sessionResumptionUpdate", {})
        if resume.get("resumable") and resume.get("newHandle"):
            self.resume_handle = resume["newHandle"]
        for call_id in message.get("toolCallCancellation", {}).get("ids", []):
            if call_id in self.calls:
                self.calls[call_id].cancel()
        content = message.get("serverContent", {})
        if content.get("interrupted"):
            self.output.clear()
            self.generating = False
            self.output_text = ""
            self.suppress_output = False
            self.awaiting_until = 0.
            self.on_interrupt()
        incoming = content.get("inputTranscription", {})
        if incoming.get("text"):
            self.last_voice_at = time.monotonic()
            self.input_text += incoming["text"]
        if incoming.get("finished"):
            await self._flush_input()
        outgoing = content.get("outputTranscription", {})
        if outgoing.get("text") and not self.suppress_output:
            self.output_text += outgoing["text"]
        for part in content.get("modelTurn", {}).get("parts", []):
            inline = part.get("inlineData", {})
            if inline.get("data") and not self.suppress_output:
                if not inline.get("mimeType", "").startswith("audio/pcm"):
                    continue
                if not self.generating:
                    self.generating = True
                    self.awaiting_until = 0.
                    if self.last_send_at:
                        self.bus.emit("latency", stage="live_first_audio", seconds=round(time.monotonic()-self.last_send_at, 3))
                        self.last_send_at = None
                self.output.push(base64.b64decode(inline["data"], validate=True))
        for call in message.get("toolCall", {}).get("functionCalls", []):
            await self._flush_input()
            cid = call.get("id")
            if cid and cid not in self.seen_calls:
                self.seen_calls.add(cid)
                task = asyncio.create_task(self._tool(call, self.connection_epoch))
                self.calls[cid] = task
        if content.get("turnComplete"):
            await self._flush_input()
            self.output.finish()
            self.generating = False
            self.awaiting_until = 0.
            self.suppress_output = False
            self.last_turn_at = time.monotonic()
            if self.output_text.strip():
                self.last_spoken_text = self.output_text.strip()
                await self.on_text("assistant", self.output_text.strip())
            self.output_text = ""

    async def _flush_input(self):
        if self.input_text.strip():
            text, self.input_text = self.input_text.strip(), ""
            await self.on_text("user", text)

    async def _tool(self, call, epoch):
        try:
            result = await self.on_tool(call.get("name"), call.get("args", {}))
            if epoch == self.connection_epoch and self.connected.is_set():
                await self.send({"toolResponse": {"functionResponses": [{"id": call["id"], "name": call["name"], "response": result}]}})
        except asyncio.CancelledError:
            self.on_interrupt()
            raise
        except Exception as error:
            self.bus.emit("degraded", subsystem="Live tool", message=redact(str(error))[:250])
            if epoch == self.connection_epoch and self.connected.is_set():
                try:
                    await self.send({"toolResponse": {"functionResponses": [{"id": call["id"], "name": call["name"],
                        "response": {"success": False, "status": "failed", "reason": redact(str(error))[:250]}}]}})
                except Exception:
                    pass
        finally:
            self.calls.pop(call["id"], None)

    def stop(self):
        was_active = self.generating or self.output.speaking or bool(self.calls)
        for task in list(self.calls.values()):
            task.cancel()
        self.output.clear()
        self.suppress_output = was_active
        self.output_text = ""
        self.generating = False
        self.awaiting_until = 0.

    async def reconnect(self, forget=False):
        self.stop()
        self.invalidate_pending()
        if forget:
            self.resume_handle = None
        if self.socket:
            await self.socket.close()

    async def close(self):
        self.closed = True
        self.enabled = False
        self.invalidate_pending()
        if self.capture:
            self.capture.stop()
            self.capture.close()
            self.capture = None
        for task in self.tasks:
            task.cancel()
        await asyncio.gather(*self.tasks, return_exceptions=True)
        if self.interruption_task:
            await asyncio.gather(self.interruption_task, return_exceptions=True)
        if self.interruption_stt:
            await self.interruption_stt.close()
        self.output.close()
