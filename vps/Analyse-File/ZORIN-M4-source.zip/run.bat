@echo off
setlocal
cd /d "%~dp0"
title ZORIN-M4 - Voice Assistant
if not exist ".venv\Scripts\python.exe" (
  echo Run powershell -ExecutionPolicy Bypass -File setup.ps1 first.
  exit /b 1
)
echo ZORIN-M4 starts with microphone and spoken replies enabled.
echo Default voice: Gemini Live Puck. Use --cascade for the previous voice pipeline.
echo.
".venv\Scripts\python.exe" -u main.py %*
set "ZORIN_EXIT=%errorlevel%"
if not "%ZORIN_EXIT%"=="0" pause
exit /b %ZORIN_EXIT%
