"""Audition male voices using identical conversational text; no default changes."""
import asyncio
import io
import json
from pathlib import Path
import sys
import time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.config import ROOT, load_config
from core.state_machine import Cancellation
from voice.playback import Playback


async def run():
    import edge_tts
    import soundfile as sf
    playback = Playback(load_config().voice.output_device)
    text = "अच्छा, तो आज भी PC ने तुम्हारा धैर्य टेस्ट किया? चलो, बताओ क्या हुआ, मैं सुन रहा हूँ।"
    variants = [
        ("A", "hi-IN-MadhurNeural", "+8%", "-3Hz"),
        ("B", "en-US-AndrewMultilingualNeural", "+0%", "+0Hz"),
        ("C", "en-US-BrianMultilingualNeural", "+0%", "+0Hz"),
    ]
    records = []
    for label, voice, rate, pitch in variants:
        start = time.monotonic()
        path = ROOT / f"data/voice-candidate-{label}.wav"
        if path.exists():
            audio, sr = sf.read(path, dtype="float32")
        else:
            for attempt in range(2):
                chunks = []
                try:
                    async with asyncio.timeout(20):
                        async for chunk in edge_tts.Communicate(text, voice=voice, rate=rate, pitch=pitch).stream():
                            if chunk["type"] == "audio": chunks.append(chunk["data"])
                    audio, sr = sf.read(io.BytesIO(b"".join(chunks)), dtype="float32")
                    sf.write(path, audio, sr)
                    break
                except Exception as error:
                    print(f"Voice {label}, attempt {attempt+1}: {type(error).__name__}", flush=True)
            else:
                records.append({"label": label, "voice": voice, "failed": True})
                continue
        records.append({"label": label, "voice": voice, "rate": rate, "pitch": pitch,
                        "generation_seconds": round(time.monotonic()-start, 2), "path": str(path)})
        # Announce the label with the already configured English male voice.
        chunks = []
        async with asyncio.timeout(15):
            async for chunk in edge_tts.Communicate(f"Voice {label}.", voice="en-IN-PrabhatNeural").stream():
                if chunk["type"] == "audio": chunks.append(chunk["data"])
        announcement, announcement_rate = sf.read(io.BytesIO(b"".join(chunks)), dtype="float32")
        await playback.play(announcement, announcement_rate, Cancellation())
        await playback.play(audio, sr, Cancellation())
        print(json.dumps(records[-1]), flush=True)
        await asyncio.sleep(.8)
    (ROOT / "data/voice-candidates.json").write_text(json.dumps(records, indent=2), encoding="utf-8")


if __name__ == "__main__":
    asyncio.run(run())
