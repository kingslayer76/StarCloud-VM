import asyncio
from unittest.mock import Mock, AsyncMock
import pytest
from brain.intent import IntentRouter
from brain.schemas import action, Expected
from core.config import Config
from core.state_machine import Cancellation
from core.live_assistant import LiveAssistant
from memory.manager import Memory
from hands.executor import WindowsExecutor
from hands.verifier import verify
from perception.selection import ordered_controls
from persona.companion import ActivityOffer, context_key
from brain.planner import control_context
from voice.commands import voice_command


@pytest.mark.parametrize('spoken', ['Zorin Chrome pe YouTube khol.',
    'Zorin Chrome par YouTube kholo', 'zorin yotube kol', 'chorm pa yotube khole',
    'ज़ोरिन क्रोम पर यूट्यूब खोलो', 'YouTube Chrome pe kholo'])
def test_reported_hinglish_requests_open_the_site_not_the_sentence(spoken):
    memory=Memory(':memory:',enabled=False)
    try:
        plan=IntentRouter(Config().automation,memory).route(voice_command(spoken))
        assert [(a.kind,a.target) for a in plan.actions] == [
            ('open_app','chrome'),('navigate','https://www.youtube.com/')]
    finally:
        memory.close()


def test_reported_hinglish_search_uses_an_encoded_search_url():
    memory=Memory(':memory:',enabled=False)
    try:
        plan=IntentRouter(Config().automation,memory).route(voice_command('Zorin Chrome par YouTube search kar.'))
        assert plan.actions[1].target == 'https://www.google.com/search?q=YouTube'
        assert plan.actions[1].expected.value == plan.actions[1].target
        assert plan.actions[0].target == 'chrome'
        assert IntentRouter(Config().automation,memory).route('Jori new call') is None
    finally:
        memory.close()


def test_search_words_inside_literal_typing_are_not_a_search():
    memory=Memory(':memory:',enabled=False)
    try:
        plan=IntentRouter(Config().automation,memory).route('type: YouTube search kar')
        assert len(plan.actions)==1 and plan.actions[0].kind=='type_text'
        assert plan.actions[0].text=='YouTube search kar'
    finally:
        memory.close()


@pytest.mark.parametrize('text', ['Open YouTube on Chrome', 'open youtube on chrom',
    'Can you please open YouTube in Google Chrome?', 'Chrome mein YouTube kholo',
    'Chrome में यूट्यूब खोलो', 'YouTube Chrome mein kholo', 'open github.com on Chrome'])
def test_browser_qualifier_never_becomes_an_app_search(text):
    memory = Memory(':memory:', enabled=False)
    try:
        plan = IntentRouter(Config().automation, memory).route(text)
        assert plan.actions[0].target == 'chrome'
        assert plan.actions[-1].expected.kind == 'url'
        assert plan.actions[1].target.startswith('https://')
        assert 'on Chrome' not in plan.actions[0].target
    finally:
        memory.close()


@pytest.mark.parametrize('text,number', [('click on the fourth video', 4), ('open video 5', 5),
                                      ('play the 1st video', 1), ('पहला वीडियो खोलो', 1)])
def test_ordinal_request_is_a_fresh_visible_selection(text, number):
    memory = Memory(':memory:', enabled=False)
    try:
        plan = IntentRouter(Config().automation, memory).route(text)
        item = plan.actions[0]
        assert item.kind == 'click_index' and item.amount == number and item.target == 'video'
    finally:
        memory.close()


def row(name, x, y, url, typ='HyperlinkControl'):
    return {'name':name, 'rect':[x,y,x+100,y+80], 'url':url, 'type':typ, 'enabled':True}


def test_video_order_excludes_navigation_and_deduplicates_thumbnail_title():
    base='https://www.youtube.com/watch?v='
    rows=[row('second',200,99,base+'b'), row('first',10,100,base+'a'),
          row('first title',10,190,base+'a'), row('third',10,300,base+'c'),
          row('subscribe',0,0,'https://www.youtube.com/channel/one'),
          row('external fake',0,0,'https://youtube.com.evil.test/watch?v=bad')]
    assert [r['name'] for r in ordered_controls(rows,'video')] == ['first','second','third']


def test_a_typed_url_or_an_old_youtube_window_does_not_verify_navigation():
    exp=Expected(kind='url',value='https://www.youtube.com/')
    assert not verify(exp,{}, {'browser_url':'https://www.youtube.com/','focus':'Address and search bar'})
    assert not verify(exp,{}, {'browser_url':'https://google.com/','windows':[{'title':'YouTube'}]})
    assert verify(exp,{}, {'browser_url':'youtube.com','focus':'YouTube'})
    assert not verify(exp,{}, {'browser_url':'https://youtube.com.evil.test/','focus':'page'})


def test_appended_address_is_not_successful_typing():
    exp=Expected(kind='text',value='https://www.youtube.com/')
    assert not verify(exp,{}, {'browser_url':'https://old.test/https://www.youtube.com/',
                              'focused_text':'https://old.test/https://www.youtube.com/'}, {'replace_address':True})
    assert verify(exp,{}, {'browser_url':exp.value}, {'replace_address':True})


def test_cloud_labels_omit_typed_fields_documents_and_extra_metadata():
    source={'title':'YouTube','process':'chrome.exe','focused_text':'private draft',
            'browser_url':'https://private.test/','elements':[
                {'name':'private draft','type':'EditControl','value':'private draft'},
                {'name':'private typed selection','type':'ComboBoxControl'},
                {'name':'private page body','type':'DocumentControl'},
                {'name':'Settings','type':'ButtonControl','rect':[1,2,3,4],'value':'hidden'}]}
    result=control_context(source)
    assert result['elements'] == [{'name':'Settings','type':'ButtonControl','rect':[1,2,3,4]}]
    assert 'private' not in str(result) and 'hidden' not in str(result)
    assert control_context({**source,'password_focused':True}) == {'protected_interface':True}


def test_open_existing_chrome_does_not_refresh_installed_apps():
    c=Config()
    e=WindowsExecutor(c.automation,c.privacy)
    before={'hwnd':1,'title':'YouTube - Google Chrome','process':'chrome.exe','fingerprint':'one',
            'windows':[{'hwnd':1,'title':'YouTube - Google Chrome'}]}
    e.desktop=Mock(observe=Mock(return_value=before))
    e.input=Mock()
    e.catalogue=Mock()
    try:
        result=e._execute(action('open_app',target='Google Chrome',expected_kind='window',expected_value='Google Chrome'),Cancellation(),'Open Chrome',None)
        assert result.success
        e.catalogue.resolve.assert_not_called()
        e.input.key.assert_not_called()
    finally:
        e.pool.shutdown(wait=False)


def test_web_result_title_is_not_an_existing_chrome_app():
    c=Config(); e=WindowsExecutor(c.automation,c.privacy)
    before={'hwnd':1,'title':'Google Chrome - Search - Edge','process':'msedge.exe','fingerprint':'one',
            'windows':[{'hwnd':1,'title':'Google Chrome - Search - Edge','process':'msedge.exe'}]}
    after={'hwnd':2,'title':'New Tab - Google Chrome','process':'chrome.exe','fingerprint':'two',
           'windows':[{'hwnd':2,'title':'New Tab - Google Chrome','process':'chrome.exe'}]}
    app={'Name':'Google Chrome','AppID':'Chrome'}
    e.desktop=Mock(observe=Mock(side_effect=[before,after]))
    e.catalogue=Mock(resolve=Mock(return_value=app)); e.input=Mock()
    try:
        result=e._execute(action('open_app',target='Google Chrome',expected_kind='window',expected_value='Google Chrome'),Cancellation(),'Open Chrome',None)
        assert result.success
        e.catalogue.launch_registered.assert_called_once_with(app)
        e.desktop.focus_window.assert_not_called()
        e.input.key.assert_not_called()
    finally:
        e.pool.shutdown(wait=False)


def test_launch_verification_rejects_the_wrong_process_even_with_matching_title():
    c=Config(); e=WindowsExecutor(c.automation,c.privacy)
    fake={'title':'Google Chrome - Search','process':'msedge.exe','windows':[{'title':'Google Chrome - Search'}]}
    e.desktop=Mock(observe=Mock(return_value=fake))
    try:
        result=e._wait_verified(action('open_app',target='Google Chrome',expected_kind='window',expected_value='Google Chrome',timeout=.1),Cancellation(),fake,{})
        assert not result.success
    finally:
        e.pool.shutdown(wait=False)


def test_registered_app_left_in_background_is_focused_once_before_success():
    c=Config(); e=WindowsExecutor(c.automation,c.privacy)
    windows=[{'hwnd':2,'title':'Untitled - Notepad','process':'Notepad.exe'}]
    before={'hwnd':1,'title':'Chrome','process':'chrome.exe','windows':windows}
    after={'hwnd':2,'title':'Untitled - Notepad','process':'Notepad.exe','windows':windows}
    e.desktop=Mock(observe=Mock(side_effect=[before,after]))
    e.input=Mock()
    try:
        result=e._wait_verified(action('open_app',target='Notepad',expected_kind='window',expected_value='Notepad'),Cancellation(),before,{'strategy':'Windows registered application activation'})
        assert result.success
        e.desktop.focus_handle.assert_called_once()
        assert e.desktop.focus_handle.call_args.args[0]==2
    finally:
        e.pool.shutdown(wait=False)


def test_video_scrolling_counts_overlap_once_and_returns_fresh_target():
    c=Config(); e=WindowsExecutor(c.automation,c.privacy)
    base='https://www.youtube.com/watch?v='
    first=[row('one',0,100,base+'a'),row('two',200,100,base+'b'),row('three',400,100,base+'c')]
    second=[row('three',400,0,base+'c'),row('four',0,300,base+'d'),row('five',200,300,base+'e')]
    e.desktop=Mock(indexed_controls=Mock(side_effect=[first,second]))
    e.input=Mock(); token=Mock(); guard=Mock()
    try:
        assert e._video_at(4,token,guard) is second[1]
        e.input.scroll.assert_called_once_with(-4,token)
        e.input.click.assert_not_called()
        assert guard.call_count >= 4
    finally:
        e.pool.shutdown(wait=False)


def test_video_scroll_stops_when_view_does_not_move():
    c=Config(); e=WindowsExecutor(c.automation,c.privacy)
    e.desktop=Mock(indexed_controls=Mock(return_value=[row('one',0,100,'https://youtube.com/watch?v=a')]))
    e.input=Mock()
    try:
        with pytest.raises(ValueError,match='could not safely locate'):
            e._video_at(4,Mock(),Mock())
        assert e.input.scroll.call_count == 1
        e.input.click.assert_not_called()
    finally:
        e.pool.shutdown(wait=False)


def test_navigation_never_submits_an_appended_address():
    c=Config(); e=WindowsExecutor(c.automation,c.privacy)
    before={'hwnd':1,'title':'YouTube - Google Chrome','process':'chrome.exe','fingerprint':'one'}
    focus=Mock(IsPassword=False); focus.Name='Address and search bar'
    e.desktop=Mock(observe=Mock(return_value=before),secure_desktop=Mock(return_value=False),
                   control_value=Mock(return_value='https://old.test/https://www.youtube.com/'))
    e.desktop.user32.GetForegroundWindow.return_value=1
    e.desktop.auto.GetFocusedControl.return_value=focus
    e.input=Mock()
    try:
        a=action('navigate',target='https://www.youtube.com/',expected_kind='url',expected_value='https://www.youtube.com/')
        result=e._execute(a,Cancellation(),'Open YouTube on Chrome',None)
        assert not result.success and 'Enter was not pressed' in result.summary
        assert [call.args[0] for call in e.input.key.call_args_list] == ['ctrl+l','ctrl+a','delete']
    finally:
        e.pool.shutdown(wait=False)


def test_whole_sentence_cannot_be_typed_into_start_search():
    c=Config();e=WindowsExecutor(c.automation,c.privacy)
    before={'hwnd':1,'title':'Desktop','process':'explorer.exe','fingerprint':'one','windows':[]}
    e.desktop=Mock(observe=Mock(return_value=before))
    e.input=Mock(); e.catalogue=Mock(resolve=Mock(return_value=None))
    try:
        result=e._execute(action('open_app',target='open YouTube on Chrome',expected_kind='window',expected_value='open YouTube on Chrome'),Cancellation(),'Open YouTube on Chrome',None)
        assert not result.success
        e.input.key.assert_not_called()
        e.input.type_text.assert_not_called()
    finally:
        e.pool.shutdown(wait=False)


@pytest.mark.asyncio
async def test_silent_or_stale_activity_decision_never_reaches_puck(tmp_path):
    c=Config();c.memory.database=str(tmp_path/'activity.db')
    desktop=Mock(close=AsyncMock(),activity=AsyncMock(return_value={'title':'YouTube','process':'chrome.exe'}))
    a=LiveAssistant(c,desktop)
    a._busy=Mock(return_value=False)
    a.live.text=AsyncMock()
    context={'title':'YouTube','app':'chrome.exe'}
    offer=ActivityOffer(context_key(context),context)
    try:
        a.companion.generate=AsyncMock(return_value=None)
        await a._consider_activity(offer)
        a.live.text.assert_not_awaited()
        a.companion.generate=AsyncMock(return_value='कुछ देखने का mood है?')
        desktop.activity.return_value={'title':'Notepad','process':'notepad.exe'}
        await a._consider_activity(offer)
        a.live.text.assert_not_awaited()
        desktop.activity.return_value={'title':'YouTube','process':'chrome.exe'}
        await a._consider_activity(offer)
        a.live.text.assert_awaited_once()
    finally:
        await a.close()
