import re
from dataclasses import dataclass
from safety.secrets import sensitive_text

SENSITIVE = re.compile(r"\b(delete|remove|format|purchase|buy|pay|checkout|send|post|publish|submit|transfer|password|security|permission|disable|uninstall|reset account|empty recycle|erase)\b", re.I)
BLOCKED_APP = re.compile(r"\b(powershell|cmd|terminal|command prompt|registry editor|regedit|credential|password manager|windows security|lockapp|consent\.exe)\b", re.I)
ALLOWED_KEYS = {"enter", "escape", "tab", "up", "down", "left", "right", "home", "end", "pageup", "pagedown", "backspace", "delete", "space", "ctrl+l", "ctrl+f", "ctrl+a", "ctrl+s", "ctrl+n", "ctrl+t", "ctrl+shift+n", "alt+f4", "alt+tab", "win+shift+left", "win+shift+right", "volume_mute", "media_play_pause"}


@dataclass(frozen=True)
class Decision:
    mode: str
    reason: str = ""


def assess(action, observation: dict, goal="") -> Decision:
    context = " ".join([observation.get("title", ""), observation.get("process", "")])
    if observation.get("secure_desktop") or observation.get("password_focused"):
        return Decision("deny", "Protected desktop or password field: handle this directly.")
    if (BLOCKED_APP.search(context) and action.kind not in {"open_app", "focus_window", "volume"}) or (action.kind in {"open_app", "focus_window"} and BLOCKED_APP.search(action.target)):
        return Decision("deny", "Terminal, credential and security surfaces are outside Phase 1 automation.")
    if action.kind == "key" and action.text.lower() not in ALLOWED_KEYS:
        return Decision("deny", "This key combination is outside the supported input set.")
    if sensitive_text(action.text):
        return Decision("deny", "Secret entry is handled directly by you.")
    if action.kind == 'navigate' and sensitive_text(action.target):
        return Decision('deny', 'Secret-bearing URLs are handled directly by you.')
    if action.kind == "open_app" and (re.search(r"[\r\n;&|<>/\\:]", action.target) or len(action.target) > 100):
        return Decision("deny", "App search needs an application name, not a command or URL.")
    if action.kind in {"wait", "screenshot", "hover", "focus_window", "volume"}:
        return Decision("allow")
    # Read the observed target's label as well as the model-provided name.
    target = action.target.casefold().strip()
    names = [e.get("name", "") for e in observation.get("elements", [])]
    exact = [name for name in names if target and name.casefold().strip() == target]
    labels = " ".join(exact or [name for name in names if target and target in name.casefold()])
    if action.risk_level == "sensitive" or SENSITIVE.search(action.target + " " + labels):
        return Decision("confirm", "This action may have a sensitive or irreversible consequence.")
    if action.kind == "key" and action.text.lower() in {"delete", "alt+f4", "ctrl+s"}:
        return Decision("confirm", "This may delete, discard, or overwrite existing work.")
    if action.kind in {"click", "click_index", "navigate", "double_click", "key", "type_text", "drag"} and SENSITIVE.search(goal):
        # Allow harmless preparation, confirm the committing input.
        if action.kind != "type_text" or re.search(r"password|security|payment", context, re.I):
            return Decision("confirm", "Review this step before continuing the sensitive task.")
    if action.kind == "key" and action.text.lower() == "enter":
        if re.search(r"discord|whatsapp|slack|telegram|mail|messages|checkout|payment", context, re.I):
            return Decision("confirm", "Enter could send a message or submit a form here.")
    return Decision("allow")
