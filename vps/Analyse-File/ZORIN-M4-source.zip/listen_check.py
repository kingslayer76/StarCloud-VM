"""Timed microphone/STT diagnostic. No desktop execution; audio never saved."""
import asyncio
import argparse
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.config import load_config
from core.events import EventBus
from core.instance import InstanceLease
from voice.stt import SpeechToText
from voice.microphone import Microphone
from voice.tts import SpeechOutput


async def run(seconds=30, device=None, announce=True):
    config = load_config()
    lease = InstanceLease()
    if device is not None:
        config.voice.input_device = int(device) if device.isdecimal() else device
    bus = EventBus()
    events = bus.subscribe()
    stt = SpeechToText(config.voice, bus)
    speech = SpeechOutput(config.voice, bus)
    heard = []
    frames = 0
    max_rms = 0.
    async def on_text(text):
        heard.append(text)
        print("HEARD: " + text, flush=True)
    mic = Microphone(config.voice, stt, bus, on_text, lambda: None)
    original_enqueue = mic._enqueue
    def enqueue(frame):
        nonlocal frames, max_rms
        import numpy as np
        frames += 1
        samples = np.frombuffer(frame, dtype=np.int16).astype(np.float32)
        max_rms = max(max_rms, float(np.sqrt(np.mean(samples*samples))))
        original_enqueue(frame)
    mic._enqueue = enqueue
    try:
        await stt.start()
        if announce:
            speech.say("Microphone test. Say hello Zorin, or Chrome kholo. I will only listen, no actions.")
            await speech.task
        await mic.start()
        await asyncio.wait_for(mic.ready.wait(), 5)
        print(f"LISTENING for {seconds} seconds. Say: Hello Zorin. Chrome kholo.", flush=True)
        for elapsed in range(seconds):
            await asyncio.sleep(1)
            if elapsed % 5 == 4:
                print(f"{elapsed+1}s: peak level={max_rms:.1f}; speech starts={mic.stats['speech_starts']}; utterances={mic.stats['utterances']}; phrases={len(heard)}", flush=True)
        # Finish transcribing a phrase spoken near the end of the test.
        print("Capture ended; finishing the last transcript...", flush=True)
        await mic.finish_capture()
        errors = []
        while not events.empty():
            event = events.get_nowait()
            if event.type == "degraded":
                errors.append(event.data)
        result = {"microphone_frames": frames, "peak_rms": round(max_rms, 1), "transcribed_segments": len(heard),
                  "pipeline": dict(mic.stats), "errors": errors, "audio_saved": False}
        Path("data/listen-check.json").write_text(json.dumps(result, indent=2))
        print(json.dumps(result), flush=True)
        return 0 if frames > 0 and heard else 1
    finally:
        await mic.close()
        await speech.close()
        await stt.close()
        lease.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seconds", type=int, default=30)
    parser.add_argument("--device", help="Input device index or name from main.py --devices")
    parser.add_argument("--no-announcement", action="store_true", help="Start listening without a spoken announcement")
    args = parser.parse_args()
    raise SystemExit(asyncio.run(run(max(5, min(args.seconds, 120)), args.device, not args.no_announcement)))
