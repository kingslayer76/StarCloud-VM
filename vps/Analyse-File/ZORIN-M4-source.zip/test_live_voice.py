import asyncio
import base64
import time
from unittest.mock import AsyncMock, Mock

import pytest

from core.config import Config, VoiceConfig
from core.events import EventBus
from core.live_assistant import LiveAssistant
from voice.live import LiveVoice, PCMOutput
from voice.commands import voice_command


def live():
    return LiveVoice(VoiceConfig(), EventBus(), instruction=lambda: "voice", tools=[],
                     on_text=AsyncMock(), on_tool=AsyncMock(return_value={"success": False}), on_interrupt=Mock())


def test_observed_live_greeting_is_not_part_of_app_name():
    assert voice_command("Hello Soren YouTube kholo.") == "YouTube kholo."
    assert voice_command("Open Soren") == "Open Soren"


def test_pcm_packets_are_contiguous_and_stop_erases_tail():
    output = PCMOutput()
    output.push(b"\x01\x00"*2000)
    output.push(b"\x02\x00"*2000)
    output.finish()
    assert output.read(2400) == b"\x01\x00"*2000+b"\x02\x00"*400
    output.clear()
    assert output.read(2400) == bytes(4800)
    assert output.samples == 0


def test_small_final_audio_plays_and_buffer_has_a_bound():
    output = PCMOutput()
    output.push(b"\x01\x00"*100)
    assert output.read(100) == bytes(200)
    output.finish()
    assert output.read(200) == b"\x01\x00"*100+bytes(200)
    with pytest.raises(ValueError):
        output.push(bytes(24000*61*2))


def test_stop_while_idle_does_not_silence_the_next_reply():
    voice = live()
    voice.stop()
    assert not voice.suppress_output


@pytest.mark.asyncio
async def test_combined_audio_and_transcripts_not_lost():
    voice = live()
    await voice.handle({"serverContent": {
        "inputTranscription": {"text": "YouTube खोलो"},
        "outputTranscription": {"text": "बोलो"},
        "modelTurn": {"parts": [{"inlineData": {"mimeType": "audio/pcm;rate=24000", "data": base64.b64encode(bytes(400)).decode()}}]},
        "turnComplete": True}})
    assert voice.output.samples == 200
    assert voice.on_text.await_args_list[0].args == ("user", "YouTube खोलो")
    assert voice.on_text.await_args_list[1].args == ("assistant", "बोलो")


@pytest.mark.asyncio
async def test_interruption_discards_audio_and_calls_controller():
    voice = live()
    voice.output.push(bytes(200))
    voice.output_text = "unspoken tail"
    await voice.handle({"serverContent": {"interrupted": True}})
    assert voice.output.samples == 0
    assert not voice.output_text
    voice.on_interrupt.assert_called_once()


@pytest.mark.asyncio
async def test_duplicate_tool_does_not_execute_twice_and_waits_for_result():
    voice = live()
    voice.connected.set()
    voice.socket = Mock(send=AsyncMock())
    completed = asyncio.Event()
    async def tool(name, args):
        await completed.wait()
        return {"success": False, "status": "failed"}
    voice.on_tool = AsyncMock(side_effect=tool)
    msg = {"toolCall": {"functionCalls": [{"id": "one", "name": "desktopTask", "args": {}}]}}
    await voice.handle(msg)
    await voice.handle(msg)
    await asyncio.sleep(0)
    voice.socket.send.assert_not_awaited()
    completed.set()
    await asyncio.gather(*list(voice.calls.values()))
    voice.on_tool.assert_awaited_once()
    assert '"success": false' in voice.socket.send.await_args.args[0]


@pytest.mark.asyncio
async def test_muting_invalidates_callback_and_queued_audio():
    voice = live()
    voice.connected.set()
    voice.socket = Mock(send=AsyncMock())
    voice.activity_open = True
    epoch = voice.epoch
    voice._enqueue(bytes(3200), epoch)
    await voice.set_mic(False)
    voice._enqueue(bytes(3200), epoch)
    assert voice.audio.empty()
    assert not voice.enabled
    assert "activityEnd" in voice.socket.send.await_args.args[0]


@pytest.mark.asyncio
async def test_tool_cancel_cancels_pending_operation():
    voice = live()
    voice.connected.set()
    voice.socket = Mock(send=AsyncMock())
    voice.on_tool = AsyncMock(side_effect=lambda *a: None)
    entered = asyncio.Event()
    async def tool(*args):
        entered.set()
        await asyncio.Event().wait()
    voice.on_tool = tool
    await voice.handle({"toolCall": {"functionCalls": [{"id": "one", "name": "desktopTask", "args": {}}]}})
    await entered.wait()
    task = voice.calls["one"]
    await voice.handle({"toolCallCancellation": {"ids": ["one"]}})
    await asyncio.gather(task, return_exceptions=True)
    assert task.cancelled()
    voice.socket.send.assert_not_awaited()
    voice.on_interrupt.assert_called_once()


def make_assistant(tmp_path):
    config = Config()
    config.memory.database = str(tmp_path/'live.db')
    executor = Mock(close=AsyncMock())
    return LiveAssistant(config, executor)


@pytest.mark.asyncio
async def test_conversation_success_is_never_desktop_success(tmp_path):
    assistant=make_assistant(tmp_path)
    try:
        assistant.worker.submit=AsyncMock()
        assistant.background_turn=False
        assistant.last_user_text='Jori new call'
        assistant.last_user_at=time.monotonic()
        assistant.worker.state.outcome='success'
        assistant.worker.state.current_step=0
        assistant.worker.last_response='YouTube is open'
        result=await assistant._tool('desktopTask',{'request':'Open YouTube'})
        assert result['success'] is False
        assert result['status'] == 'needs_clarification'
        assert 'YouTube is open' not in result['detail']
    finally:
        await assistant.close()


@pytest.mark.asyncio
async def test_ambient_title_cannot_execute_and_model_cannot_expand_user_request(tmp_path):
    assistant = make_assistant(tmp_path)
    try:
        assistant.worker.submit = AsyncMock()
        assistant.last_user_text = "Open YouTube"
        assistant.last_user_at = time.monotonic()
        assert not (await assistant._tool("desktopTask", {"request": "delete files"}))["success"]
        assistant.worker.submit.assert_not_awaited()
        assistant.background_turn = False
        assistant.worker.state.outcome = "failed"
        result = await assistant._tool("desktopTask", {"request": "delete files"})
        assistant.worker.submit.assert_awaited_once_with("Open YouTube")
        assert result["success"] is False
        result = await assistant._tool("desktopTask", {"request": "Open YouTube again"})
        assert result["status"] == "already_attempted"
        assistant.worker.submit.assert_awaited_once()
    finally:
        await assistant.close()


@pytest.mark.asyncio
async def test_forget_discards_live_resume_handle_and_context(tmp_path):
    assistant = make_assistant(tmp_path)
    try:
        assistant.memory.record_dialogue("user", "remember my preference")
        assistant.live.resume_handle = "private-session-token"
        assistant.history.append({"role": "user", "content": "private detail"})
        await assistant.forget_memory()
        assert not assistant.memory.recent_dialogue()
        assert not assistant.history
        assert assistant.live.resume_handle is None
        assert "private detail" not in assistant._instruction()
    finally:
        await assistant.close()
