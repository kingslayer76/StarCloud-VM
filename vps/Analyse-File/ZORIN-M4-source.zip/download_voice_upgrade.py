"""Install checksum-pinned upstream Whisper Turbo without removing Whisper small."""
import json
from download_models import ROOT, fetch

REVISION = "5359861c739e955e79d9a303bcbc70fb988958b1"
FILENAME = "ggml-large-v3-turbo-q5_0.bin"
DIGEST = "394221709cd5ad1f40c46e6031ca61bce88931e6e088c188294c6d5a55ffa7e2"


def main():
    fetch(f"https://huggingface.co/ggerganov/whisper.cpp/resolve/{REVISION}/{FILENAME}", ROOT / "models" / FILENAME, DIGEST)
    (ROOT / "models/voice-model-provenance.json").write_text(json.dumps({"repository": "ggerganov/whisper.cpp",
        "revision": REVISION, "file": FILENAME, "sha256": DIGEST}, indent=2))
    print("Verified Whisper Turbo installed; Whisper small retained.", flush=True)


if __name__ == "__main__":
    main()
