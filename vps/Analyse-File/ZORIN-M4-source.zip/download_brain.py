import json
import urllib.request
import zipfile
from download_models import ROOT, fetch, sha256


def main():
    tag = "b10865"
    req = urllib.request.Request(f"https://api.github.com/repos/ggml-org/llama.cpp/releases/tags/{tag}", headers={"User-Agent": "ZORIN-M4"})
    with urllib.request.urlopen(req, timeout=30) as response:
        release = json.load(response)
    name = f"llama-{tag}-bin-win-vulkan-x64.zip"
    asset = next(a for a in release["assets"] if a["name"] == name)
    archive = ROOT / "vendor" / name
    fetch(asset["browser_download_url"], archive, asset["digest"].removeprefix("sha256:"))
    folder = ROOT / "vendor" / "llama"
    folder.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as zipped:
        for info in zipped.infolist():
            if not info.is_dir():
                destination = (folder / info.filename).resolve()
                if not destination.is_relative_to(folder.resolve()):
                    raise ValueError("Unsafe archive member")
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(zipped.read(info))
    # Upstream layout can contain a top-level directory. Keep configured executable path stable.
    servers = list(folder.rglob("llama-server.exe"))
    if len(servers) != 1:
        raise RuntimeError("Expected one llama-server binary")
    if servers[0].parent != folder:
        import shutil
        for item in servers[0].parent.iterdir():
            if item.is_file():
                shutil.copy2(item, folder / item.name)
    from download_chat_brain import main as download_chat, FILENAME, DIGEST
    download_chat()
    (folder / "provenance.json").write_text(json.dumps({"release": tag, "archive_sha256": sha256(archive),
        "model": "Qwen/Qwen3-4B-Instruct-2507", "file": FILENAME, "model_sha256": DIGEST}, indent=2))
    print("Local Qwen brain and Vulkan server installed.", flush=True)


if __name__ == "__main__":
    main()
