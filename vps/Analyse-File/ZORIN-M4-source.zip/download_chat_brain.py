"""Pinned same-size instruction-model update; retains the previous model."""
import json
from download_models import ROOT, fetch

REPOSITORY = "lmstudio-community/Qwen3-4B-Instruct-2507-GGUF"
REVISION = "4edb920b6f14e3b9284d4502a6485103d72cde05"
FILENAME = "Qwen3-4B-Instruct-2507-Q4_K_M.gguf"
DIGEST = "8cdb57cbb880d313736a9bc4e3d3d2485f145b5e19cf33783746e753e82641fc"


def main():
    fetch(f"https://huggingface.co/{REPOSITORY}/resolve/{REVISION}/{FILENAME}", ROOT / "models" / FILENAME, DIGEST)
    (ROOT / "models/chat-model-provenance.json").write_text(json.dumps({
        "upstream": "Qwen/Qwen3-4B-Instruct-2507", "quantization_repository": REPOSITORY,
        "revision": REVISION, "file": FILENAME, "sha256": DIGEST}, indent=2))
    print("Verified instruction model installed; previous model retained.", flush=True)


if __name__ == "__main__":
    main()
