import sys
import time
import psutil


for process in psutil.process_iter(["pid", "name", "create_time"]):
    if process.info["name"].lower() not in {"python.exe", "pythonw.exe"}:
        continue
    try:
        command = process.cmdline()
        own = any("ZORIN-M4" in arg for arg in command)
        diagnostic = "--doctor" in command or "pycaw" in command and "pip" in command
        if own and diagnostic:
            age = time.time() - process.info["create_time"]
            print({"pid": process.pid, "kind": "doctor" if "--doctor" in command else "pycaw-install", "age_seconds": int(age)}, flush=True)
            if "--stop-stale" in sys.argv and age > 120:
                process.terminate()
                print("Terminated stale project diagnostic", flush=True)
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        continue
