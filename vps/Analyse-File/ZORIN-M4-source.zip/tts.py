import asyncio
import base64
import hashlib
import json
from concurrent.futures import ThreadPoolExecutor
import io
import math
import os
import re
import time
import zipfile
from typing import Protocol
import httpx
from core.config import project_path
from core.state_machine import Cancellation, CancelledAction
from voice.playback import Playback


class TTSProvider(Protocol):
    def synthesize(self, text: str): ...


class SpeechProviderFailure(RuntimeError):
    def __init__(self, message, cooldown=60):
        super().__init__(message)
        self.cooldown = cooldown


class PartialSpeechFailure(RuntimeError):
    """Never restart a whole reply after some streamed audio was delivered."""


def contains_hindi(text):
    return bool(re.search(r"[\u0900-\u097f]", text))


class EdgeTTSProvider:
    """Send only the assistant's reply text to the online speech service."""
    def __init__(self, config):
        self.config = config

    async def synthesize_async(self, text):
        import edge_tts
        import soundfile as sf
        voice = self.config.edge_hindi_voice if contains_hindi(text) else self.config.edge_english_voice
        chunks = []
        async with asyncio.timeout(self.config.edge_timeout):
            async for chunk in edge_tts.Communicate(text, voice=voice).stream():
                if chunk["type"] == "audio":
                    chunks.append(chunk["data"])
        if not chunks:
            raise RuntimeError("Speech service returned no audio")
        return sf.read(io.BytesIO(b"".join(chunks)), dtype="float32")


class GoogleTTSProvider:
    """Google Translate speech via gTTS, distinct from Google Cloud/Gemini TTS."""
    def __init__(self, config):
        self.config = config

    def synthesize(self, text):
        from gtts import gTTS
        import soundfile as sf
        buffer = io.BytesIO()
        gTTS(text=text, lang="hi" if contains_hindi(text) else "en", tld=self.config.google_tld,
             slow=False, lang_check=False, timeout=(4, self.config.google_timeout)).write_to_fp(buffer)
        buffer.seek(0)
        return sf.read(buffer, dtype="float32")


class GeminiTTSProvider:
    """Google's expressive speech model; requires the user's own API key."""
    def __init__(self, config, transport=None):
        self.config, self.transport = config, transport
        self.model_cooldowns = {}
        self.last_model = ""
        self.last_attempts = []

    async def stream_async(self, text):
        import numpy as np
        model = self.config.gemini_tts_model
        if model != "gemini-3.1-flash-tts-preview":
            raise RuntimeError("Streaming is only enabled for the verified 3.1 model")
        key = os.getenv("GEMINI_API_KEY", "").strip()
        if not key:
            raise RuntimeError("Set GEMINI_API_KEY locally to use expressive Google speech")
        prompt = ("Generate speech for the TRANSCRIPT only. Read it verbatim in its original language.\n"
                  "DELIVERY: " + self.config.gemini_tts_style + "\n\nTRANSCRIPT:\n" + text)
        body = {"contents": [{"parts": [{"text": prompt}]}], "generationConfig": {"responseModalities": ["AUDIO"],
                "speechConfig": {"voiceConfig": {"prebuiltVoiceConfig": {"voiceName": self.config.gemini_tts_voice}}}}}
        completed = False
        total_samples = 0
        self.last_attempts = []
        try:
            async with asyncio.timeout(self.config.gemini_tts_timeout), httpx.AsyncClient(timeout=self.config.gemini_tts_timeout, transport=self.transport) as client:
                async with client.stream("POST", "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":streamGenerateContent?alt=sse",
                                         headers={"x-goog-api-key": key}, json=body) as response:
                    if response.status_code >= 400:
                        await response.aread()
                        self._check_response(response)
                    async for line in response.aiter_lines():
                        if not line.startswith("data:"):
                            continue
                        data = line[5:].strip()
                        if data == "[DONE]":
                            continue
                        payload = json.loads(data)
                        if "error" in payload:
                            raise RuntimeError("Google speech stream reported an error")
                        candidates = payload.get("candidates", [])
                        if not candidates:
                            continue
                        candidate = candidates[0]
                        finish = candidate.get("finishReason")
                        if finish and finish != "STOP":
                            raise RuntimeError("Google speech stream did not finish (" + str(finish)[:40] + ")")
                        for part in candidate.get("content", {}).get("parts", []):
                            inline = part.get("inlineData")
                            if not inline:
                                continue
                            samples = self._decode_audio(inline)
                            total_samples += len(samples)
                            if total_samples > 24000*180:
                                raise RuntimeError("Speech exceeded the bounded reply duration")
                            if len(samples):
                                self.last_model = model
                                yield samples
                        completed |= finish == "STOP"
            if not completed or not total_samples:
                raise RuntimeError("Google speech stream ended without a complete reply")
            self.last_attempts.append({"model": model, "status": "stream complete"})
        except (RuntimeError, ValueError, httpx.HTTPError, TimeoutError) as error:
            self.model_cooldowns[model] = time.monotonic() + (error.cooldown if isinstance(error, SpeechProviderFailure) else 30)
            self.last_attempts.append({"model": model, "status": str(error) if isinstance(error, RuntimeError) else type(error).__name__})
            raise

    @staticmethod
    def _decode_audio(inline):
        import numpy as np
        mime = inline.get("mimeType", "").lower().replace(" ", "")
        channels = re.search(r"channels=(\d+)", mime)
        if not mime.startswith("audio/l16") or not re.search(r"(?:^|;)rate=24000(?:;|$)", mime) or channels and channels[1] != "1":
            raise RuntimeError("Unsupported Google speech audio format")
        raw = base64.b64decode(inline.get("data", ""), validate=True)
        if len(raw) % 2:
            raise RuntimeError("Incomplete Google speech sample")
        return np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768.

    @staticmethod
    def _check_response(response):
        if response.status_code == 429:
            cooldown, daily = 60., False
            try:
                for detail in response.json().get("error", {}).get("details", []):
                    if detail.get("@type", "").endswith("RetryInfo"):
                        delay = re.fullmatch(r"(\d+(?:\.\d+)?)s", detail.get("retryDelay", ""))
                        if delay:
                            cooldown = max(cooldown, float(delay[1]))
                    for violation in detail.get("violations", []):
                        daily |= "perday" in violation.get("quotaId", "").casefold()
            except (ValueError, TypeError):
                pass
            if daily:
                cooldown = max(cooldown, 3600)
            raise SpeechProviderFailure("Gemini daily speech quota reached" if daily else "Gemini speech rate limit reached", min(cooldown, 86400))
        response.raise_for_status()

    async def synthesize_async(self, text):
        if not os.getenv("GEMINI_API_KEY", "").strip():
            raise RuntimeError("Set GEMINI_API_KEY locally to use expressive Google speech")
        last_error = None
        self.last_attempts = []
        models = list(dict.fromkeys([self.config.gemini_tts_model] + self.config.gemini_tts_fallback_models))
        for model in models:
            if self.model_cooldowns.get(model, 0) > time.monotonic():
                continue
            try:
                audio = await self._synthesize_model(text, model)
                self.last_model = model
                self.last_attempts.append({"model": model, "status": "success"})
                return audio
            except httpx.HTTPStatusError as error:
                if error.response.status_code in {401, 403}:
                    raise  # Shared credentials: a different model cannot fix this.
                last_error = error
                self.last_attempts.append({"model": model, "status": f"HTTP {error.response.status_code}"})
                self.model_cooldowns[model] = time.monotonic() + 60
            except (RuntimeError, httpx.HTTPError, TimeoutError) as error:
                last_error = error
                self.last_attempts.append({"model": model, "status": str(error) if isinstance(error, RuntimeError) else type(error).__name__})
                self.model_cooldowns[model] = time.monotonic() + (error.cooldown if isinstance(error, SpeechProviderFailure) else 30)
        delay = max(1, math.ceil(round(min(self.model_cooldowns.get(model, time.monotonic()+60) for model in models) - time.monotonic(), 3)))
        reason = str(last_error) if isinstance(last_error, SpeechProviderFailure) else "Gemini speech models temporarily unavailable"
        raise SpeechProviderFailure(reason, cooldown=delay)

    async def _synthesize_model(self, text, model):
        import numpy as np
        key = os.getenv("GEMINI_API_KEY", "").strip()
        if not key:
            raise RuntimeError("Set GEMINI_API_KEY locally to use expressive Google speech")
        if not re.fullmatch(r"[a-zA-Z0-9._-]+", model):
            raise ValueError("Invalid speech model name")
        prompt = ("Generate speech for the TRANSCRIPT only. Read it verbatim in its original language.\n"
                  "DELIVERY: " + self.config.gemini_tts_style + "\n\nTRANSCRIPT:\n" + text)
        async with asyncio.timeout(self.config.gemini_tts_timeout), httpx.AsyncClient(timeout=self.config.gemini_tts_timeout, transport=self.transport) as client:
            response = await client.post(
                "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent",
                headers={"x-goog-api-key": key}, json={"contents": [{"parts": [{"text": prompt}]}],
                "generationConfig": {"responseModalities": ["AUDIO"], "speechConfig": {
                    "voiceConfig": {"prebuiltVoiceConfig": {"voiceName": self.config.gemini_tts_voice}}}}})
            if response.status_code == 429:
                cooldown = 60.
                daily = False
                try:
                    details = response.json().get("error", {}).get("details", [])
                    for detail in details:
                        if detail.get("@type", "").endswith("RetryInfo"):
                            delay = re.fullmatch(r"(\d+(?:\.\d+)?)s", detail.get("retryDelay", ""))
                            if delay:
                                cooldown = max(cooldown, float(delay[1]))
                        for violation in detail.get("violations", []):
                            daily |= "perday" in violation.get("quotaId", "").casefold()
                except (ValueError, TypeError):
                    pass
                if daily:
                    cooldown = max(cooldown, 3600)
                reason = "Gemini daily speech quota reached" if daily else "Gemini speech rate limit reached"
                raise SpeechProviderFailure(reason, cooldown=min(cooldown, 86400))
            response.raise_for_status()
        candidates = response.json().get("candidates", [])
        if not candidates or candidates[0].get("finishReason") != "STOP":
            reason = candidates[0].get("finishReason", "missing") if candidates else "no candidate"
            raise RuntimeError("Google speech generation did not finish (" + str(reason)[:40] + ")")
        audio = []
        for part in candidates[0].get("content", {}).get("parts", []):
            inline = part.get("inlineData", {})
            if not inline:
                continue
            mime = inline.get("mimeType", "").lower().replace(" ", "")
            channels = re.search(r"channels=(\d+)", mime)
            if not mime.startswith("audio/l16") or "rate=24000" not in mime or channels and channels[1] != "1":
                raise RuntimeError("Unsupported Google speech audio format")
            raw = base64.b64decode(inline.get("data", ""), validate=True)
            if len(raw) % 2:
                raise RuntimeError("Incomplete Google speech sample")
            audio.append(np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768.)
        if not audio or not any(len(chunk) for chunk in audio):
            raise RuntimeError("Google speech returned no audio")
        return np.concatenate(audio), 24000


class KokoroProvider:
    def __init__(self, config):
        self.config = config
        self.engine = None

    def synthesize(self, text):
        if self.engine is None:
            from kokoro_onnx import Kokoro
            import onnxruntime as ort
            options = ort.SessionOptions()
            options.intra_op_num_threads = 2
            options.inter_op_num_threads = 1
            session = ort.InferenceSession(str(project_path(self.config.kokoro_model)), sess_options=options, providers=["CPUExecutionProvider"])
            self.engine = Kokoro.from_session(session, str(project_path(self.config.kokoro_voices)))
        hindi = contains_hindi(text)
        return self.engine.create(text, voice=self.config.kokoro_hindi_voice if hindi else self.config.kokoro_voice,
                                  speed=self.config.tts_speed, lang="hi" if hindi else self.config.tts_language)


class GroqTTSProvider:
    def __init__(self, config):
        self.config = config

    def synthesize(self, text):
        import soundfile as sf
        key = os.getenv("GROQ_API_KEY")
        if not key:
            raise RuntimeError("Groq TTS key missing")
        response = httpx.post("https://api.groq.com/openai/v1/audio/speech", timeout=15,
            headers={"Authorization": f"Bearer {key}"}, json={"model": self.config.groq_tts_model,
                "voice": self.config.groq_tts_voice, "input": text, "response_format": "wav"})
        response.raise_for_status()
        return sf.read(io.BytesIO(response.content), dtype="float32")


class SpeechOutput:
    # Only these fixed, non-personal phrases can be saved. Never persist generated
    # conversation text or microphone recordings as part of the audio cache.
    CACHE_TEXT = {"Done.", "On it.", "One second.", "Got it.", "हाँ, बोलो।", "हाँ, सुन रहा हूँ।", "हो गया।", "रुक गया।"}

    def __init__(self, config, bus):
        self.config, self.bus = config, bus
        self.playback = Playback(config.output_device)
        self.providers = {"gemini": GeminiTTSProvider(config), "google": GoogleTTSProvider(config), "edge": EdgeTTSProvider(config), "kokoro": KokoroProvider(config), "groq": GroqTTSProvider(config)}
        self.pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="zorin-tts")
        self.cache = {}
        self.cache_models = {}
        self.failed_until = {}
        self.last_backend = None
        self.task = None
        self.preparing = None
        self.token = Cancellation()
        self.speaking = False

    def stop(self):
        if self.preparing is not None and not self.preparing.done():
            self.preparing.cancel()
        self.preparing = None
        self.token.cancel()
        self.playback.stop()
        if self.task and not self.task.done():
            self.task.cancel()
        self.speaking = False
        self.bus.emit("speaking_state", speaking=False)

    def say(self, text, *, prepared=None):
        self.stop()
        self.token = Cancellation()
        self.preparing = prepared
        self.task = asyncio.create_task(self._speak(text, self.token, prepared))

    async def prepare(self, text):
        """Synthesize one novel task reply in RAM while desktop work proceeds."""
        if self.config.tts_provider != "gemini":
            return None
        started = time.monotonic()
        try:
            provider = self.providers["gemini"]
            audio = await provider.synthesize_async(text)
            self.bus.emit("latency", stage="speech_prepared", seconds=round(time.monotonic()-started, 3), provider="gemini")
            return {"text": text, "audio": audio, "model": provider.last_model,
                    "identity": str(self._cache_path("gemini", text))}
        except (RuntimeError, ValueError, httpx.HTTPError, TimeoutError):
            return None

    async def _speak(self, text, token, prepared=None):
        if self.config.tts_provider == "none":
            return
        self.speaking = True
        self.bus.emit("speaking_state", speaking=True)
        try:
            if prepared is not None:
                ready = await prepared
                token.check()
                if ready and ready["text"] == text and ready["identity"] == str(self._cache_path("gemini", text)):
                    self.last_backend = ("gemini", ready["model"])
                    self.bus.emit("voice_backend", provider="gemini", model=ready["model"], voice=self.config.gemini_tts_voice)
                    await self.playback.play(*ready["audio"], token)
                    return
            # Short conversational replies are generated together, so model/network
            # startup between sentences cannot insert seconds of playback silence.
            token.check()
            if text.strip():
                await self._chunk(text, token)
        except (asyncio.CancelledError, CancelledAction):
            pass
        except Exception:
            self.bus.emit("degraded", subsystem="TTS", message="Speech output unavailable; text remains active")
        finally:
            if token is self.token:
                self.speaking = False
                self.bus.emit("speaking_state", speaking=False)

    async def _chunk(self, text, token):
        started = time.monotonic()
        for name in dict.fromkeys([self.config.tts_provider] + self.config.tts_fallbacks):
            cache_key = (name, text)
            audio = self.cache.get(cache_key)
            if audio is None and text in self.CACHE_TEXT:
                audio = self._read_cache(name, text)
            if audio is None and self.failed_until.get(name, 0) > time.monotonic():
                continue
            try:
                if name == "gemini" and audio is None and not os.getenv("GEMINI_API_KEY", "").strip():
                    self.failed_until[name] = time.monotonic() + 60
                    self.bus.emit("degraded", subsystem="TTS", message="Gemini voice needs GEMINI_API_KEY in .env; using a local fallback voice")
                    continue
                if name == "sapi":
                    await asyncio.get_running_loop().run_in_executor(self.pool, self._sapi, text, token)
                    return
                cached = audio is not None
                if audio is None:
                    provider = self.providers[name]
                    if name == "gemini" and self.config.gemini_tts_streaming and self.config.gemini_tts_model == "gemini-3.1-flash-tts-preview" and provider.model_cooldowns.get(self.config.gemini_tts_model, 0) <= time.monotonic():
                        if await self._stream_reply(text, provider, token, started):
                            return
                    if hasattr(provider, "synthesize_async"):
                        audio = await provider.synthesize_async(text)
                    else:
                        audio = await asyncio.get_running_loop().run_in_executor(self.pool, provider.synthesize, text)
                    if text in self.CACHE_TEXT:
                        self.cache[cache_key] = audio
                        self.cache_models[cache_key] = getattr(provider, "last_model", "")
                        self._write_cache(name, text, audio)
                token.check()
                provider = self.providers[name]
                backend = (name, self.cache_models.get(cache_key, getattr(provider, "last_model", "")))
                if backend != self.last_backend:
                    self.last_backend = backend
                    self.bus.emit("voice_backend", provider=name, model=backend[1],
                                  voice=self.config.gemini_tts_voice if name == "gemini" else "")
                self.bus.emit("latency", stage="speech_ready", provider=name, seconds=round(time.monotonic()-started, 3), cached=cached)
                await self.playback.play(*audio, token)
                return
            except CancelledAction:
                raise
            except PartialSpeechFailure:
                self.bus.emit("degraded", subsystem="TTS", message="Speech stream was interrupted before completion. The reply remains in text; it will not restart in another voice.")
                return
            except Exception as error:
                cooldown = error.cooldown if isinstance(error, SpeechProviderFailure) else 60
                self.failed_until[name] = time.monotonic() + cooldown
                message = str(error) if isinstance(error, SpeechProviderFailure) else f"{name} failed"
                self.bus.emit("degraded", subsystem="TTS", message=message + f"; trying fallback, {name} retry in {int(cooldown)} seconds")
        raise RuntimeError("All TTS providers unavailable")

    async def _stream_reply(self, text, provider, token, started):
        emitted = False
        collected = []
        source = provider.stream_async(text)
        async def chunks():
            nonlocal emitted
            async for samples in source:
                token.check()
                if not emitted:
                    self.last_backend = ("gemini", provider.last_model)
                    self.bus.emit("voice_backend", provider="gemini", model=provider.last_model, voice=self.config.gemini_tts_voice)
                    self.bus.emit("latency", stage="speech_first_chunk", provider="gemini", seconds=round(time.monotonic()-started, 3), cached=False)
                emitted = True
                if text in self.CACHE_TEXT:
                    collected.append(samples)
                yield samples
        stream = chunks()
        try:
            stats = await self.playback.play_stream(stream, 24000, token)
            if not emitted:
                raise RuntimeError("No streamed speech received")
            if collected:
                import numpy as np
                audio = np.concatenate(collected), 24000
                self.cache[("gemini", text)] = audio
                self.cache_models[("gemini", text)] = provider.last_model
                self._write_cache("gemini", text, audio)
            self.bus.emit("latency", stage="speech_stream_complete", provider="gemini", underruns=stats["underruns"],
                          playback_started_seconds=round(stats["started_at"]-started, 3) if stats["started_at"] else None)
            return True
        except (asyncio.CancelledError, CancelledAction):
            raise
        except Exception as error:
            if emitted:
                raise PartialSpeechFailure() from error
            if isinstance(error, httpx.HTTPStatusError) and error.response.status_code in {401, 403}:
                raise
            reason = str(error) if isinstance(error, SpeechProviderFailure) else type(error).__name__
            self.bus.emit("voice", message="Streaming unavailable before playback; trying buffered speech", reason=reason)
            return False
        finally:
            await stream.aclose()
            await source.aclose()

    def _cache_path(self, name, text):
        # Settings form part of the identity: changing speaker, model or delivery
        # cannot silently replay audio from the old voice.
        identity = {"version": 1, "provider": name, "text": text,
                    "settings": self.config.model_dump(include={"gemini_tts_model", "gemini_tts_fallback_models", "gemini_tts_voice", "gemini_tts_style",
                        "google_tld", "edge_hindi_voice", "edge_english_voice", "kokoro_hindi_voice", "kokoro_voice", "tts_language", "tts_speed"})}
        digest = hashlib.sha256(json.dumps(identity, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
        return project_path(self.config.tts_cache_directory) / (digest + ".npz")

    def _read_cache(self, name, text):
        import numpy as np
        try:
            path = self._cache_path(name, text)
            if not path.exists() or path.stat().st_size > 2_000_000:
                return None
            with np.load(path, allow_pickle=False) as saved:
                samples, rate = saved["samples"], int(saved["rate"])
                if samples.ndim != 1 or not 8000 <= rate <= 48000 or not 0 < len(samples) <= rate*20 or not np.isfinite(samples).all():
                    return None
                audio = samples.astype(np.float32), rate
                self.cache_models[(name, text)] = str(saved["model"])
                self.cache[(name, text)] = audio
                return audio
        except (OSError, ValueError, KeyError, EOFError, zipfile.BadZipFile):
            return None

    def _write_cache(self, name, text, audio):
        import numpy as np
        try:
            path = self._cache_path(name, text)
            path.parent.mkdir(parents=True, exist_ok=True)
            samples, rate = audio
            temporary = path.with_suffix(".tmp")
            with temporary.open("wb") as stream:
                np.savez(stream, samples=np.asarray(samples, dtype=np.float32).reshape(-1), rate=rate, model=self.cache_models[(name, text)])
            temporary.replace(path)
        except (OSError, ValueError):
            pass  # A cache failure must not prevent the spoken reply.

    @staticmethod
    def _sapi(text, token):
        import comtypes
        import comtypes.client
        comtypes.CoInitialize()
        try:
            speaker = comtypes.client.CreateObject("SAPI.SpVoice")
            voices = speaker.GetVoices()
            for index in range(voices.Count):
                voice = voices.Item(index)
                if "male" == voice.GetAttribute("Gender").casefold():
                    speaker.Voice = voice
                    break
            token.check()
            speaker.Speak(text, 1)
            while not speaker.WaitUntilDone(20):
                if token.event.is_set():
                    speaker.Speak("", 3)
                    break
        finally:
            comtypes.CoUninitialize()

    async def warm(self):
        if self.config.tts_provider == "kokoro" and project_path(self.config.kokoro_model).exists():
            try:
                for text in self.CACHE_TEXT:
                    audio = await asyncio.get_running_loop().run_in_executor(self.pool, self.providers["kokoro"].synthesize, text)
                    self.cache[("kokoro", text)] = audio
            except Exception:
                self.bus.emit("degraded", subsystem="TTS", message="Kokoro warmup failed; fallback remains available")

    async def close(self):
        self.stop()
        if self.task:
            await asyncio.gather(self.task, return_exceptions=True)
        self.pool.shutdown(wait=False, cancel_futures=True)
