import asyncio
from collections import deque
import re
import time
from core.config import project_path
from core.events import EventBus
from core.state_machine import TaskState, Phase, Cancellation, CancelledAction
from brain.intent import IntentRouter, is_cancel
from brain.router import ProviderRouter, AllProvidersUnavailable
from brain.planner import Planner
from memory.manager import Memory
from persona.personality import Personality
from persona.proactive import Proactive
from persona.companion import Companion, activity_context, context_key
from safety.confirmation import ConfirmationGate
from safety.risk import assess
from safety.secrets import redact, sensitive_text
from voice.tts import SpeechOutput
from voice.stt import SpeechToText
from voice.microphone import Microphone
from brain.local_runtime import LocalBrainRuntime
from perception.vision import Vision


class Assistant:
    def __init__(self, config, executor, *, bus=None, providers=None, speech=None):
        self.config, self.executor = config, executor
        self.bus = bus or EventBus()
        self.memory = Memory(project_path(config.memory.database), config.memory.enabled)
        self.persona = Personality(config, self.memory)
        self.proactive = Proactive(config.personality)
        self.router = ProviderRouter(config.brain, self.bus, providers)
        self.intent = IntentRouter(config.automation, self.memory)
        self.planner = Planner(self.router, self.persona, self.memory, config)
        self.gate = ConfirmationGate(self.bus)
        self.speech = speech or SpeechOutput(config.voice, self.bus)
        self.stt = SpeechToText(config.voice, self.bus)
        self.microphone = None
        self.state = TaskState()
        self.history = deque(self.memory.recent_dialogue(), maxlen=12)
        self.companion = Companion(config, self.memory, self.persona, self.router)
        self.companion_task = None
        self.input_serial = 0
        self.speech_context = "reply"
        self.conversation_active = False
        self.task = None
        self.token = Cancellation()
        self.generation = 0
        self.last_response = ""
        self.last_speech_ended = -1e12
        self.background = []
        self.closed = False
        self.failures = 0
        self.local_brain = LocalBrainRuntime(config.brain, self.bus)
        self.router.local_recovery = self.local_brain.ensure_running
        self.vision = Vision(config.privacy, self.router.providers)

    def set_phase(self, phase):
        self.state.phase = phase
        self.bus.emit("assistant_state", phase=phase)

    def respond(self, text, *, source="reply", prepared=None):
        text = redact(text)
        self.last_response = text
        self.persona.remember_response(text)
        self.history.append({"role": "assistant", "content": text})
        self.memory.record_dialogue("assistant", text, source)
        self.speech_context = source
        self.bus.emit("assistant_text", text=text)
        if self.config.voice.enabled:
            if prepared is not None:
                self.speech.say(text, prepared=prepared)
            else:
                self.speech.say(text)

    async def start(self, voice=True, proactive=True):
        queue = self.bus.subscribe()
        self.background.append(asyncio.create_task(self._speech_state(queue)))
        self.bus.emit("system", message="Starting ZORIN-M4 — microphone and voice ON" if voice and self.config.voice.enabled else "Starting ZORIN-M4 — microphone OFF")
        try:
            self.state.last_observation = await self.executor.observe()
        except Exception:
            self.bus.emit("degraded", subsystem="desktop", message="Desktop inspection unavailable; task attempts will report failure")
        if voice and self.config.voice.enabled:
            try:
                await self.stt.start()
            except Exception:
                self.bus.emit("degraded", subsystem="STT", message="Whisper startup failed; check --doctor")
            async def voice_command(text):
                await self.submit(text, source="voice")
            self.microphone = Microphone(self.config.voice, self.stt, self.bus, voice_command, self.barge_in)
            self.microphone.enabled = False
            await self.microphone.start()
            # Warm before greeting; otherwise cache generation delays the first audible response.
            await self.speech.warm()
            try:
                await asyncio.wait_for(self.microphone.ready.wait(), 3)
            except asyncio.TimeoutError:
                self.bus.emit("degraded", subsystem="microphone", message="Microphone has not become ready; use /devices")
        try:
            await self.local_brain.start()
            local_provider = self.router.providers.get("local")
            if self.local_brain.ready and local_provider:
                self.bus.emit("system", message="Checking local conversation before enabling microphone commands")
                await local_provider.complete([{"role": "system", "content": "Reply with exactly the word Ready."},
                                               {"role": "user", "content": "Confirm readiness."}], json_mode=False)
                self.router.cooldown.pop("local", None)
        except Exception as error:
            self.bus.emit("degraded", subsystem="local brain", message=redact(str(error)))
        if self.microphone:
            self.microphone.invalidate_pending()
            self.microphone.enabled = True
        self.bus.emit("system", message="ZORIN-M4 ready. /help for controls.")
        if proactive:
            self.background.append(asyncio.create_task(self._monitor()))
            if self.config.personality.companion_enabled:
                serial = self.input_serial
                reply = await self.companion.generate("startup", history=self.history)
                if reply and serial == self.input_serial and not self._companion_busy():
                    self.respond(reply, source="companion")
                    self.companion.said()
            elif self.proactive.accept("startup"):
                self.respond(self.persona.greeting())

    def interrupt(self, *, silent=False):
        if self.companion_task and not self.companion_task.done():
            self.companion_task.cancel()
        self.companion.pause()
        self.generation += 1
        self.token.cancel()
        self.gate.cancel()
        self.speech.stop()
        if self.task and not self.task.done():
            self.task.cancel()
        self.state.user_interrupt = True
        self.state.cancel_requested = True
        self.state.outcome = "cancelled"
        self.set_phase(Phase.INTERRUPTED if silent else Phase.CANCELLED)
        if not silent:
            self.respond("रुक गया।" if self.config.assistant.language_mode == "hinglish" else "Stopped. Anything already completed stays completed.")

    def barge_in(self):
        if self.speech.speaking or self.task and not self.task.done():
            self.interrupt(silent=True)

    async def submit(self, text, source="text"):
        text = text.strip()
        if source == "voice":
            from voice.commands import voice_command
            text = voice_command(text, busy=bool(self.speech.speaking and self.speech_context not in {"companion", "conversation"} or self.task and not self.task.done() and not self.conversation_active),
                                 last_reply=self.last_response, speaking=self.speech.speaking or time.monotonic()-self.last_speech_ended < 8)
            if text is None:
                self.bus.emit("voice_filter", message="Ignored unaddressed speech while busy or likely playback echo")
                return
        if not text or len(text) > 8000:
            return
        self.input_serial += 1
        if self.companion_task and not self.companion_task.done():
            self.companion_task.cancel()
        if source != "voice" and self.microphone:
            self.microphone.invalidate_pending()
        if text.casefold() in {"/voice-test", "test your voice"}:
            self.speech.say("हाँ, मैं सुन रहा हूँ। बोलो, क्या हुआ? We can take it one step at a time.")
            return
        if text.casefold() in {"/mic off", "/mic on"}:
            if self.microphone:
                self.microphone.enabled = text.casefold().endswith("on")
                self.respond("Microphone " + ("on." if self.microphone.enabled else "off."))
            else:
                self.respond("This session started without microphone input. Restart using run.bat.")
            return
        if text.casefold().strip(" ?.") in {"what are you doing", "/status"}:
            self.respond(self.state.describe())
            return
        if text.startswith(("/confirm ", "/deny ")):
            command, nonce = text.split(maxsplit=1)
            if not self.gate.resolve(nonce.strip(), command == "/confirm"):
                self.respond("That confirmation has expired or doesn't match.")
            return
        if is_cancel(text) or text == "/cancel":
            self.interrupt()
            return
        if text == "/quiet" or text.casefold().strip(" .!।") in {"stop commenting", "chup raho", "abhi mat bolo", "चुप रहो", "अभी मत बोलो"}:
            self.persona.social.user_busy = True
            self.memory.set_preference("proactive_paused", True)
            self.respond("Quiet mode on.")
            return
        if text == "/unquiet" or text.casefold().strip(" .!।") in {"talk freely", "baat karte raho", "बात करते रहो"}:
            self.persona.social.user_busy = False
            self.memory.set_preference("proactive_paused", False)
            self.respond("Quiet mode off.")
            return
        if sensitive_text(text):
            self.respond("Keep secrets out of chat. Enter them directly in the application.")
            return
        if self.speech.speaking or self.task and not self.task.done():
            self.interrupt(silent=True)
        self.token = Cancellation()
        self.conversation_active = False
        self.state = TaskState(current_goal=text)
        self.history.append({"role": "user", "content": text})
        self.memory.record_dialogue("user", text, source)
        learned_reply = self.memory.ingest(text, self.last_response)
        if learned_reply:
            self.respond(learned_reply)
            return
        quick_reply = None if self.config.personality.companion_enabled else self.persona.quick_reply(text)
        if quick_reply:
            self.state.outcome = "success"
            self.respond(quick_reply)
            return
        generation = self.generation
        self.task = asyncio.create_task(self._run(text, self.token, generation))

    async def _run(self, goal, token, generation):
        self.state.outcome = "running"
        performed = []
        outcomes = []
        planned_hwnd = None
        repairs = 0
        succeeded = False
        summary = "Task interrupted"
        completion_draft = None
        completion_audio = None
        audio_handed_off = False
        try:
            plan = self.intent.route(goal)
            if plan is None:
                self.set_phase(Phase.THINKING)
                if self.planner.is_conversation(goal):
                    self.conversation_active = self.config.personality.companion_enabled
                    observation = {}
                else:
                    try:
                        observation = await self.executor.observe()
                    except Exception:
                        observation = {"desktop": "unavailable"}
                plan = await self.planner.plan(goal, self.history, observation, outcomes)
                planned_hwnd = observation.get("hwnd")
            if plan.actions and self.config.personality.companion_enabled:
                completion_draft = asyncio.create_task(self.companion.generate("completion_draft", history=list(self.history), goal=goal))
                if self.config.voice.enabled and hasattr(self.speech, "prepare"):
                    async def prepare_audio():
                        text = await asyncio.shield(completion_draft)
                        return await self.speech.prepare(text) if text else None
                    completion_audio = asyncio.create_task(prepare_audio())
            for batch in range(4):
                replan_needed = False
                token.check()
                if not plan.actions:
                    succeeded = plan.complete
                    summary = plan.reply or "I need a more specific target to continue."
                    self.respond(summary, source="conversation" if self.config.personality.companion_enabled else "reply")
                    return
                if len(performed) + len(plan.actions) > self.config.automation.max_steps:
                    raise RuntimeError("Task reached its configured step limit")
                self.state.current_plan = [a.model_dump() for a in plan.actions]
                self.bus.emit("plan", steps=len(plan.actions))
                for action in plan.actions:
                    token.check()
                    observation = await self.executor.observe()
                    if action.kind not in {"open_app", "focus_window", "volume"} and planned_hwnd and observation.get("hwnd") != planned_hwnd:
                        raise RuntimeError("The active window changed while I was planning. Stopped before sending input to a different app.")
                    self.state.last_observation = observation
                    self.state.active_application = observation.get("title", "")
                    decision = assess(action, observation, goal)
                    approved = None
                    if decision.mode == "deny":
                        raise PermissionError(decision.reason)
                    if decision.mode == "confirm":
                        self.set_phase(Phase.AWAITING_CONFIRMATION)
                        if not await self.gate.request(action, decision.reason, observation["fingerprint"]):
                            raise CancelledAction("Action was not approved")
                        approved = observation["fingerprint"]
                    token.check()
                    self.set_phase(Phase.ACTING)
                    self.state.current_step = len(performed) + 1
                    self.state.expected_result = action.expected.value or action.kind.replace("_", " ")
                    self.bus.emit("current_action", kind=action.kind, target=redact(action.target), step=self.state.current_step)
                    if action.method == "vision":
                        result = await self._visual_action(action, token, goal)
                    else:
                        result = await self.executor.execute(action, token, goal, approved)
                    if not result.success and action.fallback == "vision" and result.summary.startswith("LookupError:") and action.kind in {"click", "double_click", "right_click", "hover"}:
                        result = await self._visual_action(action, token, goal)
                    elif not result.success and self.config.privacy.cloud_vision and result.summary.startswith('LookupError:') and action.kind in {'click','click_index','double_click','right_click','hover'}:
                        result = await self._visual_action(action, token, goal)
                    # Retry only operations that cannot duplicate typed text or commit transactions.
                    if not result.success and action.fallback == "redetect" and action.kind in {"focus_window", "wait"}:
                        for _ in range(self.config.automation.retries):
                            token.check()
                            result = await self.executor.execute(action, token, goal, approved)
                            if result.success:
                                break
                    self.memory.record_action(action, result.success, result.summary)
                    self.state.last_observation = result.observation
                    planned_hwnd = result.observation.get("hwnd")
                    performed.append(action)
                    outcomes.append({"action": action.kind, "target": action.target, "success": result.success, "summary": result.summary})
                    self.bus.emit("verification", success=result.success, message=redact(result.summary))
                    self.bus.emit("task_progress", completed=len(performed), batch_size=len(plan.actions))
                    if not result.success:
                        self.state.error_count += 1
                        ambiguous = "Multiple matching windows" in result.summary or "matches; need one unambiguous" in result.summary
                        if result.summary.startswith("LookupError:") and not ambiguous and repairs < self.config.automation.retries:
                            # Lookup failed before committing input. Fresh perception may
                            # reveal a Back button, different view or renamed control.
                            repairs += 1
                            replan_needed = True
                            self.bus.emit("recovery", message="Target lookup failed; replanning from the current view")
                            break
                        raise RuntimeError(result.summary)
                    if action.kind == "open_app":
                        purpose = "thumbnail editor" if "thumbnail" in goal.casefold() else "editing software" if "edit" in goal.casefold() else ""
                        self.memory.record_app(action.target, purpose)
                if plan.complete and not replan_needed:
                    succeeded = True
                    summary = "All planned actions verified"
                    continuation = None
                    if completion_draft:
                        try:
                            continuation = await asyncio.wait_for(asyncio.shield(completion_draft), .25)
                        except TimeoutError:
                            pass
                    token.check()
                    ready_audio = completion_audio if continuation else None
                    self.respond(continuation or plan.reply or ("हो गया।" if self.config.assistant.language_mode == "hinglish" else "Done."),
                                 source="conversation" if continuation else "reply", prepared=ready_audio)
                    audio_handed_off = ready_audio is not None
                    if continuation:
                        context = activity_context(self.state.last_observation)
                        self.companion.said(context_key(context) if context else None)
                    self.failures = 0
                    self.persona.social.task_pressure = 0.
                    return
                self.set_phase(Phase.THINKING)
                observation = await self.executor.observe()
                plan = await self.planner.plan(goal, self.history, observation, outcomes)
                planned_hwnd = observation.get("hwnd")
            raise RuntimeError("Reached the planning round limit; the remaining task needs a new instruction")
        except (asyncio.CancelledError, CancelledAction):
            token.cancel()
            summary = "Cancelled; completed actions were not undone"
        except AllProvidersUnavailable:
            summary = "No brain provider configured or reachable"
            if self.router.last_failure == "invalid plan":
                detail = "Completed steps remain completed." if performed else "Nothing was executed."
                self.respond("I couldn't produce a valid action plan for that. " + detail + " Try giving me one part of the task first.")
            else:
                self.respond("My local brain isn't responding. App commands still work.")
        except Exception as error:
            summary = redact(str(error))
            self.failures += 1
            self.persona.social.task_pressure = min(1., self.failures * .3)
            if "Multiple matching windows" in summary:
                self.respond("एक से ज़्यादा matching window खुली हैं। जिस वाली में काम करना है, उसे सामने ले आओ।")
            else:
                self.respond("Stopped here: " + summary)
        finally:
            if completion_audio and not audio_handed_off:
                completion_audio.cancel()
                await asyncio.gather(completion_audio, return_exceptions=True)
            if completion_draft:
                completion_draft.cancel()
                await asyncio.gather(completion_draft, return_exceptions=True)
            if performed and self.config.memory.reflection:
                learned_actions = [a for a, result in zip(performed, outcomes) if result["success"]] if succeeded else performed
                self.memory.reflect(goal, learned_actions, succeeded, summary, reusable=succeeded)
            if generation == self.generation:
                self.state.outcome = "success" if succeeded else "cancelled" if token.event.is_set() else "failed"
                self.set_phase(Phase.SPEAKING if self.speech.speaking else Phase.LISTENING)

    async def _speech_state(self, queue):
        try:
            while not self.closed:
                event = await queue.get()
                if event.type != "speaking_state":
                    continue
                if not event.data.get("speaking"):
                    self.last_speech_ended = time.monotonic()
                idle = not self.task or self.task.done()
                if event.data.get("speaking") and idle:
                    self.set_phase(Phase.SPEAKING)
                elif not event.data.get("speaking") and self.state.phase == Phase.SPEAKING and idle:
                    self.set_phase(Phase.LISTENING)
        finally:
            self.bus.unsubscribe(queue)

    def _companion_busy(self):
        return bool(self.closed or self.persona.social.user_busy or self.speech.speaking or
                    self.task and not self.task.done() or self.gate.pending or
                    self.microphone and (not self.microphone.enabled or self.microphone.transcribing or
                    time.monotonic()-self.microphone.last_voice_at < 2))

    async def _consider_activity(self, observation, now=None):
        offer = self.companion.observe(observation, busy=self._companion_busy(), now=now)
        if not offer or self.companion_task and not self.companion_task.done():
            return
        serial = self.input_serial
        self.companion_task = asyncio.create_task(self._activity_reply(offer, serial))

    async def _activity_reply(self, offer, serial):
        reply = await self.companion.generate("activity", history=list(self.history), activity=offer.context)
        if not reply or serial != self.input_serial or self._companion_busy():
            return
        # Recheck the current tab after model latency; never comment on a stale tab.
        try:
            current = activity_context(await self.executor.activity())
        except Exception:
            return
        if not current or context_key(current) != offer.key or serial != self.input_serial or self._companion_busy():
            return
        self.respond(reply, source="companion")
        self.companion.said(offer.key)
        self.bus.emit("companion", event="activity_comment", context="active title and app only")

    async def _monitor(self):
        import psutil
        while not self.closed:
            await asyncio.sleep(1 if self.config.personality.companion_enabled else 8)
            try:
                stats = {"cpu_percent": psutil.cpu_percent(), "memory_percent": psutil.virtual_memory().percent}
                self.bus.emit("system_stats", **stats)
                busy = self._companion_busy()
                if stats["memory_percent"] > 94 and self.proactive.accept("high_memory", busy=busy):
                    self.respond("Memory is nearly full. Closing a heavy app would give us some room.")
                if self.config.personality.companion_enabled:
                    observation = await self.executor.activity()
                    await self._consider_activity(observation)
            except Exception:
                continue

    async def _visual_action(self, action, token, goal):
        from hands.executor import Outcome
        if not self.config.privacy.cloud_vision:
            return Outcome(False, "Vision is disabled. Enable privacy.cloud_vision and configure a vision provider to use it.", await self.executor.observe())
        observation = await self.executor.observe()
        png, bbox = await self.executor.capture()
        target = (f'The {action.amount}th visible {action.target}, counted top to bottom and left to right. Count each video card once, not its separate title and thumbnail. Exclude ads, navigation, channels and playlists. If fewer than {action.amount} are visible, return found:false.'
                  if action.kind=='click_index' else action.target)
        visual = await self.vision.locate(png, target)
        token.check()
        if not self.config.privacy.cloud_vision:
            return Outcome(False,'Screen sharing was disabled while locating the target.',observation)
        if not visual.found or visual.confidence < .85:
            return Outcome(False, "Vision could not locate the requested target confidently", observation)
        checked_action = action.model_copy(update={"target": visual.label or action.target,
                                                  'kind':'click' if action.kind=='click_index' else action.kind})
        decision = assess(checked_action, observation, goal)
        if decision.mode == "deny":
            return Outcome(False, decision.reason, observation)
        approved = None
        if decision.mode == "confirm":
            self.set_phase(Phase.AWAITING_CONFIRMATION)
            if not await self.gate.request(checked_action, decision.reason, observation["fingerprint"]):
                raise CancelledAction("Visual action was not approved")
            approved = observation["fingerprint"]
        self.set_phase(Phase.ACTING)
        return await self.executor.execute_visual(checked_action, visual, bbox, observation["fingerprint"], token, goal, approved)

    async def close(self):
        self.closed = True
        self.interrupt(silent=True)
        if self.companion_task:
            await asyncio.gather(self.companion_task, return_exceptions=True)
        if self.task:
            await asyncio.gather(self.task, return_exceptions=True)
        for task in self.background:
            task.cancel()
        await asyncio.gather(*self.background, return_exceptions=True)
        if self.microphone:
            await self.microphone.close()
        await self.stt.close()
        await self.speech.close()
        await self.router.close()
        await self.local_brain.close()
        await self.executor.close()
        self.memory.close()
