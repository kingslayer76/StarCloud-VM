import asyncio
import json
import time
import pytest
import httpx
from pydantic import ValidationError
from core.config import Config, VoiceConfig, ProviderConfig, BrainConfig
from core.events import EventBus
from core.state_machine import Cancellation, CancelledAction
from brain.schemas import Plan, action
from brain.intent import IntentRouter, corrected, is_cancel
from brain.providers.groq_provider import GroqProvider
from brain.providers.base import ProviderFailure
from brain.router import ProviderRouter, AllProvidersUnavailable
from memory.manager import Memory
from persona.personality import Personality
from persona.proactive import Proactive
from safety.risk import assess
from safety.confirmation import ConfirmationGate
from safety.secrets import redact
from hands.verifier import verify
from voice.vad import Segmenter


@pytest.fixture
def memory(tmp_path):
    value = Memory(tmp_path / "memory.db")
    yield value
    value.close()


def test_memory_restart_and_feedback(tmp_path):
    path = tmp_path / "persist.db"
    first = Memory(path)
    assert first.ingest("I prefer short replies.")
    first.ingest("Don't make jokes when I'm fixing errors.")
    first.ingest("Stop saying that.", "Old phrase.")
    first.close()
    second = Memory(path)
    assert second.preference("response_length") == "short"
    assert second.preference("no_humor_debugging") is True
    assert "Old phrase." in second.preference("avoid_phrases")
    assert second.preference("humor_multiplier") < 1
    assert len(second.retrieve("replies")) == 2
    second.close()


def test_memory_secrets_and_confidence(memory):
    assert not memory.remember("password=verysecret123")
    memory.remember("Enjoys editing", explicit=False)
    memory.remember("Prefers Chrome", explicit=True)
    rows = memory.retrieve("Chrome")
    assert rows[0]["confidence"] == .99
    assert next(r for r in rows if not r["explicit"])["confidence"] == .6


def test_learned_recipe_and_app_threshold(memory):
    actions = [action("open_app", target="Notepad", expected_kind="window", expected_value="Notepad")]
    memory.reflect("Open my editor", actions, True, "Verified", reusable=True)
    memory.reflect("Open my editor", actions, True, "Verified", reusable=True)
    assert memory.recipe("open my editor")[0]["kind"] == "open_app"
    assert memory.db.execute("SELECT success_count FROM skills").fetchone()[0] == 2
    for _ in range(2):
        memory.record_app("Photoshop", "thumbnail editor")
    assert memory.learned_app("thumbnail editor") is None
    memory.record_app("Photoshop", "thumbnail editor")
    assert memory.learned_app("thumbnail editor") == "Photoshop"


@pytest.mark.parametrize("text,target", [("Open Chrome.", "Chrome"), ("Steam kholo.", "Steam"), ("notepad khol do", "notepad"), ("Actually rehne de, Steam khol.", "Steam")])
def test_fast_open(memory, text, target):
    result = IntentRouter(Config().automation, memory).route(text)
    assert result.actions[0].target == target


def test_literal_payload_and_complex_route(memory):
    router = IntentRouter(Config().automation, memory)
    p = router.route("Open Notepad and type exactly: actually, don't split this and that.")
    assert p.actions[1].text == "actually, don't split this and that."
    assert router.route("Open Steam and launch Forza Horizon 5.") is None


@pytest.mark.parametrize("text", ["Wait, cancel that.", "Actually rehne de.", "stop", "रुको"])
def test_cancel_phrases(text):
    assert is_cancel(text)


def test_malformed_model_output_rejected():
    with pytest.raises(ValidationError):
        Plan.model_validate({"reply": "", "actions": [{"kind": "shell", "command": "anything"}]})
    with pytest.raises(ValidationError):
        action("type_text", text="hello", expected_kind="changed")
    with pytest.raises(ValidationError):
        action("type_text", text="hello", expected_kind="text", expected_value="different")
    with pytest.raises(ValidationError):
        Config.model_validate({"safety": {"confirm_sensitive_actions": False}})


def test_safety_independent_of_model_risk():
    a = action("click", target="Delete account", risk_level="normal")
    assert assess(a, {}).mode == "confirm"
    assert assess(action("key", text="enter"), {"title": "Discord"}).mode == "confirm"
    assert assess(action("type_text", text="hello", expected_kind="text", expected_value="hello"), {"process": "powershell.exe"}).mode == "deny"
    assert assess(action("click", target="OK"), {"password_focused": True}).mode == "deny"
    assert assess(action("open_app", target="Notepad", expected_kind="window", expected_value="Notepad"), {}).mode == "allow"
    assert assess(action("key", text="win+r"), {}).mode == "deny"


async def test_confirmation_nonce_and_single_use():
    bus = EventBus()
    gate = ConfirmationGate(bus)
    pending = asyncio.create_task(gate.request(action("click", target="Send"), "send message", "screen"))
    await asyncio.sleep(0)
    nonce = gate.pending["id"]
    assert not gate.resolve("wrong", True)
    assert gate.resolve(nonce, True)
    assert await pending is True
    assert not gate.resolve(nonce, True)


def test_verification_does_not_assume_click():
    expected = action("click", target="Settings").expected
    assert not verify(expected, {"fingerprint": "same"}, {"fingerprint": "same"})
    assert verify(expected, {"fingerprint": "a"}, {"fingerprint": "b"})
    text = action("type_text", text="hello", expected_kind="text", expected_value="hello").expected
    assert not verify(text, {}, {"focused_text": "different"})


def test_cancellation_is_cooperative():
    token = Cancellation()
    token.cancel()
    with pytest.raises(CancelledAction):
        token.wait(.5)


def test_bounded_bus():
    bus = EventBus()
    queue = bus.subscribe(2)
    for i in range(10):
        bus.emit("test", index=i)
    assert queue.qsize() == 2
    assert queue.get_nowait().data["index"] == 8


def test_proactivity_and_humor(memory):
    config = Config()
    p = Proactive(config.personality)
    assert not p.accept("app_opened", now=1)
    assert p.accept("wait_finished", now=1)
    assert not p.accept("wait_finished", now=2)
    assert not p.accept("high_memory", busy=True, now=1000)
    persona = Personality(config, memory)
    memory.set_preference("no_humor_debugging", True)
    assert not persona.humor_allowed("fix this error")


def test_vad_endpointing_and_barge():
    config = VoiceConfig(endpoint_ms=150, min_speech_ms=90, barge_in_ms=60)
    vad = Segmenter(config, classifier=lambda frame, rate: frame[0] == 1)
    speech, silence = b"\x01" * 960, b"\x00" * 960
    assert vad.feed(speech) == (None, False)
    assert vad.feed(speech) == (None, True)
    vad.feed(speech)
    for _ in range(4):
        assert vad.feed(silence)[0] is None
    segment, _ = vad.feed(silence)
    assert segment and len(segment) == 960 * 8
    assert not vad.started


def test_vad_rejects_short_noise():
    vad = Segmenter(VoiceConfig(endpoint_ms=150), classifier=lambda frame, rate: frame[0] == 1)
    vad.feed(b"\x01" * 960)
    for _ in range(5):
        result, _ = vad.feed(b"\x00" * 960)
    assert result is None


@pytest.mark.parametrize("status,reason", [(401, "credentials"), (403, "credentials"), (429, "quota"), (503, "outage"), (400, "rejected")])
async def test_provider_failure_classification(monkeypatch, status, reason):
    monkeypatch.setenv("TEST_KEY", "test-key")
    provider = GroqProvider(ProviderConfig(base_url="https://provider.invalid", model="test", key_env="TEST_KEY"), transport=httpx.MockTransport(lambda request: httpx.Response(status)))
    with pytest.raises(ProviderFailure, match=reason):
        await provider.complete([])
    await provider.close()


async def test_provider_fallback_and_circuit_breaker():
    class Provider:
        configured = True
        def __init__(self, failing): self.calls, self.failing = 0, failing
        async def complete(self, messages):
            self.calls += 1
            if self.failing: raise ProviderFailure("primary", "quota", 60)
            return '{"reply":"Works","actions":[],"complete":true}'
        async def close(self): pass
    primary, fallback = Provider(True), Provider(False)
    router = ProviderRouter(BrainConfig(primary_provider="primary", fallback_providers=["fallback"]), EventBus(), {"primary": primary, "fallback": fallback})
    assert (await router.complete([], Plan.model_validate_json)).reply == "Works"
    await router.complete([], Plan.model_validate_json)
    assert primary.calls == 1 and fallback.calls == 2


async def test_invalid_plan_falls_back():
    class Provider:
        configured = True
        def __init__(self, reply): self.reply = reply
        async def complete(self, messages): return self.reply
    providers = {"a": Provider('{"actions":[{"kind":"shell"}]}'), "b": Provider('{"reply":"Fine"}')}
    router = ProviderRouter(BrainConfig(primary_provider="a", fallback_providers=["b"]), EventBus(), providers)
    assert (await router.complete([], Plan.model_validate_json)).reply == "Fine"


def test_secret_redaction(monkeypatch):
    monkeypatch.setenv("TEST_API_KEY", "long-secret-value")
    assert "long-secret-value" not in redact("request long-secret-value")
    assert "hunter123" not in redact("password=hunter123")
