"""Explicitly apply assistant.autostart from config; never modifies startup on import."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import os
from core.config import ROOT, load_config


def main():
    config = load_config()
    startup = Path(os.environ["APPDATA"]) / "Microsoft/Windows/Start Menu/Programs/Startup/ZORIN-M4.lnk"
    if not config.assistant.autostart:
        startup.unlink(missing_ok=True)
        print("ZORIN-M4 autostart disabled.")
        return
    import comtypes.client
    shell = comtypes.client.CreateObject("WScript.Shell", dynamic=True)
    link = shell.CreateShortcut(str(startup))
    link.TargetPath = str(ROOT / ".venv/Scripts/python.exe")
    link.Arguments = f'"{ROOT / "main.py"}" --background'
    link.WorkingDirectory = str(ROOT)
    link.WindowStyle = 7
    link.Description = "ZORIN-M4 voice assistant"
    link.Save()
    print("ZORIN-M4 starts minimized after Windows sign-in. Set autostart:false and rerun to remove.")


if __name__ == "__main__":
    main()
