import asyncio
import time
from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class Event:
    type: str
    data: dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)


class EventBus:
    """Bounded fan-out. A slow tablet cannot stall the brain."""
    def __init__(self):
        self.listeners: set[asyncio.Queue] = set()

    def subscribe(self, capacity=128):
        queue = asyncio.Queue(maxsize=capacity)
        self.listeners.add(queue)
        return queue

    def unsubscribe(self, queue):
        self.listeners.discard(queue)

    def emit(self, event_type: str, **data):
        event = Event(event_type, data)
        for queue in tuple(self.listeners):
            if queue.full():
                queue.get_nowait()
            queue.put_nowait(event)
