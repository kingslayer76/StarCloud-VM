"""Audition two Gemini voices without changing the selected voice."""
import asyncio
import json
from pathlib import Path
import sys
import time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.config import ROOT, load_config
from core.state_machine import Cancellation
from voice.playback import Playback
from voice.tts import GeminiTTSProvider


async def run():
    import soundfile as sf
    config = load_config().voice
    text = "हाँ, बोलो, क्या scene है? आराम से बताओ, मैं सुन रहा हूँ। आज काम ने दिमाग खा लिया क्या?"
    records = []
    for label, voice, style in [
        ("A", "Zubenelgenubi", "A casual conversation between friends in India. Speak with easy, spontaneous energy, a hint of a smile and fluid everyday Hinglish. Use natural emphasis without an announcer tone."),
        ("B", "Algieba", "A calm, confident male friend speaking beside one person. Smooth, warm everyday Indian Hindi/Hinglish. Understated expression and fluid speech, without whispering or dramatic pauses."),
    ]:
        selected = config.model_copy(update={"gemini_tts_voice": voice, "gemini_tts_style": style})
        start = time.monotonic()
        audio, rate = await GeminiTTSProvider(selected).synthesize_async(f"Voice {label}. " + text)
        path = ROOT / f"data/gemini-candidate-{label}.wav"
        sf.write(path, audio, rate)
        record = {"label": label, "voice": voice, "style": style,
                  "generation_seconds": round(time.monotonic()-start, 2), "path": str(path)}
        records.append(record)
        print(json.dumps(record), flush=True)
        await Playback(config.output_device).play(audio, rate, Cancellation())
    (ROOT / "data/gemini-voice-candidates.json").write_text(json.dumps(records, indent=2), encoding="utf-8")


if __name__ == "__main__":
    asyncio.run(run())
