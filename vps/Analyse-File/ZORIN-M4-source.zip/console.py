"""Cancellable Windows console input; Ctrl+C must not leave input() blocked."""
import asyncio
import os
import sys


async def read_line(prompt="you > "):
    if os.name != "nt" or not sys.stdin.isatty():
        return await asyncio.to_thread(input, prompt)
    import msvcrt
    print(prompt, end="", flush=True)
    buffer = []
    while True:
        if not msvcrt.kbhit():
            await asyncio.sleep(.025)
            continue
        character = msvcrt.getwch()
        if character in {"\x00", "\xe0"}:
            msvcrt.getwch()  # Skip an unsupported console navigation key.
        elif character == "\x03":
            raise KeyboardInterrupt
        elif character == "\x1a":
            raise EOFError
        elif character in {"\r", "\n"}:
            print(flush=True)
            return "".join(buffer)
        elif character == "\b":
            if buffer:
                buffer.pop()
                print("\b \b", end="", flush=True)
        elif character.isprintable():
            buffer.append(character)
            print(character, end="", flush=True)
