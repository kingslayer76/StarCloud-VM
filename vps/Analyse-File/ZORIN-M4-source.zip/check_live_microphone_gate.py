"""Normal-volume gate diagnostic; keeps mic audio in RAM and executes no actions."""
import asyncio,json,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
import sounddevice as sd
from core.config import load_config
from core.instance import InstanceLease
from voice.live_gate import LiveSpeechGate

async def main():
    c=load_config();lease=InstanceLease();gate=LiveSpeechGate(c.voice)
    levels=[];voiced=[];starts=0;ends=0;active_frames=0
    def callback(data,frames,timing,status):
        nonlocal starts,ends,active_frames
        pcm=bytes(data);samples=np.frombuffer(pcm,dtype='<i2').astype(np.float32)
        rms=float(np.sqrt(np.mean(samples*samples)));levels.append(rms)
        for kind,value in gate.feed(pcm):
            if kind=='start': starts+=1
            if kind=='end': ends+=1
        if gate.active: active_frames+=1;voiced.append(rms)
    try:
        with sd.RawInputStream(samplerate=16000,blocksize=1600,channels=1,dtype='int16',device=c.voice.input_device,callback=callback):
            print('MIC CHECK STARTED: speak at your normal relaxed volume for 45 seconds. No actions or uploads.',flush=True)
            for second in range(45):
                await asyncio.sleep(1)
                if second%10==9:
                    print(json.dumps({'seconds':second+1,'speech_starts':starts,'active_frames':active_frames}),flush=True)
    finally:
        lease.close()
    result={'frames':len(levels),'speech_starts':starts,'speech_ends':ends,'active_frames':active_frames,
            'rms_median':round(float(np.median(levels)),1) if levels else 0,
            'speech_rms_median':round(float(np.median(voiced)),1) if voiced else 0,
            'noise_estimate':round(gate.noise,1),'audio_saved':False,'audio_uploaded':False}
    print(json.dumps(result),flush=True)
    Path('data/live-mic-gate-check.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    return int(starts==0)

if __name__=='__main__':
    raise SystemExit(asyncio.run(main()))
