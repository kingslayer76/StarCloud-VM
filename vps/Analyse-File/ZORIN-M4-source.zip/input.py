import ctypes as C
from ctypes import wintypes as W
import sys

ULONG_PTR = C.c_size_t


class MOUSEINPUT(C.Structure):
    _fields_ = [("dx", W.LONG), ("dy", W.LONG), ("mouseData", W.DWORD), ("dwFlags", W.DWORD), ("time", W.DWORD), ("dwExtraInfo", ULONG_PTR)]


class KEYBDINPUT(C.Structure):
    _fields_ = [("wVk", W.WORD), ("wScan", W.WORD), ("dwFlags", W.DWORD), ("time", W.DWORD), ("dwExtraInfo", ULONG_PTR)]


class HARDWAREINPUT(C.Structure):
    _fields_ = [("uMsg", W.DWORD), ("wParamL", W.WORD), ("wParamH", W.WORD)]


class INPUTUNION(C.Union):
    _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT), ("hi", HARDWAREINPUT)]


class INPUT(C.Structure):
    _anonymous_ = ("u",)
    _fields_ = [("type", W.DWORD), ("u", INPUTUNION)]


VK = {"ctrl": 0x11, "shift": 0x10, "alt": 0x12, "win": 0x5B,
      "enter": 0x0D, "escape": 0x1B, "tab": 9, "space": 0x20,
      "backspace": 8, "delete": 0x2E, "left": 0x25, "up": 0x26,
      "right": 0x27, "down": 0x28, "home": 0x24, "end": 0x23,
      "pageup": 0x21, "pagedown": 0x22, "f4": 0x73,
      "volume_mute": 0xAD, "media_play_pause": 0xB3}


class Input:
    def __init__(self, profile="natural"):
        if sys.platform != "win32":
            raise RuntimeError("Windows is required for physical input")
        self.user32 = C.WinDLL("user32", use_last_error=True)
        self.user32.SendInput.argtypes = [W.UINT, C.POINTER(INPUT), C.c_int]
        self.user32.SendInput.restype = W.UINT
        self.duration = {"fast": .06, "natural": .18, "demo": .45}[profile]

    def send(self, event):
        if self.user32.SendInput(1, C.byref(event), C.sizeof(INPUT)) != 1:
            raise RuntimeError("Windows rejected input (possibly elevated or protected window)")

    def key_event(self, code, up=False, unicode=False):
        extended = not unicode and code in {0x5B, 0x25, 0x26, 0x27, 0x28, 0x21, 0x22, 0x23, 0x24, 0x2E, 0xAD, 0xB3}
        flags = (2 if up else 0) | (4 if unicode else 0) | (1 if extended else 0)
        self.send(INPUT(type=1, ki=KEYBDINPUT(0 if unicode else code, code if unicode else 0, flags, 0, 0)))

    def key(self, chord, token):
        codes = [VK[x] if x in VK else ord(x.upper()) if len(x) == 1 and x.isascii() else None for x in chord.lower().split("+")]
        if None in codes:
            raise ValueError("Unsupported keyboard chord")
        pressed = []
        try:
            for code in codes:
                token.check()
                self.key_event(code)
                pressed.append(code)
            token.wait(.025)
        finally:
            for code in reversed(pressed):
                self.key_event(code, up=True)

    def type_text(self, text, token, guard=None):
        encoded = text.encode("utf-16-le")
        for offset in range(0, len(encoded), 2):
            token.check()
            if guard and offset % 24 == 0:
                guard()
            code = int.from_bytes(encoded[offset:offset+2], "little")
            self.key_event(code, unicode=True)
            self.key_event(code, up=True, unicode=True)
            token.wait(.002)

    def position(self):
        point = W.POINT()
        self.user32.GetCursorPos(C.byref(point))
        return point.x, point.y

    def move(self, x, y, token):
        sx, sy = self.position()
        ticks = max(1, round(self.duration / .012))
        for i in range(1, ticks + 1):
            token.check()
            t = i / ticks
            t = t*t*(3-2*t)
            self.user32.SetCursorPos(round(sx + (x-sx)*t), round(sy + (y-sy)*t))
            token.wait(self.duration / ticks)

    def button(self, button, up=False):
        flags = {("left", False): 2, ("left", True): 4, ("right", False): 8, ("right", True): 16}
        self.send(INPUT(type=0, mi=MOUSEINPUT(0, 0, 0, flags[(button, up)], 0, 0)))

    def click(self, token, button="left", count=1):
        for _ in range(count):
            token.check()
            self.button(button)
            try:
                token.wait(.025)
            finally:
                self.button(button, up=True)
            if count > 1:
                token.wait(.06)

    def scroll(self, amount, token):
        token.check()
        self.send(INPUT(type=0, mi=MOUSEINPUT(0, 0, (amount * 120) & 0xFFFFFFFF, 0x0800, 0, 0)))
