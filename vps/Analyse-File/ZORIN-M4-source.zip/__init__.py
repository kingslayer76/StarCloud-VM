"""Local persistent memory, feedback and versioned task recipes."""
