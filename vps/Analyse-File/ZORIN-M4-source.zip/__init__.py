"""Visible Windows input and verification."""
