"""Local endpointed speech with independent capture and playback."""
