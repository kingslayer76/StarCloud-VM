from .base import ChatProvider, ProviderFailure
from .groq_provider import GroqProvider
from .gemini_provider import GeminiProvider
from .openai_provider import OpenAIProvider
from .local_provider import LocalProvider

PROVIDERS = {"groq": GroqProvider, "gemini": GeminiProvider, "openai": OpenAIProvider, "local": LocalProvider}
