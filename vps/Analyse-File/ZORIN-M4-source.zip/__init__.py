"""Behavioral controls, not simulated emotional experience."""
