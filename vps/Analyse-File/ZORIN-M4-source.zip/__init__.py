"""Fast routing and validated model planning."""
