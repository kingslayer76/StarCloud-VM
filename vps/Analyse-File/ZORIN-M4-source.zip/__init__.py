"""Optional loopback transport for a future tablet client."""
