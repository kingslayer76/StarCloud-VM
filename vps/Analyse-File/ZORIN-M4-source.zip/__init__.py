"""On-demand UI Automation and cropped screenshot perception."""
