"""ZORIN-M4 runtime."""
import os

# Configure before NumPy/ONNX imports. Large inherited BLAS pools waste memory
# on a desktop already sharing its RAM and CPU with the user's applications.
_threads = os.getenv("ZORIN_BLAS_THREADS", "2")
if not _threads.isdecimal() or not 1 <= int(_threads) <= 4:
    _threads = "2"
for _variable in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS"):
    os.environ[_variable] = _threads
