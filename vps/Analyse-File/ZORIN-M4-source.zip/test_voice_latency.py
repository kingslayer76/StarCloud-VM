import asyncio
import json
from unittest.mock import AsyncMock
import httpx
import pytest
from core.config import Config, VoiceConfig
from core.events import EventBus
from voice.stt import SpeechToText
from voice.commands import voice_command
from voice.tts import SpeechOutput
from brain.intent import IntentRouter
from brain.planner import Planner
from memory.manager import Memory
from persona.personality import Personality


async def test_cloud_stt_sends_multilingual_context_without_forcing_english(monkeypatch):
    monkeypatch.setenv('GROQ_API_KEY', 'test-key')
    def handle(request):
        assert request.url.host == 'api.groq.com'
        assert b'whisper-large-v3' in request.content
        assert b'YouTube' in request.content
        assert b'name="language"' not in request.content
        return httpx.Response(200, json={'text': 'YouTube खोलो।', 'segments': [{'no_speech_prob': .01, 'avg_logprob': -.2}]})
    stt = SpeechToText(VoiceConfig(stt_provider='groq'), EventBus(), httpx.MockTransport(handle))
    try:
        assert await stt.transcribe(bytes(32000)) == 'YouTube खोलो।'
        assert stt.last_result['provider'] == 'groq'
    finally:
        await stt.close()


async def test_cloud_rate_limit_falls_back_and_next_segment_skips_cloud(monkeypatch):
    monkeypatch.setenv('GROQ_API_KEY', 'test-key')
    seen = []
    def handle(request):
        seen.append(request.url.host)
        if request.url.host == 'api.groq.com':
            return httpx.Response(429, headers={'retry-after': '120'})
        return httpx.Response(200, json={'text': 'Zorin ruko.'})
    stt = SpeechToText(VoiceConfig(stt_provider='groq'), EventBus(), httpx.MockTransport(handle))
    try:
        assert await stt.transcribe(bytes(32000)) == 'Zorin ruko.'
        assert await stt.transcribe(bytes(32000)) == 'Zorin ruko.'
        assert seen == ['api.groq.com', '127.0.0.1', '127.0.0.1']
    finally:
        await stt.close()


async def test_local_only_never_sends_audio_to_cloud_on_failure():
    seen = []
    def handle(request):
        seen.append(request.url.host)
        return httpx.Response(503)
    stt = SpeechToText(VoiceConfig(stt_provider='local_whisper', cloud_stt_fallback=False), EventBus(), httpx.MockTransport(handle))
    try:
        assert await stt.transcribe(bytes(32000)) == ''
        assert seen == ['127.0.0.1']
    finally:
        await stt.close()


async def test_low_confidence_silence_is_not_dispatched_as_thank_you(monkeypatch):
    monkeypatch.setenv('GROQ_API_KEY', 'test-key')
    payload = {'text': 'Thank you.', 'segments': [{'no_speech_prob': .95, 'avg_logprob': -1.8}]}
    stt = SpeechToText(VoiceConfig(stt_provider='groq'), EventBus(), httpx.MockTransport(lambda r: httpx.Response(200, json=payload)))
    try:
        assert await stt.transcribe(bytes(32000)) == ''
        assert stt.last_result['rejected_as_noise']
    finally:
        await stt.close()


@pytest.mark.parametrize('text', ['Hello M4.', 'Hello, M four.', 'Hello Zorin.'])
def test_named_greetings_are_admitted_while_busy(text):
    assert voice_command(text, busy=True) == 'Hello'


@pytest.mark.parametrize('text', ['Open YouTube.', 'YouTube kholo.', 'यूट्यूब खोलो।', 'YouTube खोल दो।'])
def test_youtube_is_a_verified_browser_plan_not_an_installed_app(text):
    memory = Memory(':memory:', enabled=False)
    try:
        plan = IntentRouter(Config().automation, memory).route(text)
        assert [a.kind for a in plan.actions] == ['open_app', 'navigate']
        assert plan.actions[1].target == 'https://www.youtube.com/'
        assert plan.actions[-1].expected.kind == 'url'
        assert plan.actions[-1].expected.value == 'https://www.youtube.com/'
        assert plan.complete
    finally:
        memory.close()


def test_misheard_youtube_poll_requests_clarification_without_actions():
    memory = Memory(':memory:', enabled=False)
    try:
        plan = IntentRouter(Config().automation, memory).route('YouTube poll.')
        assert not plan.actions
        assert '?' in plan.reply
    finally:
        memory.close()


async def test_greeting_needs_neither_model_nor_screen(tmp_path):
    from core.orchestrator import Assistant
    class Speech:
        speaking = False
        def say(self, text): pass
        def stop(self): pass
        async def close(self): pass
    class Desktop:
        async def observe(self): raise AssertionError('Greeting must not inspect the screen')
        async def close(self): pass
    config = Config()
    config.memory.database = str(tmp_path/'memory.db')
    assistant = Assistant(config, Desktop(), providers={}, speech=Speech())
    try:
        await assistant.submit('Hello M4.', source='voice')
        assert assistant.last_response == 'हाँ, बोलो।'
        assert assistant.task is None
        assert assistant.state.outcome == 'success'
    finally:
        await assistant.close()


def test_conversation_routing_and_configured_hinglish():
    memory = Memory(':memory:', enabled=False)
    try:
        personality = Personality(Config(), memory)
        assert 'modern Hindi/Hinglish' in personality.language_instruction('Hello')
        assert personality.language_instruction('Reply in English') == 'Reply in conversational English.'
        assert Planner.is_conversation('That was a long day, bro')
        assert Planner.is_conversation('Why is the sky blue?')
        assert not Planner.is_conversation('Open Chrome and search for the sky')
    finally:
        memory.close()


async def test_fixed_voice_cache_survives_restart_without_network_and_keeps_actual_model(tmp_path, monkeypatch):
    monkeypatch.setenv('GEMINI_API_KEY', 'test-key')
    config = VoiceConfig(tts_provider='gemini', tts_fallbacks=[], tts_cache_directory=str(tmp_path))
    first = SpeechOutput(config, EventBus())
    first.providers['gemini'].synthesize_async = AsyncMock(return_value=([0.0]*240, 24000))
    first.providers['gemini'].last_model = 'gemini-2.5-flash-preview-tts'
    first.playback.play = AsyncMock()
    try:
        first.say('हाँ, बोलो।')
        await first.task
    finally:
        await first.close()
    second = SpeechOutput(config, EventBus())
    second.providers['gemini'].synthesize_async = AsyncMock(side_effect=AssertionError('No new synthesis'))
    second.playback.play = AsyncMock()
    try:
        second.failed_until['gemini'] = 1e20
        second.say('हाँ, बोलो।')
        await second.task
        second.providers['gemini'].synthesize_async.assert_not_awaited()
        second.playback.play.assert_awaited_once()
        assert second.last_backend == ('gemini', 'gemini-2.5-flash-preview-tts')
        changed = config.model_copy(update={'gemini_tts_voice': 'Achird'})
        assert first._cache_path('gemini', 'हाँ, बोलो।') != SpeechOutput(changed, EventBus())._cache_path('gemini', 'हाँ, बोलो।')
    finally:
        await second.close()


async def test_personal_conversation_audio_is_not_saved(tmp_path):
    speech = SpeechOutput(VoiceConfig(tts_provider='edge', tts_fallbacks=[], tts_cache_directory=str(tmp_path)), EventBus())
    speech.providers['edge'].synthesize_async = AsyncMock(return_value=([0.0], 24000))
    speech.playback.play = AsyncMock()
    try:
        speech.say('Your personal conversation goes here.')
        await speech.task
        assert not list(tmp_path.iterdir())
    finally:
        await speech.close()
