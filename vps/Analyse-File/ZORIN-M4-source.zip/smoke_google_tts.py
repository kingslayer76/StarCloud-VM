"""Play Google Translate speech with casual Hindi; no microphone or desktop actions."""
import asyncio
import argparse
import json
from pathlib import Path
import sys
import time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.config import ROOT, load_config
from core.state_machine import Cancellation
from voice.playback import Playback
from voice.tts import GoogleTTSProvider, GeminiTTSProvider


async def run(gemini=False):
    import soundfile as sf
    config = load_config().voice
    provider = GeminiTTSProvider(config) if gemini else GoogleTTSProvider(config)
    results = []
    for name, text in [("casual-hindi", "हाँ भाई, बोलो, क्या हुआ? आराम से बताओ, कोई जल्दी नहीं है।"),
                       ("casual-hinglish", "आज का दिन थोड़ा heavy था, हाँ? चलो, काम की बात बाद में, पहले बताओ क्या scene है।")]:
        start = time.monotonic()
        audio, rate = await provider.synthesize_async(text) if gemini else await asyncio.to_thread(provider.synthesize, text)
        path = ROOT / f"data/{'gemini' if gemini else 'google'}-{name}.wav"
        sf.write(path, audio, rate)
        result = {"sample": name, "provider": "Gemini expressive speech" if gemini else "Google Translate (gTTS), not Gemini or Cloud TTS",
                  "text": text, "generation_seconds": round(time.monotonic()-start, 2), "path": str(path)}
        results.append(result)
        print(json.dumps(result, ensure_ascii=False), flush=True)
        await Playback(config.output_device).play(audio, rate, Cancellation())
    (ROOT / f"data/{'gemini' if gemini else 'google'}-tts-smoke.json").write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--gemini", action="store_true", help="Use expressive Google speech with GEMINI_API_KEY from .env")
    asyncio.run(run(parser.parse_args().gemini))
