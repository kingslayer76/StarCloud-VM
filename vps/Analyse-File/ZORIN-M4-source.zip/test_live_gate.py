import asyncio
import json
from unittest.mock import AsyncMock, Mock
import pytest
from core.config import VoiceConfig
from core.events import EventBus
from voice.live import LiveVoice
from voice.live_gate import LiveSpeechGate

SPEECH = b'\xe8\x03'*480
QUIET = bytes(960)


def gate():
    return LiveSpeechGate(VoiceConfig(), classifier=lambda f: f != QUIET)


def test_impulse_does_not_start_activity_and_speech_has_preroll():
    g = gate()
    assert not g.feed(QUIET*10+SPEECH+QUIET*20)
    events = g.feed(SPEECH*10+QUIET*20)
    assert [k for k, _ in events].count('start') == 1
    assert events[-1][0] == 'end'
    assert b''.join(d for k,d in events if k=='audio').count(SPEECH) >= 10


def test_low_level_background_speech_is_not_admitted():
    g = gate()
    assert not g.feed(b'\x40\x00'*480*100)


def test_protected_speech_stays_held_even_when_reply_finishes():
    g = gate()
    assert not g.feed(SPEECH*15, protected=True)
    result = g.feed(QUIET*20, protected=False)
    assert [kind for kind,_ in result] == ['candidate']
    assert SPEECH in result[0][1]


def test_reset_discards_partial_interruption():
    g = gate()
    g.feed(SPEECH*15, protected=True)
    g.reset()
    assert not g.feed(QUIET*30)


def voice(monkeypatch, transcript):
    monkeypatch.setenv('GROQ_API_KEY', 'test-only-key')
    v=LiveVoice(VoiceConfig(), EventBus(), instruction=lambda:'', tools=[], on_text=AsyncMock(),
                on_tool=AsyncMock(), on_interrupt=Mock())
    v.connected.set()
    v.socket=Mock(send=AsyncMock())
    v.interruption_stt=Mock(transcribe=AsyncMock(return_value=transcript), close=AsyncMock())
    return v


@pytest.mark.asyncio
async def test_background_conversation_cannot_clear_output_or_reach_gemini(monkeypatch):
    v=voice(monkeypatch, 'What are we having for dinner?')
    v.output.push(SPEECH)
    await v._confirm_interruption(SPEECH*20, v.epoch, v.connection_epoch)
    assert v.output.samples == 480
    v.on_interrupt.assert_not_called()
    v.socket.send.assert_not_awaited()
    assert v.rejected_interruptions == 1


@pytest.mark.asyncio
async def test_named_interruption_sends_bounded_activity(monkeypatch):
    v=voice(monkeypatch, 'Zorin, ruko.')
    v.output.push(SPEECH)
    await v._confirm_interruption(SPEECH*20, v.epoch, v.connection_epoch)
    assert v.output.samples == 0
    v.on_interrupt.assert_called_once()
    packets=[json.loads(c.args[0])['realtimeInput'] for c in v.socket.send.await_args_list]
    assert list(packets[0]) == ['activityStart']
    assert list(packets[1]) == ['audio']
    assert list(packets[2]) == ['activityEnd']


@pytest.mark.asyncio
async def test_stale_recognition_cannot_interrupt_after_mute(monkeypatch):
    v=voice(monkeypatch, 'Zorin stop')
    epoch=v.epoch
    v.invalidate_pending()
    await v._confirm_interruption(SPEECH, epoch, v.connection_epoch)
    v.socket.send.assert_not_awaited()
    v.on_interrupt.assert_not_called()


@pytest.mark.asyncio
async def test_noise_frames_never_sent_on_socket(monkeypatch):
    v=voice(monkeypatch, '')
    v.gate=gate()
    await v.process_microphone(QUIET*20+SPEECH+QUIET*20, v.epoch)
    v.socket.send.assert_not_awaited()
