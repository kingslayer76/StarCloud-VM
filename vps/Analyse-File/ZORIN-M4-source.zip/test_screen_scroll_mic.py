import asyncio
import json
from io import BytesIO
from unittest.mock import Mock, AsyncMock
import numpy as np
import pytest
from PIL import Image
from core.config import Config, VoiceConfig
from core.events import EventBus
from core.live_assistant import LiveAssistant
from brain.desktop_language import ordinal_request, scroll_request
from perception.screen import scrolled, same_visual_frame, anchors_scrolled
from voice.live_gate import LiveSpeechGate
from voice.live import LiveVoice


@pytest.mark.parametrize('phrase,index',[('play video number 8',8),('8 wala video chalao',8),('video 4 chalao',4),('play the second video',2),('play eight video',8)])
def test_numbered_video_variants(phrase,index):
    assert ordinal_request(phrase)==('video',index)


@pytest.mark.parametrize('phrase,amount',[('neeche scroll karo',-3),('ऊपर स्क्रॉल करो',3),('scroll down',-3)])
def test_natural_scroll(phrase,amount):
    assert scroll_request(phrase)==amount


def test_scroll_detection_requires_vertical_movement_in_requested_direction():
    rng=np.random.default_rng(3)
    before=rng.uniform(0,255,(140,120)).astype(np.float32)
    after=np.concatenate([before[24:],np.zeros((24,120),dtype=np.float32)])
    assert scrolled(before,after,-3)
    assert not scrolled(before,after,3)
    assert not scrolled(before,before,-3)
    assert not scrolled(before,rng.uniform(0,255,before.shape),-3)


def test_scroll_anchors_confirm_up_and_reject_changed_or_stationary_labels():
    before={('link','one'):[(100,100)],('link','two'):[(300,100)],('link','fixed'):[(10,10)]}
    after={('link','one'):[(100,300)],('link','two'):[(300,300)],('link','fixed'):[(10,10)]}
    assert anchors_scrolled(before,after,3)
    assert not anchors_scrolled(before,after,-3)
    assert not anchors_scrolled(before,before,3)


def test_quiet_speech_is_admitted_but_quiet_noise_is_not():
    config=VoiceConfig(live_min_energy=100)
    quiet=(np.ones(480,dtype='<i2')*150).tobytes()
    speech=LiveSpeechGate(config,classifier=lambda f:True)
    noise=LiveSpeechGate(config,classifier=lambda f:False)
    assert any(k=='start' for k,_ in speech.feed(quiet*10))
    assert not noise.feed(quiet*30)


def test_quiet_phrase_tail_keeps_the_turn_open():
    g=LiveSpeechGate(VoiceConfig(live_min_energy=100),classifier=lambda f:True)
    g.feed((np.ones(480,dtype='<i2')*200).tobytes()*10)
    assert g.active
    result=g.feed((np.ones(480,dtype='<i2')*85).tobytes()*30)
    assert g.active and not any(k=='end' for k,_ in result)


@pytest.mark.asyncio
async def test_screen_frames_use_video_packet_without_creating_audio_activity():
    v=LiveVoice(VoiceConfig(),EventBus(),instruction=lambda:'',tools=[],on_text=AsyncMock(),on_tool=AsyncMock(),on_interrupt=Mock())
    v.connected.set(); v.socket=Mock(send=AsyncMock())
    await v.screen_frame(b'jpeg-test')
    packet=json.loads(v.socket.send.call_args.args[0])
    assert set(packet['realtimeInput'])=={'video'}
    assert packet['realtimeInput']['video']['mimeType']=='image/jpeg'
    quiet=(np.ones(480,dtype='<i2')*150).tobytes()
    assert np.max(np.frombuffer(v.amplify_speech(quiet),dtype='<i2'))==300
    loud=(np.ones(480,dtype='<i2')*31000).tobytes()
    assert np.max(np.frombuffer(v.amplify_speech(loud),dtype='<i2'))<=30000


@pytest.mark.asyncio
async def test_screen_off_also_disables_visual_controller_and_persists(tmp_path):
    c=Config();c.privacy.live_screen_sharing=True;c.privacy.cloud_vision=True
    c.memory.database=str(tmp_path/'memory.db')
    a=LiveAssistant(c,Mock(close=AsyncMock()))
    try:
        await a.submit('/screen off')
        assert not a.screen_sharing and not a.worker.config.privacy.cloud_vision
        assert a.memory.preferences()['screen_sharing_enabled'] is False
        await a.submit('/screen on')
        assert a.screen_sharing and a.worker.config.privacy.cloud_vision
    finally:
        await a.close()


def test_large_visual_change_invalidates_the_old_target_frame():
    def png(color):
        out=BytesIO();Image.new('RGB',(160,100),color).save(out,format='PNG');return out.getvalue()
    assert same_visual_frame(png('black'),png('black'))
    assert not same_visual_frame(png('black'),png('white'))


@pytest.mark.asyncio
async def test_vision_converts_normalized_box_and_rejects_invalid_geometry():
    from perception.vision import Vision, VisualBox
    from pydantic import ValidationError
    c=Config().privacy;c.cloud_vision=True;c.vision_provider='gemini'
    provider=Mock(configured=True,complete=AsyncMock(return_value=json.dumps({
        'found':True,'coordinate_system':'normalized_1000','box':[100,200,300,600],
        'confidence':.95,'label':'Video title'})))
    v=await Vision(c,{'gemini':provider}).locate(b'png','second video')
    assert (v.x,v.y)==(.4,.2) and v._reference_png==b'png'
    with pytest.raises(ValidationError):
        VisualBox(found=True,coordinate_system='normalized_1000',box=[300,200,100,600],confidence=.95,label='Bad')
