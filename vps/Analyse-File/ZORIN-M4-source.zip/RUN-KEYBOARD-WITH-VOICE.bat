@echo off
call "%~dp0run.bat" --keyboard
