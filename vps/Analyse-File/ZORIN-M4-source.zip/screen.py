from io import BytesIO
from PIL import ImageGrab


def shared_frame(desktop):
    from persona.companion import activity_context
    import hashlib
    before=desktop.activity()
    if not activity_context(before):
        raise PermissionError('This window is excluded from screen sharing')
    png,bbox=capture_window(desktop)
    after=desktop.activity()
    if after.get('hwnd') != before.get('hwnd') or not activity_context(after):
        raise PermissionError('Window changed during capture')
    from PIL import Image
    image=Image.open(BytesIO(png)).convert('RGB')
    image.thumbnail((1280,960))
    out=BytesIO(); image.save(out,format='JPEG',quality=75)
    jpeg=out.getvalue()
    return jpeg,hashlib.sha256(jpeg).hexdigest(),before['hwnd']


def scroll_sample(bbox):
    import numpy as np
    image=ImageGrab.grab(bbox=bbox,all_screens=True).convert('L')
    image.thumbnail((160,160))
    return np.asarray(image,dtype=np.float32)


def scrolled(before, after, direction):
    """Require coherent vertical translation, not animation or arbitrary change."""
    import numpy as np
    if before.shape != after.shape or before.size == 0:
        return False
    height,width=before.shape
    left,right=width//8,width-width//8
    baseline=float(np.mean(np.abs(before[:,left:right]-after[:,left:right])))
    if baseline < 3:
        return False
    for shift in range(2,max(3,height//2)):
        a,b=(before[shift:,left:right],after[:-shift,left:right]) if direction<0 else (before[:-shift,left:right],after[shift:,left:right])
        error=float(np.mean(np.abs(a-b)))
        if error < 18 and error < baseline*.60:
            return True
    return False


def same_visual_frame(reference, current):
    import numpy as np
    from PIL import Image
    images=[np.asarray(Image.open(BytesIO(p)).convert('L').resize((160,100)),dtype=np.float32) for p in (reference,current)]
    return float(np.mean(np.abs(images[0]-images[1])>30)) < .04


def anchors_scrolled(before, after, direction):
    shifts=[]
    for key,positions in before.items():
        current=after.get(key,[])
        if len(positions)!=1 or len(current)!=1:
            continue
        x,y=positions[0]; nx,ny=current[0]
        shift=y-ny
        if abs(x-nx)<=6 and abs(shift)>10 and shift*direction<0:
            shifts.append(shift)
    return any(sum(abs(other-shift)<15 for other in shifts)>=2 for shift in shifts)


def capture_window(desktop):
    if desktop.secure_desktop():
        raise PermissionError("Cannot capture protected desktop")
    focus = desktop.auto.GetFocusedControl()
    if focus and focus.IsPassword:
        raise PermissionError("Cannot capture a password-entry surface")
    control = desktop.foreground()
    rect = control.BoundingRectangle
    bbox = (rect.left, rect.top, rect.right, rect.bottom)
    image = ImageGrab.grab(bbox=bbox, all_screens=True)
    output = BytesIO()
    image.save(output, format="PNG")
    return output.getvalue(), bbox
