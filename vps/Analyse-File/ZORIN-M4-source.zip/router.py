import time
from brain.providers import PROVIDERS, ProviderFailure


class AllProvidersUnavailable(Exception):
    pass


class ProviderRouter:
    def __init__(self, config, bus, providers=None):
        self.bus = bus
        self.order = list(dict.fromkeys([config.primary_provider] + config.fallback_providers))
        self.providers = providers if providers is not None else {
            name: PROVIDERS[name](cfg, config.timeout) for name, cfg in config.providers.items() if name in PROVIDERS
        }
        self.cooldown = {}
        self.last_failure = ""
        self.local_recovery = None

    async def complete(self, messages, validate=None, local_messages=None, conversation=False, local_only=False):
        for name in (["local"] if local_only else self.order):
            provider = self.providers.get(name)
            if name == "local" and self.local_recovery:
                try:
                    if await self.local_recovery():
                        self.cooldown.pop(name, None)
                except Exception:
                    self.bus.emit("provider", provider=name, status="local restart failed")
            if not provider or not provider.configured or self.cooldown.get(name, 0) > time.monotonic():
                if provider and provider.configured and self.cooldown.get(name, 0) > time.monotonic():
                    self.bus.emit("provider", provider=name, status="temporarily cooling down after a failed request")
                continue
            try:
                started = time.monotonic()
                selected = local_messages if name == "local" and local_messages is not None else messages
                raw = await provider.complete(selected, json_mode=False) if conversation else await provider.complete(selected)
                try:
                    result = validate(raw) if validate else raw
                except ValueError as error:
                    if conversation or name == 'local':
                        raise
                    issues = '; '.join('.'.join(map(str, e['loc']))+': '+e['msg']
                        for e in error.errors(include_input=False, include_url=False)[:3]) if hasattr(error, 'errors') else 'invalid JSON'
                    self.bus.emit('provider', provider=name, status='correcting invalid plan')
                    correction = selected + [{'role':'assistant','content':raw[:8000]},
                        {'role':'user','content':'No actions from this plan were executed. Correct its JSON/schema errors once, preserving the original user request and safety rules. Validation: '+issues+
                         '. Navigation target and expected URL must be the same complete http:// or https:// URL. Do not put a search phrase in navigate; use an encoded search URL or visible search controls.'}]
                    raw = await provider.complete(correction)
                    result = validate(raw)
                self.last_failure = ""
                self.bus.emit("provider", provider=name, status="success")
                self.bus.emit("latency", stage="reasoning", provider=name, seconds=round(time.monotonic()-started, 3))
                return result
            except ProviderFailure as error:
                self.last_failure = error.reason
                self.cooldown[name] = time.monotonic() + error.cooldown
                self.bus.emit("provider", provider=name, status=error.reason)
            except ValueError as error:
                self.last_failure = "invalid plan"
                self.cooldown[name] = time.monotonic() + 15
                issues = "; ".join(".".join(map(str, e["loc"])) + ": " + e["msg"]
                                   for e in error.errors(include_input=False, include_url=False)[:3]) if hasattr(error, "errors") else "invalid JSON"
                self.bus.emit("provider", provider=name, status="invalid plan; falling back", detail=issues)
        raise AllProvidersUnavailable("No configured brain provider is available. Local commands still work.")

    async def close(self):
        for provider in self.providers.values():
            await provider.close()
