import os
import re

SECRET_PATTERN = re.compile(r"(?i)(?:\b(?:password|passwd|api[_ -]?key|secret|otp)\s*[:=]\s*\S+|\b(?:sk-|gsk_)[A-Za-z0-9_-]{12,})")


def sensitive_text(text: str) -> bool:
    return bool(SECRET_PATTERN.search(text)) or any(
        value and len(value) > 8 and value in text
        for name, value in os.environ.items() if name.endswith(("_KEY", "_TOKEN", "_SECRET"))
    )


def redact(text: str) -> str:
    text = SECRET_PATTERN.sub("[REDACTED]", str(text))
    for name, value in os.environ.items():
        if name.endswith(("_KEY", "_TOKEN", "_SECRET")) and len(value) > 8:
            text = text.replace(value, "[REDACTED]")
    return text
