"""Open one public documentation tab and test unsolicited title-aware conversation."""
import asyncio
import json
from pathlib import Path
import sys
import time
import webbrowser
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.config import ROOT, load_config
from core.instance import InstanceLease
from core.orchestrator import Assistant
from hands.executor import WindowsExecutor


async def run():
    config = load_config()
    config.memory.enabled = False
    config.voice.enabled = False  # Verify conversation generation without spending speech quota.
    lease = InstanceLease()
    assistant = Assistant(config, WindowsExecutor(config.automation, config.privacy))
    try:
        await assistant._consider_activity(await assistant.executor.activity())
        started = time.monotonic()
        webbrowser.open('https://docs.python.org/3/library/asyncio.html', new=2)
        for _ in range(20):
            await asyncio.sleep(1)
            await assistant._consider_activity(await assistant.executor.activity())
            if assistant.companion_task:
                await assistant.companion_task
                if assistant.last_response:
                    break
        result = {'activity_comment_generated': bool(assistant.last_response), 'reply': assistant.last_response,
                  'seconds_from_open': round(time.monotonic()-started, 3), 'spoken': False,
                  'user_command_submitted': False, 'note': 'The test requested a public documentation tab, but comments follow the actual foreground app, including user switches during the test. The companion itself had no action executor calls.'}
        print(json.dumps(result, indent=2, ensure_ascii=False), flush=True)
        (ROOT/'data/activity-live-check.json').write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding='utf-8')
        return int(not result['activity_comment_generated'])
    finally:
        await assistant.close()
        lease.close()


if __name__ == '__main__':
    raise SystemExit(asyncio.run(run()))
