import pytest
from core.config import Config
from brain.planner import Planner
from brain.schemas import Plan
from memory.manager import Memory
from persona.personality import Personality


@pytest.mark.parametrize("goal,conversation", [("कैसे हो?", True), ("आज का दिन बहुत heavy था।", True),
    ("आज का दिन heavy था, Chrome खोलो।", False)])
async def test_native_hindi_chat_uses_plain_replies_but_tasks_keep_planning(goal, conversation):
    class Router:
        used_conversation = False
        async def complete(self, messages, validate=None, **kwargs):
            self.used_conversation = kwargs.get("conversation", False)
            return Plan(reply="हाँ, बोलो।", actions=[], complete=True)
    memory = Memory(":memory:", enabled=False)
    router = Router()
    config = Config()
    try:
        planner = Planner(router, Personality(config, memory), memory, config)
        await planner.plan(goal, [{"role": "user", "content": goal}], {}, [])
        assert router.used_conversation is conversation
    finally:
        memory.close()


def test_explicit_hindi_memory_survives_restart(tmp_path):
    path = tmp_path / "memory.db"
    memory = Memory(path)
    assert memory.ingest("याद रखना, मुझे छोटे जवाब पसंद हैं।") == "याद रखूँगा।"
    memory.close()
    memory = Memory(path)
    try:
        assert memory.preference("response_length") == "short"
        assert any("छोटे जवाब" in item["content"] for item in memory.retrieve("जवाब"))
    finally:
        memory.close()
