"""Visible Notepad control lookup/click test, without changing any settings."""
import asyncio
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from brain.schemas import action
from core.config import ROOT, load_config
from core.state_machine import Cancellation
from hands.executor import WindowsExecutor
from brain.intent import IntentRouter
from memory.manager import Memory


async def run():
    config = load_config()
    executor = WindowsExecutor(config.automation, config.privacy)
    memory = Memory(":memory:", enabled=False)
    token = Cancellation()
    results = []
    try:
        launch = IntentRouter(config.automation, memory).open_action("Notepad")
        for step in [launch, action("click", target="Settings", expected_kind="element", expected_value="Appearance")]:
            outcome = await executor.execute(step, token, "Open Notepad settings for a smoke test")
            result = {"action": step.kind, "target": step.target, "success": outcome.success, "summary": outcome.summary}
            results.append(result)
            print(json.dumps(result), flush=True)
            if not outcome.success:
                print(json.dumps({"foreground_process": outcome.observation.get("process"),
                                  "visible_controls": [e["name"] for e in outcome.observation.get("elements", [])]}), flush=True)
                break
        (ROOT / "data/settings-smoke.json").write_text(json.dumps(results, indent=2))
        return 0 if len(results) == 2 and all(r["success"] for r in results) else 1
    finally:
        await executor.close()
        memory.close()


if __name__ == "__main__":
    raise SystemExit(asyncio.run(run()))
