"""Read Windows' app catalogue once; model-provided names never become commands."""
import json
import subprocess
import time
import os


class AppCatalogue:
    def __init__(self):
        self.apps = []
        self.loaded_at = 0.

    def resolve(self, name):
        if time.monotonic() - self.loaded_at > 300:
            result = subprocess.run(["powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive", "-Command",
                "[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new(); Get-StartApps | Select-Object Name,AppID | ConvertTo-Json -Compress"],
                capture_output=True, text=True, encoding="utf-8", timeout=12,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), check=True)
            data = json.loads(result.stdout.lstrip("\ufeff"))
            self.apps = data if isinstance(data, list) else [data]
            self.loaded_at = time.monotonic()
        matches = [app for app in self.apps if app["Name"].casefold() == name.casefold()
                   and not app["AppID"].casefold().startswith(("http:", "https:"))]
        return matches[0] if len(matches) == 1 else None

    @staticmethod
    def launch_registered(app):
        # The identifier comes exclusively from Get-StartApps, never model text.
        if not app or app["AppID"].casefold().startswith(("http:", "https:")):
            raise ValueError("No installed application to launch")
        os.startfile("shell:AppsFolder\\" + app["AppID"])
