import asyncio
import threading
import queue
import time
import numpy as np


class Playback:
    def __init__(self, device=None):
        self.device = device
        self.stopped = threading.Event()
        self.stream = None
        self.lock = asyncio.Lock()

    def stop(self):
        self.stopped.set()
        if self.stream:
            try:
                self.stream.abort()
            except Exception:
                pass

    async def play(self, samples, rate, token):
        async with self.lock:
            token.check()
            self.stopped.clear()
            worker = asyncio.create_task(asyncio.to_thread(self._play, samples, rate, token))
            try:
                await asyncio.shield(worker)
            except asyncio.CancelledError:
                self.stop()
                await asyncio.gather(worker, return_exceptions=True)
                raise

    async def play_stream(self, chunks, rate, token):
        """One output stream for a whole reply, with a small initial buffer."""
        async with self.lock:
            token.check()
            self.stopped.clear()
            pending = queue.Queue()
            finished = threading.Event()
            worker = None
            count = 0
            stats = {"underruns": 0, "started_at": None}
            try:
                async for samples in chunks:
                    token.check()
                    samples = np.asarray(samples, dtype=np.float32).reshape(-1, 1)
                    count += len(samples)
                    pending.put(samples)
                    if worker is None and count >= rate//4:
                        worker = asyncio.create_task(asyncio.to_thread(self._play_stream, pending, finished, rate, token, stats))
                finished.set()
                if worker is None and count:
                    worker = asyncio.create_task(asyncio.to_thread(self._play_stream, pending, finished, rate, token, stats))
                if worker:
                    await asyncio.shield(worker)
                return stats
            except BaseException:
                self.stop()
                finished.set()
                if worker:
                    await asyncio.gather(worker, return_exceptions=True)
                raise

    def _play_stream(self, pending, finished, rate, token, stats):
        import sounddevice as sd
        with sd.OutputStream(samplerate=rate, channels=1, dtype="float32", device=self.device, latency=.1) as stream:
            self.stream = stream
            try:
                while not self.stopped.is_set():
                    token.check()
                    try:
                        samples = pending.get(timeout=.05)
                    except queue.Empty:
                        if finished.is_set():
                            break
                        continue
                    for offset in range(0, len(samples), rate//10):
                        token.check()
                        if self.stopped.is_set():
                            return
                        if stats["started_at"] is None:
                            stats["started_at"] = time.monotonic()
                        if stream.write(samples[offset:offset+rate//10]):
                            stats["underruns"] += 1
            finally:
                self.stream = None

    def _play(self, samples, rate, token):
        import sounddevice as sd
        samples = np.asarray(samples, dtype=np.float32).reshape(-1, 1)
        offset = 0
        def callback(outdata, frames, timing, status):
            nonlocal offset
            outdata.fill(0)
            if self.stopped.is_set() or token.event.is_set():
                raise sd.CallbackStop
            count = min(frames, len(samples) - offset)
            outdata[:count] = samples[offset:offset+count]
            offset += count
            if offset >= len(samples):
                raise sd.CallbackStop
        with sd.OutputStream(samplerate=rate, channels=1, dtype="float32", device=self.device,
                             blocksize=max(128, rate//100), callback=callback, latency="low") as stream:
            self.stream = stream
            try:
                while stream.active and not self.stopped.wait(.02):
                    token.check()
            finally:
                self.stream = None
