"""Navigation language, separated from literal app names and typed payloads."""
import re
from urllib.parse import urlparse, urlencode

SITES = {"youtube": "https://www.youtube.com/", "google": "https://www.google.com/",
         "github": "https://github.com/", "wikipedia": "https://www.wikipedia.org/"}
NUMBERS = {"first": 1, "second": 2, "third": 3, "fourth": 4, "fifth": 5,
           "sixth": 6, "seventh": 7, "eighth": 8, "ninth": 9, "tenth": 10,
           "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, 'six':6,'seven':7,'eight':8,'nine':9,'ten':10,
           "pehla": 1, "pehli": 1, "dusra": 2, "teesra": 3, "chautha": 4, "panchva": 5,
           "पहला": 1, "पहली": 1, "दूसरा": 2, "तीसरा": 3, "चौथा": 4, "पांचवा": 5, "पाँचवाँ": 5}


def clean_request(text):
    text = text.strip().rstrip('.!। ')
    if not re.search(r'https?://|\w\.\w', text):
        text = text.rstrip('? ')
    return re.sub(r'^(?:(?:can|could|would) you\s+|please\s+|(?:bro|bhai|yaar)[, ]+)+', '', text, flags=re.I)


def browser_request_text(text):
    text = clean_request(text)
    browser = r'(?:google\s+)?(?:chrome?|chorm|क्रोम)'
    on = r'(?:on|in|using|with|mein|me|pe|par|pa|में|पर|पे)'
    text = re.sub(rf'^{browser}\s+{on}\s+', '', text, flags=re.I)
    text = re.sub(rf'\s+{on}\s+{browser}$', '', text, flags=re.I)
    text = re.sub(rf'\s+{browser}\s+{on}(?=\s+(?:kholo|khole|khol|kol|open|search|खोल|सर्च))', '', text, flags=re.I)
    return text


def website_request(text):
    text = browser_request_text(text)
    text = re.sub(r'\b(?:you\s+tube|yotube)\b', 'youtube', text, flags=re.I)
    match = re.fullmatch(r'(?:open|launch|go to|navigate to)\s+(.+)|(.+?)\s+(?:kholo|khole|khol do|khol|kol|open kar)', text, re.I)
    if not match:
        return None
    name = (match[1] or match[2]).strip()
    if name.casefold() in SITES:
        return SITES[name.casefold()]
    if re.fullmatch(r'(?:https?://)?(?:[a-z0-9-]+\.)+[a-z]{2,}(?:/[^\s]*)?', name, re.I):
        url = name if '://' in name else 'https://'+name
        return url if urlparse(url).scheme in {'https', 'http'} else None
    return None


def search_request(text):
    """Explicit search remains a search; never turn arbitrary speech into a URL."""
    text = browser_request_text(text)
    match = re.fullmatch(r'(?:search(?: for)?|सर्च)\s+(.+)|(.+?)\s+(?:search|सर्च)\s+(?:kar|karo|kar do|कर|करो)', text, re.I)
    if not match:
        return None
    query = (match[1] or match[2]).strip()
    if re.search(r'\b(?:then|and then|phir)\b|फिर', query, re.I):
        return None
    return 'https://www.google.com/search?' + urlencode({'q': query})


def ordinal_request(text):
    text = clean_request(text).casefold()
    numbers = '|'.join(map(re.escape, NUMBERS))
    n = rf'(\d{{1,2}}(?:st|nd|rd|th)?|{numbers})'
    kind = r'(video|link|button|tab|item)'
    text=re.sub(r'\b(?:number|no\.)\s+', '', text)
    text=re.sub(r'\s+(?:wala|wali|वाला|वाली)\s+', ' ', text)
    patterns = [rf'(?:click(?: on)?|open|play|select) (?:the )?{n} {kind}',
                rf'(?:click(?: on)?|open|play|select) (?:the )?{kind} (?:number )?{n}',
                rf'{n} {kind} (?:kholo|chalao|chala do|play karo|पर क्लिक करो|चलाओ|खोलो)',
                rf'{kind} {n} (?:kholo|chalao|chala do|play karo|चलाओ)']
    for i, pattern in enumerate(patterns):
        m = re.fullmatch(pattern, text)
        if not m:
            continue
        number, category = (m[2],m[1]) if i in {1,3} else (m[1],m[2])
        value = NUMBERS.get(number) or int(re.sub(r'(st|nd|rd|th)$', '', number))
        if 1 <= value <= 30:
            return category, value
    return None


def scroll_request(text):
    text=clean_request(text).casefold()
    text=re.sub(r'स्क्रॉल', 'scroll',text)
    text=re.sub(r'\b(?:niche|neeche)\b|नीचे', 'down',text)
    text=re.sub(r'\b(?:upar|oopar)\b|ऊपर', 'up',text)
    text=re.sub(r'\s+(?:karo|kar|kar do|करो|कर)$', '',text)
    match=re.fullmatch(r'scroll (up|down)(?: (\d+))?|(up|down) scroll',text)
    if not match:
        return None
    direction=match[1] or match[3]
    return min(10,int(match[2] or 3))*(1 if direction=='up' else -1)
