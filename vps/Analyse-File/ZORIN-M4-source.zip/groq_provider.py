from .base import ChatProvider


class GroqProvider(ChatProvider):
    name = "groq"
