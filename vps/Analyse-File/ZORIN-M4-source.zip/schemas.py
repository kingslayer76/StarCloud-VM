from typing import Literal
from urllib.parse import urlparse
from pydantic import Field, model_validator
from core.config import Strict


class Expected(Strict):
    kind: Literal["window", "window_gone", "text", "element", "changed", "capture", "cursor", "volume", "url", "url_changed"]
    value: str = Field(default="", max_length=4000)


class Action(Strict):
    kind: Literal["open_app", "navigate", "focus_window", "click", "click_index", "double_click", "right_click", "hover", "drag", "scroll", "type_text", "key", "wait", "screenshot", "volume"]
    target: str = Field(default="", max_length=240, description="Required application/control NAME for open_app/focus_window/click/hover/drag. Example: Notepad or Settings. Never leave a targeted action unnamed.")
    text: str = Field(default="", max_length=4000, description="Literal text for type_text, or key chord for key. App/control names belong in target, not text.")
    destination: str = Field(default="", max_length=240)
    amount: int = Field(default=0, ge=-100, le=100)
    method: Literal["visible", "uia", "vision"] = "visible"
    timeout: float = Field(default=8, ge=.1, le=30)
    expected: Expected
    fallback: Literal["none", "redetect", "vision"] = "none"
    risk_level: Literal["normal", "sensitive"] = "normal"

    @model_validator(mode="after")
    def coherent(self):
        if self.kind == 'navigate':
            p = urlparse(self.target)
            if p.scheme not in {'http', 'https'} or not p.hostname or p.username or p.password or any(c.isspace() for c in self.target):
                raise ValueError('Browser navigation requires an ordinary HTTP(S) URL')
            if self.expected.kind != 'url' or self.expected.value != self.target:
                raise ValueError('Navigation must verify its exact destination URL')
        if self.kind == "click_index" and (self.target not in {"video", "link", "button", "tab", "item"} or not 1 <= self.amount <= 30):
            raise ValueError("Indexed click needs a supported category and index 1 to 30")
        if self.kind in {"open_app", "focus_window", "click", "double_click", "right_click", "hover", "drag"} and not self.target.strip():
            raise ValueError("This action needs a target")
        if self.kind in {"type_text", "key"} and not self.text:
            raise ValueError("This action needs text")
        if self.kind == "drag" and not self.destination:
            raise ValueError("Drag needs a named destination")
        if self.kind == "type_text" and self.expected.kind != "text":
            raise ValueError("Typing must verify the literal text")
        if self.kind == "type_text" and self.expected.value != self.text:
            raise ValueError("Typing verification must match exactly")
        if self.kind == "open_app" and self.expected.kind != "window":
            raise ValueError("Launch must verify a window")
        if self.expected.kind in {"window", "window_gone", "text", "element", "url"} and not self.expected.value:
            raise ValueError("Verification needs a nonempty value")
        return self


class Plan(Strict):
    reply: str = Field(default="", max_length=1200)
    actions: list[Action] = Field(default_factory=list, max_length=16)
    complete: bool = True


def action(kind, *, expected_kind="changed", expected_value="", **kwargs):
    return Action(kind=kind, expected=Expected(kind=expected_kind, value=expected_value), **kwargs)


def generation_schema():
    schema = Plan.model_json_schema()
    definition = schema["$defs"]["Action"]
    definition["required"] = list(dict.fromkeys(definition["required"] + ["target"]))
    definition["properties"]["target"].pop("default", None)
    definition["properties"]["target"]["minLength"] = 1
    return schema
