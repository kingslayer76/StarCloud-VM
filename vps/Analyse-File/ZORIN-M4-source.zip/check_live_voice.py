"""Synthetic text-to-native-audio probe. Never opens a mic or executes PC tools."""
import asyncio
import json
from pathlib import Path
import sys
import time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.config import load_config
from core.events import EventBus
from persona.live import STYLE, TOOLS
from voice.live import LiveVoice


async def main():
    config = load_config()
    bus = EventBus()
    events = bus.subscribe()
    turns = []
    result = {"model": config.voice.live_model, "voice": config.voice.live_voice, "microphone": False, "turns": turns}
    done = asyncio.Event()
    async def on_text(role, text):
        if role == "assistant":
            turns[-1]["reply"] = text
            done.set()
            print(text, flush=True)
    async def tool(name, args):
        turns[-1].setdefault("tools", []).append({"name": name, "args": args})
        return {"success": False, "status": "test_only", "detail": "Diagnostic test: no actual desktop action was performed."}
    live = LiveVoice(config.voice, bus, instruction=lambda: STYLE, tools=TOOLS,
                     on_text=on_text, on_tool=tool, on_interrupt=lambda: None)
    try:
        await live.start(microphone=False, playback="--play" in sys.argv)
        for prompt in ["यार आज coding करके दिमाग पक गया। normal Hindi में बात कर, formal नहीं।", "कुछ मज़ेदार देखते हैं, YouTube खोल दो।"]:
            done.clear()
            live.output.first_played_at = None
            before = time.monotonic()
            turns.append({"prompt": prompt})
            await live.text(prompt)
            await asyncio.wait_for(done.wait(), 30)
            turns[-1]["turn_seconds"] = round(time.monotonic()-before, 3)
            if "--play" in sys.argv:
                while live.output.speaking:
                    await asyncio.sleep(.1)
                turns[-1]["playback_start_seconds"] = round(live.output.first_played_at-before, 3) if live.output.first_played_at else None
            else:
                live.output.clear()
            turns[-1]["underruns"] = live.output.underruns
            while not events.empty():
                event = events.get_nowait()
                if event.type == "latency":
                    turns[-1]["first_audio_seconds"] = event.data["seconds"]
            print(json.dumps(turns[-1], ensure_ascii=False), flush=True)
        result["success"] = True
    except Exception as error:
        from safety.secrets import redact
        result["success"] = False
        result["error"] = redact(str(error)) or type(error).__name__
        while not events.empty():
            event = events.get_nowait()
            if event.type == "degraded":
                print(event.data, flush=True)
    finally:
        await live.close()
        Path("data/live-voice-check.json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
        print(json.dumps(result, ensure_ascii=False), flush=True)
    return 0 if result.get("success") else 1

if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
