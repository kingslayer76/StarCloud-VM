from .base import ChatProvider


class GeminiProvider(ChatProvider):
    """Google's documented OpenAI-compatible REST endpoint."""
    name = "gemini"
