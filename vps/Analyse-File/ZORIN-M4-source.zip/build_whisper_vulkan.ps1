param([string]$Revision = 'b4938')
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $projectRoot
if (-not (Get-Command cmake -ErrorAction SilentlyContinue)) { throw 'Install CMake and Visual Studio C++ Build Tools first.' }
if (-not $env:VULKAN_SDK) { throw 'Install the LunarG Vulkan SDK first, then open a new terminal.' }
if (-not (Test-Path -LiteralPath 'vendor\whisper-source')) {
    git clone --depth 1 --branch $Revision https://github.com/ggml-org/whisper.cpp.git vendor\whisper-source
    if ($LASTEXITCODE -ne 0) { throw 'whisper.cpp source download failed.' }
}
cmake -S vendor\whisper-source -B vendor\whisper-source\build -DGGML_VULKAN=ON -DWHISPER_BUILD_SERVER=ON -DGGML_NATIVE=OFF
if ($LASTEXITCODE -ne 0) { throw 'Vulkan configuration failed.' }
cmake --build vendor\whisper-source\build --config Release --parallel 4
if ($LASTEXITCODE -ne 0) { throw 'Vulkan build failed.' }
New-Item -ItemType Directory -Force -Path vendor\whisper | Out-Null
Get-ChildItem -LiteralPath 'vendor\whisper-source\build\bin\Release' -File | Where-Object Extension -In '.exe','.dll' | Copy-Item -Destination 'vendor\whisper' -Force
Write-Host 'Vulkan build installed. Run .\run.bat --doctor; verify GPU selection in whisper-server startup output.'
