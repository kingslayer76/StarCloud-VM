"""Speak one synthetic Hindi reply through the real streaming playback path."""
import asyncio
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.config import ROOT, load_config
from core.events import EventBus
from voice.tts import SpeechOutput


async def run():
    config = load_config()
    bus = EventBus()
    events = bus.subscribe()
    speech = SpeechOutput(config.voice, bus)
    try:
        speech.say('हाँ, अब मैं जल्दी सुन सकता हूँ। YouTube खोलना हो तो बस बोल देना।')
        await speech.task
        rows = []
        while not events.empty():
            event = events.get_nowait()
            if event.type in {'latency', 'degraded', 'voice_backend'}:
                rows.append({'type': event.type, **event.data})
        print(json.dumps(rows, indent=2, ensure_ascii=False))
        (ROOT/'data/streaming-voice-check.json').write_text(json.dumps(rows, indent=2, ensure_ascii=False), encoding='utf-8')
    finally:
        await speech.close()


if __name__ == '__main__':
    asyncio.run(run())
