import asyncio
import json
import time
import pytest
import httpx
import os
import subprocess
import sys
from core.config import Config, ProviderConfig, VoiceConfig
from core.events import EventBus
from core.state_machine import Cancellation
from brain.providers.local_provider import LocalProvider
from brain.schemas import action, generation_schema
from memory.manager import Memory
from voice.playback import Playback
from voice.microphone import Microphone
from safety.risk import assess


@pytest.mark.skipif(os.name != "nt", reason="Windows job object lifecycle")
def test_abrupt_parent_exit_releases_owned_server():
    import psutil
    script = "from core.child_process import spawn_managed; import sys,time; p=spawn_managed([sys.executable,'-c','import time; time.sleep(60)']); print(p.pid,flush=True); time.sleep(60)"
    parent = subprocess.Popen([sys.executable, "-u", "-c", script], stdout=subprocess.PIPE, text=True)
    child = None
    try:
        line = parent.stdout.readline().strip()
        assert line.isdecimal(), "Parent did not start a managed child"
        child = psutil.Process(int(line))
        parent.kill()
        parent.wait(timeout=5)
        child.wait(timeout=5)
        assert not child.is_running()
    finally:
        if parent.poll() is None:
            parent.kill()
            parent.wait(timeout=5)
        parent.stdout.close()
        if child and child.is_running():
            child.kill()


async def test_local_brain_uses_constrained_schema():
    requests = []
    def handler(request):
        requests.append(json.loads(request.content))
        return httpx.Response(200, json={"choices": [{"message": {"content": '{"reply":"Hi"}'}}]})
    provider = LocalProvider(ProviderConfig(base_url="http://127.0.0.1:1234/v1", model="test", key_env="TEST_LOCAL_KEY"), transport=httpx.MockTransport(handler))
    try:
        await provider.complete([])
        schema = requests[0]["response_format"]["json_schema"]["schema"]
        assert "target" in schema["$defs"]["Action"]["required"]
        assert requests[0]["chat_template_kwargs"]["enable_thinking"] is False
    finally:
        await provider.close()


async def test_playback_cancellation_waits_for_worker(monkeypatch):
    playback = Playback()
    active = 0
    max_active = 0
    def fake_play(samples, rate, token):
        nonlocal active, max_active
        active += 1
        max_active = max(active, max_active)
        while not token.event.is_set():
            time.sleep(.005)
        time.sleep(.025)
        active -= 1
    monkeypatch.setattr(playback, "_play", fake_play)
    first_token, second_token = Cancellation(), Cancellation()
    first = asyncio.create_task(playback.play([], 24000, first_token))
    await asyncio.sleep(.03)
    first_token.cancel()
    first.cancel()
    second = asyncio.create_task(playback.play([], 24000, second_token))
    await asyncio.sleep(.08)
    second_token.cancel()
    await asyncio.gather(first, second, return_exceptions=True)
    assert max_active == 1


async def test_pending_transcript_is_invalidated():
    started = asyncio.Event()
    finished = asyncio.Event()
    results = []
    class STT:
        async def transcribe(self, pcm):
            started.set()
            await finished.wait()
            return "Old command"
    async def on_text(text): results.append(text)
    microphone = Microphone(VoiceConfig(), STT(), EventBus(), on_text, lambda: None)
    worker = asyncio.create_task(microphone._transcribe())
    microphone.segments.put_nowait((0, b"test"))
    await started.wait()
    microphone.invalidate_pending()
    finished.set()
    await asyncio.sleep(.02)
    worker.cancel()
    await asyncio.gather(worker, return_exceptions=True)
    assert results == []


def test_launch_from_terminal_is_allowed_but_terminal_typing_is_not():
    terminal = {"process": "WindowsTerminal.exe", "title": "PowerShell"}
    assert assess(action("open_app", target="Notepad", expected_kind="window", expected_value="Notepad"), terminal).mode == "allow"
    assert assess(action("type_text", text="echo hello", expected_kind="text", expected_value="echo hello"), terminal).mode == "deny"


def test_back_does_not_inherit_send_feedback_risk():
    observation = {"title": "Notepad", "elements": [{"name": "Back"}, {"name": "Send feedback"}]}
    assert assess(action("click", target="Back"), observation).mode == "allow"
    assert assess(action("click", target="Send feedback"), observation).mode == "confirm"


def test_complex_recipe_is_saved_for_replanning(tmp_path):
    memory = Memory(tmp_path / "memory.db")
    try:
        actions = [action("click", target="Settings")]
        memory.reflect("Open preferences", actions, True, "Verified", reusable=True)
        assert memory.recipe("Open preferences") is None
        assert memory.recipe("Open preferences", replay_only=False)[0]["target"] == "Settings"
    finally:
        memory.close()


async def test_websocket_auth_and_text_commands(monkeypatch, unused_tcp_port):
    from services.websocket_server import serve
    from websockets.asyncio.client import connect
    from websockets.exceptions import ConnectionClosedError
    from core.state_machine import TaskState
    class Assistant:
        config = Config()
        bus = EventBus()
        state = TaskState()
        commands = []
        async def submit(self, text, source="text"): self.commands.append(text)
    assistant = Assistant()
    assistant.config.services.websocket_port = unused_tcp_port
    monkeypatch.setenv("ZORIN_WS_TOKEN", "test-token-with-at-least-24-chars")
    server = asyncio.create_task(serve(assistant))
    await asyncio.sleep(.15)
    try:
        uri = f"ws://127.0.0.1:{unused_tcp_port}"
        async with connect(uri) as socket:
            await socket.send(json.dumps({"token": "wrong"}))
            with pytest.raises(ConnectionClosedError):
                await socket.recv()
        async with connect(uri) as socket:
            await socket.send(json.dumps({"token": "test-token-with-at-least-24-chars"}))
            assert json.loads(await socket.recv())["type"] == "assistant_state"
            await socket.send(json.dumps({"type": "text_command", "text": "Hello"}))
            await asyncio.sleep(.05)
            assert assistant.commands == ["Hello"]
    finally:
        server.cancel()
        await asyncio.gather(server, return_exceptions=True)
