"""Real services, synthetic speech only; no mic and no desktop tools."""
import asyncio
import json
from pathlib import Path
import sys
import time
import numpy as np
import soundfile as sf
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.config import load_config
from core.events import EventBus
from persona.live import STYLE
from voice.live import LiveVoice


async def main():
    config=load_config()
    interrupts=[]
    transcripts=[]
    bus=EventBus()
    async def on_text(role,text):
        transcripts.append({'role':role,'text':text})
    async def tool(*args):
        return {'success':False,'reason':'Test has no desktop actions'}
    v=LiveVoice(config.voice,bus,instruction=lambda:STYLE,tools=[],on_text=on_text,on_tool=tool,
                on_interrupt=lambda:interrupts.append(time.monotonic()))
    result={'microphone':False,'mode':'synthetic audio during actual Puck speech'}
    async def feed(path):
        samples,rate=sf.read(path,dtype='float32')
        if samples.ndim==2: samples=samples.mean(axis=1)
        samples=np.interp(np.arange(round(len(samples)*16000/rate))*rate/16000,np.arange(len(samples)),samples)
        pcm=(np.clip(samples,-1,1)*32767).astype('<i2').tobytes()+bytes(16000*2)
        for offset in range(0,len(pcm),3200):
            await v.process_microphone(pcm[offset:offset+3200],v.epoch)
            await asyncio.sleep(.1)
        if v.interruption_task:
            await v.interruption_task
    async def begin():
        await v.text('Test: बताओ कि weekend पर chill करने के लिए क्या कर सकते हैं। चार छोटे sentences में बोलो।')
        async with asyncio.timeout(20):
            while not v.output.speaking:
                await asyncio.sleep(.02)
    try:
        await v.start(microphone=False)
        await begin()
        before=len(interrupts)
        await feed('data/recognition-sample-chat.wav')
        result['background_rejected']=v.rejected_interruptions>0 and len(interrupts)==before
        result['rejected_count']=v.rejected_interruptions
        while v.speaking:
            await asyncio.sleep(.1)
        await begin()
        before=len(interrupts)
        await feed('data/recognition-sample-stop.wav')
        result['named_stop_accepted']=v.accepted_interruptions>0 and len(interrupts)>before
        result['accepted_count']=v.accepted_interruptions
        result['success']=result['background_rejected'] and result['named_stop_accepted']
    except Exception as error:
        from safety.secrets import redact
        result['error']=redact(str(error)) or type(error).__name__
    finally:
        await v.close()
        result['transcripts']=transcripts
        Path('data/reply-protection-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        print(json.dumps(result,ensure_ascii=False),flush=True)
    return int(not result.get('success'))

if __name__=='__main__':
    raise SystemExit(asyncio.run(main()))
