import asyncio
import base64
import json
import time
from unittest.mock import AsyncMock, Mock
import httpx
import numpy as np
import pytest
from core.config import VoiceConfig
from core.events import EventBus
from core.state_machine import Cancellation
from voice.tts import GeminiTTSProvider, SpeechOutput
from voice.playback import Playback


def event(samples=None, finish=None):
    candidate = {}
    if samples is not None:
        candidate['content'] = {'parts': [{'inlineData': {'mimeType': 'audio/L16;rate=24000;channels=1',
            'data': base64.b64encode(np.asarray(samples, dtype='<i2').tobytes()).decode()}}]}
    if finish:
        candidate['finishReason'] = finish
    return ('data: ' + json.dumps({'candidates': [candidate]}) + '\n\n').encode()


async def test_stream_yields_audio_before_generation_finishes(monkeypatch):
    monkeypatch.setenv('GEMINI_API_KEY', 'test-key')
    release = asyncio.Event()
    class Stream(httpx.AsyncByteStream):
        async def __aiter__(self):
            yield event([0, 16384])
            await release.wait()
            yield event([-16384], 'STOP')
    def handle(request):
        assert ':streamGenerateContent?alt=sse' in str(request.url)
        assert json.loads(request.content)['generationConfig']['speechConfig']['voiceConfig']['prebuiltVoiceConfig']['voiceName'] == 'Algieba'
        return httpx.Response(200, stream=Stream())
    provider = GeminiTTSProvider(VoiceConfig(), httpx.MockTransport(handle))
    stream = provider.stream_async('A complete reply.')
    try:
        first = await asyncio.wait_for(anext(stream), 1)
        assert first.tolist() == [0, .5]
        release.set()
        remaining = [chunk async for chunk in stream]
        assert remaining[0].tolist() == [-.5]
        assert provider.last_attempts[-1]['status'] == 'stream complete'
    finally:
        await stream.aclose()


async def test_truncated_stream_is_reported_not_accepted(monkeypatch):
    monkeypatch.setenv('GEMINI_API_KEY', 'test-key')
    provider = GeminiTTSProvider(VoiceConfig(), httpx.MockTransport(lambda r: httpx.Response(200, content=event([1, 2]))))
    with pytest.raises(RuntimeError, match='without a complete reply'):
        _ = [chunk async for chunk in provider.stream_async('A reply.')]


async def test_partial_stream_never_restarts_in_fallback_voice_or_enters_cache(tmp_path, monkeypatch):
    monkeypatch.setenv('GEMINI_API_KEY', 'test-key')
    bus = EventBus()
    events = bus.subscribe()
    speech = SpeechOutput(VoiceConfig(tts_provider='gemini', gemini_tts_streaming=True, tts_cache_directory=str(tmp_path)), bus)
    async def failing(text):
        yield np.zeros(8000)
        raise RuntimeError('Interrupted response')
    speech.providers['gemini'].stream_async = failing
    speech.providers['gemini'].synthesize_async = AsyncMock()
    speech.providers['kokoro'].synthesize = Mock()
    async def play(chunks, rate, token):
        async for _ in chunks:
            pass
    speech.playback.play_stream = play
    try:
        speech.say('हाँ, बोलो।')
        await speech.task
        speech.providers['gemini'].synthesize_async.assert_not_awaited()
        speech.providers['kokoro'].synthesize.assert_not_called()
        assert not list(tmp_path.iterdir())
        assert any(e.type == 'degraded' for e in list(events._queue))
    finally:
        await speech.close()


async def test_stream_rate_limit_before_audio_uses_buffered_25(monkeypatch, tmp_path):
    monkeypatch.setenv('GEMINI_API_KEY', 'test-key')
    def handle(request):
        if 'streamGenerateContent' in str(request.url):
            return httpx.Response(429, json={'error': {}})
        assert 'gemini-2.5-flash-preview-tts:generateContent' in str(request.url)
        return httpx.Response(200, json=json.loads(event([1, 2], 'STOP').decode()[6:]))
    speech = SpeechOutput(VoiceConfig(tts_provider='gemini', gemini_tts_streaming=True, tts_fallbacks=[], tts_cache_directory=str(tmp_path)), EventBus())
    speech.providers['gemini'] = GeminiTTSProvider(speech.config, httpx.MockTransport(handle))
    async def play(chunks, rate, token):
        async for _ in chunks:
            pass
        return {'underruns': 0, 'started_at': time.monotonic()}
    speech.playback.play_stream = play
    speech.playback.play = AsyncMock()
    try:
        speech.say('A unique reply.')
        await speech.task
        speech.playback.play.assert_awaited_once()
        assert speech.last_backend == ('gemini', 'gemini-2.5-flash-preview-tts')
    finally:
        await speech.close()


async def test_playback_stream_uses_one_device_and_preserves_chunk_order(monkeypatch):
    import sounddevice
    calls, output = [], []
    class Stream:
        def __init__(self, **kwargs): calls.append('open')
        def __enter__(self): return self
        def __exit__(self, *args): calls.append('close')
        def write(self, samples):
            output.extend(samples[:, 0].tolist())
            return False
        def abort(self): calls.append('abort')
    monkeypatch.setattr(sounddevice, 'OutputStream', Stream)
    async def chunks():
        yield np.ones(6000)
        await asyncio.sleep(.01)
        yield np.full(2000, .5)
    stats = await Playback().play_stream(chunks(), 24000, Cancellation())
    assert calls == ['open', 'close']
    assert output == [1.]*6000 + [.5]*2000
    assert stats['underruns'] == 0


async def test_cancelling_stream_closes_source_without_fallback(monkeypatch, tmp_path):
    monkeypatch.setenv('GEMINI_API_KEY', 'test-key')
    entered, closed = asyncio.Event(), asyncio.Event()
    speech = SpeechOutput(VoiceConfig(tts_provider='gemini', gemini_tts_streaming=True, tts_cache_directory=str(tmp_path)), EventBus())
    async def source(text):
        try:
            entered.set()
            await asyncio.Event().wait()
            yield np.zeros(8000)
        finally:
            closed.set()
    speech.providers['gemini'].stream_async = source
    speech.providers['gemini'].synthesize_async = AsyncMock()
    try:
        speech.say('A unique reply.')
        await entered.wait()
        speech.stop()
        await speech.task
        assert closed.is_set()
        speech.providers['gemini'].synthesize_async.assert_not_awaited()
    finally:
        await speech.close()
