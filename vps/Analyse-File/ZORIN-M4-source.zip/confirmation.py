import asyncio
import secrets
import time


class ConfirmationGate:
    def __init__(self, bus):
        self.bus = bus
        self.pending = None
        self.future = None

    async def request(self, action, reason, fingerprint):
        self.cancel()
        nonce = secrets.token_hex(4)
        self.future = asyncio.get_running_loop().create_future()
        self.pending = {"id": nonce, "action": action.model_dump(), "reason": reason,
                        "fingerprint": fingerprint, "expires": time.monotonic() + 60}
        self.bus.emit("confirmation_required", **self.pending)
        try:
            return await asyncio.wait_for(self.future, 60)
        except (asyncio.TimeoutError, asyncio.CancelledError):
            return False
        finally:
            self.pending = None
            self.future = None

    def resolve(self, nonce, approved):
        if self.pending and self.pending["id"] == nonce and self.pending["expires"] > time.monotonic() and self.future and not self.future.done():
            self.future.set_result(bool(approved))
            return True
        return False

    def cancel(self):
        if self.future and not self.future.done():
            self.future.set_result(False)
