"""Real model replies to synthetic activity events; optional single voice playback."""
import argparse
import asyncio
import json
from pathlib import Path
import sys
import time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.config import ROOT, load_config
from core.events import EventBus
from brain.router import ProviderRouter
from memory.manager import Memory
from persona.personality import Personality
from persona.companion import Companion
from voice.tts import SpeechOutput


async def run(play=False):
    config = load_config()
    memory = Memory(':memory:', enabled=False)
    bus = EventBus()
    queue = bus.subscribe()
    router = ProviderRouter(config.brain, bus)
    persona = Personality(config, memory)
    companion = Companion(config, memory, persona, router)
    speech = SpeechOutput(config.voice, bus)
    history = [{'role': 'user', 'content': 'आज थोड़ा chill करना है, coding नहीं।'}]
    rows = []
    try:
        cases = [
            ('completed', {'goal': 'YouTube kholo', 'facts': [{'action': 'key', 'target': 'YouTube', 'success': True}]}),
            ('activity', {'activity': {'title': 'Forza Horizon 5 drift tuning guide - YouTube', 'app': 'chrome.exe'}}),
            ('activity', {'activity': {'title': 'Python async tutorial for beginners - YouTube', 'app': 'chrome.exe'}}),
        ]
        for kind, context in cases:
            started = time.monotonic()
            reply = await companion.generate(kind, history=history, **context)
            row = {'event': kind, 'synthetic_context': context, 'reply': reply, 'generation_seconds': round(time.monotonic()-started, 3)}
            rows.append(row)
            if reply:
                persona.remember_response(reply)
                history.append({'role': 'assistant', 'content': reply})
            print(json.dumps(row, ensure_ascii=False), flush=True)
        if play and rows[1]['reply']:
            speech.say(rows[1]['reply'])
            await speech.task
        events = []
        while not queue.empty():
            event = queue.get_nowait()
            if event.type in {'latency', 'provider', 'degraded', 'voice_backend'}:
                events.append({'type': event.type, **event.data})
        result = {'synthetic_events_only': True, 'cases': rows, 'events': events}
        print(json.dumps(events, ensure_ascii=False), flush=True)
        (ROOT/'data/companion-smoke.json').write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding='utf-8')
        return int(not any(row['reply'] for row in rows))
    finally:
        await speech.close()
        await router.close()
        memory.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--play', action='store_true')
    args = parser.parse_args()
    raise SystemExit(asyncio.run(run(args.play)))
