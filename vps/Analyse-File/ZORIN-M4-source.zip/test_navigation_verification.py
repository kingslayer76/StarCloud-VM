from unittest.mock import Mock
import pytest
from core.config import Config
from core.state_machine import Cancellation
from brain.schemas import action
from hands.executor import WindowsExecutor


def test_transient_accessibility_failure_retries_observation_without_more_input():
    COMError = type('COMError', (Exception,), {})
    config = Config()
    executor = WindowsExecutor(config.automation, config.privacy)
    executor.desktop = Mock()
    executor.input = Mock()
    final = {'title': 'YouTube - Google Chrome', 'windows': [{'title': 'YouTube - Google Chrome'}]}
    executor.desktop.observe.side_effect = [COMError('Page changing'), final]
    try:
        result = executor._wait_verified(action('key', text='enter', expected_kind='window', expected_value='YouTube'), Cancellation(), {}, {})
        assert result.success
        assert executor.desktop.observe.call_count == 2
        assert not executor.input.mock_calls
    finally:
        executor.pool.shutdown(wait=False)


def test_navigation_does_not_treat_stale_screen_as_success():
    COMError = type('COMError', (Exception,), {})
    config = Config()
    executor = WindowsExecutor(config.automation, config.privacy)
    executor.desktop = Mock()
    executor.desktop.observe.side_effect = COMError('Unavailable')
    try:
        result = executor._wait_verified(action('key', text='enter', timeout=.1, expected_kind='window', expected_value='YouTube'), Cancellation(),
                                         {'windows': [{'title': 'YouTube'}]}, {})
        assert not result.success
    finally:
        executor.pool.shutdown(wait=False)
