"""Read model availability, then test vision on a synthetic image only."""
import asyncio,base64,json,os,sys
from io import BytesIO
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import httpx
from PIL import Image,ImageDraw,ImageFont
from core.config import load_config
from brain.providers.gemini_provider import GeminiProvider

async def main():
    c=load_config();base=c.brain.providers['gemini']
    async with httpx.AsyncClient(timeout=10) as client:
        response=await client.get('https://generativelanguage.googleapis.com/v1beta/models',headers={'x-goog-api-key':os.environ['GEMINI_API_KEY']})
        response.raise_for_status()
        names={m['name'].removeprefix('models/') for m in response.json().get('models',[])}
    candidates=[m for m in ['gemini-2.5-flash-lite','gemini-2.5-flash','gemini-3.8-flash'] if m in names]
    print(json.dumps({'available_candidates':candidates}),flush=True)
    pic=Image.new('RGB',(800,500),'white');draw=ImageDraw.Draw(pic);draw.text((50,150),'CODE 4826',font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',90),fill='black')
    out=BytesIO();pic.save(out,format='PNG')
    for model in candidates:
        provider=GeminiProvider(base.model_copy(update={'model':model}),timeout=12)
        try:
            reply=await provider.complete([{'role':'user','content':[{'type':'text','text':'Read the four digit code. Return JSON with key code, no other text.'},{'type':'image_url','image_url':{'url':'data:image/png;base64,'+base64.b64encode(out.getvalue()).decode()}}]}])
            print(json.dumps({'model':model,'reply':reply}),flush=True)
            if '4826' in reply: break
        except Exception as error:
            from safety.secrets import redact
            print(json.dumps({'model':model,'error':redact(str(error))}),flush=True)
        finally:
            await provider.close()

if __name__=='__main__':asyncio.run(main())
