"""Verify a real YouTube task and its prepared spoken completion; no microphone."""
import asyncio
import json
from pathlib import Path
import sys
import time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.config import ROOT, load_config
from core.events import EventBus
from core.instance import InstanceLease
from core.orchestrator import Assistant
from hands.executor import WindowsExecutor


async def run():
    config = load_config()
    config.memory.enabled = False
    lease = InstanceLease()
    bus = EventBus()
    events = bus.subscribe()
    assistant = Assistant(config, WindowsExecutor(config.automation, config.privacy), bus=bus)
    rows = []
    try:
        await assistant.start(voice=False, proactive=False)
        started = time.monotonic()
        await assistant.submit('YouTube kholo')
        await assistant.task
        action_seconds = round(time.monotonic()-started, 3)
        if assistant.speech.task:
            await assistant.speech.task
        while not events.empty():
            event = events.get_nowait()
            if event.type in {'assistant_text', 'current_action', 'verification', 'latency', 'voice_backend', 'degraded'}:
                rows.append({'type': event.type, **event.data})
        result = {'outcome': assistant.state.outcome, 'action_seconds': action_seconds, 'reply': assistant.last_response, 'events': rows}
        print(json.dumps(result, indent=2, ensure_ascii=False), flush=True)
        (ROOT/'data/companion-task-check.json').write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding='utf-8')
        return int(assistant.state.outcome != 'success')
    finally:
        await assistant.close()
        lease.close()


if __name__ == '__main__':
    raise SystemExit(asyncio.run(run()))
