"""Use configured providers for one harmless, screen-free planning request."""
import asyncio
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.config import load_config
from core.events import EventBus
from brain.router import ProviderRouter
from brain.schemas import Plan


async def main():
    bus = EventBus()
    events = bus.subscribe()
    router = ProviderRouter(load_config().brain, bus)
    try:
        result = await router.complete([
            {"role": "system", "content": 'You are ZORIN-M4. Reply with JSON only, matching {"reply": "brief natural greeting", "actions": [], "complete": true}.'},
            {"role": "user", "content": "Hello. Say a brief greeting in Hinglish."}
        ], Plan.model_validate_json)
        assert not result.actions
        print("Provider response validated: " + result.reply, flush=True)
    finally:
        while not events.empty():
            print(events.get_nowait().data, flush=True)
        await router.close()


if __name__ == "__main__":
    asyncio.run(main())
