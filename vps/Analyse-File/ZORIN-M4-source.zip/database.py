import sqlite3

SCHEMA = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS memories (
 id INTEGER PRIMARY KEY, content TEXT NOT NULL UNIQUE, category TEXT NOT NULL,
 confidence REAL NOT NULL, source TEXT NOT NULL, created_at REAL NOT NULL,
 last_used_at REAL, usage_count INTEGER DEFAULT 0, importance REAL NOT NULL,
 explicit INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS preferences (key TEXT PRIMARY KEY, value TEXT, confidence REAL, updated_at REAL);
CREATE TABLE IF NOT EXISTS user_profile (key TEXT PRIMARY KEY, value TEXT, updated_at REAL);
CREATE TABLE IF NOT EXISTS episodes (id INTEGER PRIMARY KEY, summary TEXT, created_at REAL);
CREATE TABLE IF NOT EXISTS task_history (id INTEGER PRIMARY KEY, goal TEXT, status TEXT, summary TEXT, created_at REAL);
CREATE TABLE IF NOT EXISTS app_usage (app TEXT, purpose TEXT, count INTEGER DEFAULT 1, last_used_at REAL, PRIMARY KEY(app,purpose));
CREATE TABLE IF NOT EXISTS feedback (id INTEGER PRIMARY KEY, response TEXT, positive INTEGER, note TEXT, created_at REAL);
CREATE TABLE IF NOT EXISTS skills (name TEXT PRIMARY KEY, recipe TEXT, version INTEGER, success_count INTEGER, last_success REAL, preconditions TEXT);
CREATE TABLE IF NOT EXISTS relationships_between_facts (source_id INTEGER, target_id INTEGER, relation TEXT, PRIMARY KEY(source_id,target_id,relation));
CREATE TABLE IF NOT EXISTS failed_actions (id INTEGER PRIMARY KEY, kind TEXT, target TEXT, summary TEXT, created_at REAL);
CREATE TABLE IF NOT EXISTS successful_actions (id INTEGER PRIMARY KEY, kind TEXT, target TEXT, summary TEXT, created_at REAL);
CREATE TABLE IF NOT EXISTS dialogue (id INTEGER PRIMARY KEY, role TEXT, content TEXT, source TEXT, created_at REAL);
CREATE TABLE IF NOT EXISTS conversation_topics (topic_key TEXT PRIMARY KEY, last_spoken REAL);
PRAGMA user_version=1;
"""


def connect(path):
    if str(path) != ":memory:":
        path.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(str(path))
    db.row_factory = sqlite3.Row
    db.executescript(SCHEMA)
    return db
