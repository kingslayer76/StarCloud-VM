"""Local speech gate. No speaker identification is implied by an energy threshold."""
from collections import deque
import math
import numpy as np


class LiveSpeechGate:
    frame_bytes = 960  # 30 ms, PCM16 mono, 16 kHz

    def __init__(self, config, classifier=None):
        self.config = config
        if classifier is None:
            import webrtcvad
            vad = webrtcvad.Vad(config.live_vad_aggressiveness)
            classifier = lambda frame: vad.is_speech(frame, 16000)
        self.classifier = classifier
        self.noise = 60.
        self.reset()

    def reset(self):
        self.pending = b""
        self.preroll = deque(maxlen=16)  # Preserve syllables during the attack check.
        self.attack = deque(maxlen=12)
        self.active = False
        self.held = False
        self.frames = []
        self.silence_ms = 0
        self.duration_ms = 0

    def feed(self, pcm, protected=False):
        """Yield start/audio/end for live speech or a held interruption candidate."""
        self.pending += pcm
        events = []
        while len(self.pending) >= self.frame_bytes:
            frame, self.pending = self.pending[:self.frame_bytes], self.pending[self.frame_bytes:]
            samples = np.frombuffer(frame, dtype='<i2').astype(np.float32)
            rms = float(np.sqrt(np.mean(samples*samples)))
            speech = self.classifier(frame)
            if not speech and not self.active:
                self.noise = .98*self.noise + .02*min(rms, 2000)
            threshold = max(self.config.live_min_energy, self.noise*self.config.live_noise_ratio)
            if protected and not self.active:
                threshold = max(180, self.config.live_min_energy, self.noise*2.2)
            elif self.active:
                threshold *= .65  # Quiet syllables must not prematurely end a phrase.
            voiced = speech and rms >= threshold
            self.attack.append(voiced)
            if not self.active:
                self.preroll.append(frame)
                required = 12 if protected else 6
                recent = list(self.attack)[-required:]
                if len(recent) < required or sum(recent) < math.ceil(required*.8):
                    continue
                self.active = True
                self.held = protected
                self.frames = list(self.preroll) if protected else []
                self.duration_ms = len(self.preroll)*30
                self.silence_ms = 0
                if not protected:
                    events.extend([('start', None), ('audio', b''.join(self.preroll))])
                self.preroll.clear()
            else:
                self.duration_ms += 30
                self.silence_ms = 0 if voiced else self.silence_ms+30
                if self.held:
                    self.frames.append(frame)
                else:
                    events.append(('audio', frame))
            endpoint = max(600, self.config.live_endpoint_ms)
            if self.silence_ms >= endpoint or self.duration_ms >= 20000:
                events.append(('candidate', b''.join(self.frames)) if self.held else ('end', None))
                # Keep only unconsumed input; do not reuse speech from the old turn.
                remaining = self.pending
                self.reset()
                self.pending = remaining
        return events
