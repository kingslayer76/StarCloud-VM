import asyncio
import time
from voice.vad import Segmenter


class Microphone:
    def __init__(self, config, stt, bus, on_text, on_barge):
        self.config, self.stt, self.bus = config, stt, bus
        self.on_text, self.on_barge = on_text, on_barge
        self.audio = asyncio.Queue(maxsize=100)
        self.segments = asyncio.Queue(maxsize=2)
        self.tasks = []
        self.closed = False
        self.transcribing = False
        self.last_voice_at = -1e12
        self.epoch = 0
        self._enabled = True
        self.ready = asyncio.Event()
        self.stats = {"frames": 0, "speech_starts": 0, "utterances": 0,
                      "transcription_attempts": 0, "empty_transcripts": 0,
                      "stale_transcripts": 0, "recognized": 0}

    @property
    def enabled(self):
        return self._enabled

    @enabled.setter
    def enabled(self, value):
        value = bool(value)
        if value != self._enabled:
            self.invalidate_pending()
            self._enabled = value

    def _enqueue(self, frame):
        if self.closed or not self.enabled:
            return
        if self.audio.full():
            self.audio.get_nowait()
        self.stats["frames"] += 1
        self.audio.put_nowait(frame)

    def invalidate_pending(self):
        self.epoch += 1
        while not self.audio.empty():
            self.audio.get_nowait()
        while not self.segments.empty():
            self.segments.get_nowait()

    async def start(self):
        self.tasks = [asyncio.create_task(self._capture()), asyncio.create_task(self._segment()), asyncio.create_task(self._transcribe())]

    async def _capture(self):
        import sounddevice as sd
        loop = asyncio.get_running_loop()
        while not self.closed:
            try:
                def callback(data, frames, timing, status):
                    if not self.closed:
                        loop.call_soon_threadsafe(self._enqueue, bytes(data))
                with sd.RawInputStream(samplerate=16000, blocksize=480, channels=1, dtype="int16",
                                       device=self.config.input_device, callback=callback) as stream:
                    self.ready.set()
                    name = sd.query_devices(self.config.input_device, "input")["name"]
                    recognition = "Groq recognition; local fallback" if self.config.stt_provider == "groq" and self.config.local_stt_fallback else self.config.stt_provider
                    self.bus.emit("voice", message=f"Listening through {name} (local VAD; {recognition})")
                    while not self.closed:
                        await asyncio.sleep(1)
                        if not stream.active:
                            raise RuntimeError("Input stream disconnected")
            except Exception:
                self.ready.clear()
                self.bus.emit("degraded", subsystem="microphone", message="Microphone unavailable; retrying in 5 seconds. Text commands remain active.")
                await asyncio.sleep(5)

    async def _segment(self):
        segmenter = Segmenter(self.config)
        segment_epoch = self.epoch
        while not self.closed:
            frame = await self.audio.get()
            if segment_epoch != self.epoch:
                segmenter = Segmenter(self.config)
                segment_epoch = self.epoch
            if not self.enabled:
                segmenter = Segmenter(self.config)
                continue
            segment, barge = segmenter.feed(frame)
            if barge:
                self.last_voice_at = time.monotonic()
                self.stats["speech_starts"] += 1
                if self.config.barge_in_mode == "speech":
                    self.epoch += 1
                    segment_epoch = self.epoch  # Keep the utterance that triggered barge-in.
                    if self.config.allow_barge_in:
                        self.on_barge()
            if segment:
                self.stats["utterances"] += 1
                if self.segments.full():
                    self.segments.get_nowait()
                self.segments.put_nowait((self.epoch, segment))

    async def _transcribe(self):
        while not self.closed:
            epoch, pcm = await self.segments.get()
            self.transcribing = True
            try:
                self.stats["transcription_attempts"] += 1
                text = await self.stt.transcribe(pcm)
                if not text:
                    self.stats["empty_transcripts"] += 1
                elif epoch != self.epoch:
                    self.stats["stale_transcripts"] += 1
                if text and self.enabled and epoch == self.epoch:
                    self.stats["recognized"] += 1
                    self.bus.emit("recognized_speech", text=text)
                    await self.on_text(text)
            except Exception:
                self.bus.emit("degraded", subsystem="STT", message="Transcription failed; next segment will retry")
            finally:
                self.transcribing = False

    async def finish_capture(self, timeout=45):
        """Diagnostics only: stop capture and finish the final utterance.

        Normal cancellation/close discards pending work instead of running it.
        """
        if self.tasks:
            self.tasks[0].cancel()
            await asyncio.gather(self.tasks[0], return_exceptions=True)
        # Endpoint padding is generated silence, not additional microphone audio.
        async with asyncio.timeout(timeout):
            for _ in range((self.config.endpoint_ms + 29)//30 + 1):
                await self.audio.put(bytes(960))
            while not self.audio.empty() or not self.segments.empty() or self.transcribing:
                await asyncio.sleep(.05)

    async def close(self):
        self.closed = True
        for task in self.tasks:
            task.cancel()
        await asyncio.gather(*self.tasks, return_exceptions=True)
