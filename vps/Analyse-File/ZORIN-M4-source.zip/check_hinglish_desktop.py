"""Real desktop checks through Live's transcript/tool bridge; no microphone."""
import asyncio
import json
from pathlib import Path
import sys
import time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.config import load_config
from core.instance import InstanceLease
from core.live_assistant import LiveAssistant
from hands.executor import WindowsExecutor
from safety.secrets import redact


async def main():
    config=load_config()
    config.memory.enabled=False
    config.personality.companion_enabled=False
    assistant=LiveAssistant(config,WindowsExecutor(config.automation,config.privacy))
    lease=InstanceLease()
    results=[]
    phrases = (['Zorin Notepad kholo', 'Zorin Chrome pe YouTube khol.'] if '--apps' in sys.argv else
               ['Zorin yotube kol', 'Zorin Chrome pe YouTube khol.', 'Zorin Chrome par YouTube search kar.'])
    try:
        for spoken in phrases:
            before=time.monotonic()
            await assistant._transcript('user',spoken)
            result=await asyncio.wait_for(assistant._tool('desktopTask',{'request':spoken}),40)
            observed=await assistant.executor.observe()
            item={'transcript':spoken,'result':result,'seconds':round(time.monotonic()-before,3),
                  'browser_url':observed.get('browser_url'),'title':observed.get('title')}
            results.append(item)
            print(redact(json.dumps(item,ensure_ascii=False)),flush=True)
            if not result['success']:
                break
    finally:
        await assistant.close()
        lease.close()
        path='data/hinglish-app-check.json' if '--apps' in sys.argv else 'data/hinglish-desktop-check.json'
        Path(path).write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
    return int(len(results)!=len(phrases) or any(not r['result']['success'] for r in results))


if __name__=='__main__':
    raise SystemExit(asyncio.run(main()))
