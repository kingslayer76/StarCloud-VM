from dataclasses import dataclass, field, asdict
from enum import StrEnum
import threading


class Phase(StrEnum):
    LISTENING = "LISTENING"
    THINKING = "THINKING"
    ACTING = "ACTING"
    SPEAKING = "SPEAKING"
    INTERRUPTED = "INTERRUPTED"
    CANCELLED = "CANCELLED"
    AWAITING_CONFIRMATION = "AWAITING_CONFIRMATION"


class CancelledAction(Exception):
    pass


class Cancellation:
    """Shared with the input worker, checked before every physical input."""
    def __init__(self):
        self.event = threading.Event()

    def cancel(self):
        self.event.set()

    def check(self):
        if self.event.is_set():
            raise CancelledAction("Cancelled by user")

    def wait(self, seconds):
        if self.event.wait(seconds):
            self.check()


@dataclass
class TaskState:
    phase: Phase = Phase.LISTENING
    outcome: str = "idle"
    current_goal: str = ""
    current_plan: list = field(default_factory=list)
    current_step: int = 0
    last_observation: dict = field(default_factory=dict)
    active_application: str = ""
    expected_result: str = ""
    error_count: int = 0
    user_interrupt: bool = False
    cancel_requested: bool = False

    def public(self):
        return asdict(self)

    def describe(self):
        if self.phase == Phase.ACTING:
            return f"Step {self.current_step}: {self.expected_result}"
        if self.phase == Phase.THINKING:
            return "Working out the next step."
        if self.phase == Phase.AWAITING_CONFIRMATION:
            return "Waiting for your approval of the pending action."
        if self.phase == Phase.SPEAKING:
            return "Speaking the reply."
        if self.phase in {Phase.INTERRUPTED, Phase.CANCELLED}:
            return "Stopped; ready for the next instruction."
        return "Listening."
