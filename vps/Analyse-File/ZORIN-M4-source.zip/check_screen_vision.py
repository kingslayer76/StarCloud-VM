"""Verify Gemini image targeting and Live screen input. No microphone or clicks."""
import asyncio,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from core.config import load_config
from core.events import EventBus
from brain.router import ProviderRouter
from hands.executor import WindowsExecutor
from perception.vision import Vision
from voice.live import LiveVoice
from persona.live import STYLE
from safety.secrets import redact

async def main():
    c=load_config();bus=EventBus();router=ProviderRouter(c.brain,bus)
    executor=WindowsExecutor(c.automation,c.privacy);vision=Vision(c.privacy,router.providers)
    result={};done=asyncio.Event()
    async def text(role,message):
        if role=='assistant': result['live_description']=message;done.set()
    async def no_tools(*args): return {'success':False,'detail':'Read-only screen diagnostic; no tools allowed.'}
    live=LiveVoice(c.voice,bus,instruction=lambda:STYLE,tools=[],on_text=text,on_tool=no_tools,on_interrupt=lambda:None)
    try:
        obs=await executor.observe()
        if obs.get('process','').lower()!='chrome.exe' or 'youtube.com' not in obs.get('browser_url',''):
            raise RuntimeError('Read-only visual check requires YouTube foreground in Chrome.')
        png,bbox=await executor.capture()
        try:
            target=await vision.locate(png,'The YouTube logo/home link at the top left, not the menu icon.')
            result['visual_target']=target.model_dump()
        except Exception as error:
            result['visual_error']=redact(str(error))
        jpeg,_,_=await executor.shared_frame()
        await live.start(microphone=False,playback=False)
        await live.screen_frame(jpeg)
        await asyncio.sleep(1.2)
        await live.text('Read-only screen test. Name the website visible in the shared image in one short sentence. Do not take actions.')
        await asyncio.wait_for(done.wait(),30)
        result['live_recognized_youtube']='youtube' in result.get('live_description','').lower() or 'यूट्यूब' in result.get('live_description','')
    except Exception as error:
        result['error']=redact(str(error))
    finally:
        await live.close();await executor.close();await router.close()
        Path('data/screen-vision-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(redact(json.dumps(result,ensure_ascii=False)),flush=True)
    return int(not result.get('live_recognized_youtube') or not result.get('visual_target',{}).get('found'))

if __name__=='__main__':
    raise SystemExit(asyncio.run(main()))
