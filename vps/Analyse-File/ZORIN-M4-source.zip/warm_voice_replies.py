"""Prepare only fixed acknowledgement clips; no microphone or audible playback."""
import asyncio
import json
from pathlib import Path
import sys
import time
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.config import ROOT, load_config
from core.events import EventBus
from voice.tts import SpeechOutput


async def run():
    bus = EventBus()
    events = bus.subscribe()
    config = load_config()
    config.voice.gemini_tts_streaming = False  # Prepare complete clips without playback.
    speech = SpeechOutput(config.voice, bus)
    async def no_playback(samples, rate, token):
        token.check()
    speech.playback.play = no_playback
    results = []
    try:
        for text in ['हाँ, बोलो।', 'हाँ, सुन रहा हूँ।', 'हो गया।', 'रुक गया।']:
            speech.say(text)
            await speech.task
            while not events.empty():
                event = events.get_nowait()
                if event.type in {'latency', 'degraded', 'voice_backend'}:
                    results.append({'type': event.type, **event.data})
                    print(json.dumps(results[-1], ensure_ascii=False), flush=True)
        (ROOT/'data/fixed-voice-cache-check.json').write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding='utf-8')
    finally:
        await speech.close()


if __name__ == '__main__':
    asyncio.run(run())
