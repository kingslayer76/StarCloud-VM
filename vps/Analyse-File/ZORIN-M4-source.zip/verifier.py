from urllib.parse import urlparse, parse_qs


def normalized_url(value):
    value = value.strip()
    p = urlparse(value if '://' in value else 'https://'+value)
    return ((p.hostname or '').removeprefix('www.').lower(), p.path.rstrip('/'), parse_qs(p.query))


def verify(expected, before, after, evidence=None):
    evidence = evidence or {}
    kind, value = expected.kind, expected.value.casefold()
    if kind in {'url', 'url_changed'}:
        current = after.get('browser_url', '')
        if not current or after.get('focus') == 'Address and search bar':
            return False
        if kind == 'url':
            return bool(expected.value) and normalized_url(current) == normalized_url(expected.value)
        target = evidence.get('target_url')
        if target:
            from perception.selection import video_url, video_key
            current_full=current if '://' in current else 'https://'+current
            if video_url(target) and video_url(current_full):
                return video_key(target)==video_key(current_full) and normalized_url(current)!=normalized_url(before.get('browser_url',''))
        if evidence.get('visual_video'):
            from perception.selection import video_url
            current_url = current if '://' in current else 'https://'+current
            return video_url(current_url) and normalized_url(current)!=normalized_url(before.get('browser_url',''))
        return (bool(target) and normalized_url(current) == normalized_url(target) and
                normalized_url(current) != normalized_url(before.get('browser_url', '')))
    windows = after.get("windows", [])
    if kind == "window":
        return any(value in w["title"].casefold() for w in windows)
    if kind == "window_gone":
        return not any(value in w["title"].casefold() for w in windows)
    if kind == "text":
        if evidence.get('replace_address'):
            return after.get('browser_url', '') == expected.value
        return expected.value in after.get("focused_text", "")
    if kind == "element":
        return any(value in e["name"].casefold() for e in after.get("elements", []))
    if kind == "capture":
        return evidence.get("capture_bytes", 0) > 0
    if kind == "cursor":
        return evidence.get("cursor_reached", False)
    if kind == "volume":
        return abs(evidence.get("volume", -1000) - int(expected.value)) < 2
    if kind == "changed":
        return before.get("fingerprint") != after.get("fingerprint") or evidence.get("media_changed", False)
    return False
