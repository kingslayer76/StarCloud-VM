"""Download upstream assets only; verify published hashes when provided."""
import hashlib
import json
from pathlib import Path
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def sha256(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def fetch(url, target, digest=None):
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() and (not digest or sha256(target) == digest):
        print(f"Present: {target.name}", flush=True)
        return
    temporary = target.with_suffix(target.suffix + ".partial")
    print(f"Downloading {target.name}", flush=True)
    request = urllib.request.Request(url, headers={"User-Agent": "ZORIN-M4-setup"})
    with urllib.request.urlopen(request, timeout=60) as response, temporary.open("wb") as output:
        while block := response.read(1024 * 1024):
            output.write(block)
    if digest and sha256(temporary) != digest:
        raise RuntimeError(f"Checksum mismatch: {target.name}")
    temporary.replace(target)


def main():
    vendor = ROOT / "vendor" / "whisper"
    archive = ROOT / "vendor" / "whisper-b4938.zip"
    fetch("https://github.com/ggml-org/whisper.cpp/releases/download/b4938/whisper-bin-x64.zip", archive,
          "c2a4b60edb11f7e11a9191ffb50929535527d4d91c9903dbe3e554583bbbc63d")
    vendor.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as zipped:
        for info in zipped.infolist():
            if not info.is_dir() and Path(info.filename).suffix.lower() in {".exe", ".dll"}:
                destination = vendor / Path(info.filename).name
                destination.write_bytes(zipped.read(info))
    fetch("https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small.bin", ROOT / "models" / "ggml-small.bin")
    base = "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/"
    for name in ["kokoro-v1.0.int8.onnx", "voices-v1.0.bin"]:
        fetch(base + name, ROOT / "models" / name)
    manifest = {}
    for path in list((ROOT / "models").glob("*")) + [archive]:
        if path.is_file() and path.suffix != ".partial":
            manifest[str(path.relative_to(ROOT))] = sha256(path)
    (ROOT / "models" / "download-manifest.json").write_text(json.dumps(manifest, indent=2))
    print("Local models installed. Official Windows build uses CPU; see README for Vulkan build.", flush=True)


if __name__ == "__main__":
    main()
