import ctypes as C
from ctypes import wintypes as W
import hashlib
import json
import time
import psutil


class Desktop:
    def __init__(self):
        import uiautomation as auto
        self.auto = auto
        self.initializer = auto.UIAutomationInitializerInThread()
        self.initializer.__enter__()
        self.user32 = C.WinDLL("user32", use_last_error=True)
        self.user32.GetForegroundWindow.restype = W.HWND
        self.user32.SetForegroundWindow.argtypes = [W.HWND]
        self.user32.OpenInputDesktop.restype = W.HANDLE
        self.user32.CloseDesktop.argtypes = [W.HANDLE]
        self.user32.GetUserObjectInformationW.argtypes = [W.HANDLE, C.c_int, C.c_void_p, W.DWORD, C.POINTER(W.DWORD)]
        try:
            self.user32.SetProcessDpiAwarenessContext(C.c_void_p(-4))
        except (AttributeError, OSError):
            pass

    def secure_desktop(self):
        handle = self.user32.OpenInputDesktop(0, False, 1)
        if not handle:
            return True
        try:
            name = C.create_unicode_buffer(256)
            needed = W.DWORD()
            ok = self.user32.GetUserObjectInformationW(handle, 2, name, C.sizeof(name), C.byref(needed))
            return not ok or name.value.casefold() != "default"
        finally:
            self.user32.CloseDesktop(handle)

    def windows(self):
        result = []
        for window in self.auto.GetRootControl().GetChildren():
            try:
                # Minimized windows still count: they should be restored, not relaunched.
                if window.Name and window.NativeWindowHandle:
                    try:
                        process = psutil.Process(window.ProcessId).name()
                    except psutil.Error:
                        process = ''
                    result.append({"title": window.Name, "hwnd": window.NativeWindowHandle, "pid": window.ProcessId, "process": process})
            except Exception:
                continue
        return result

    def foreground(self):
        return self.auto.ControlFromHandle(self.user32.GetForegroundWindow())

    def activity(self):
        """Minimal foreground metadata; no UI tree walk, page text or screenshots."""
        if self.secure_desktop():
            return {"secure_desktop": True}
        hwnd = self.user32.GetForegroundWindow()
        if not hwnd:
            return {}
        length = self.user32.GetWindowTextLengthW(W.HWND(hwnd))
        title = C.create_unicode_buffer(min(length+1, 512))
        self.user32.GetWindowTextW(W.HWND(hwnd), title, len(title))
        pid = W.DWORD()
        self.user32.GetWindowThreadProcessId(W.HWND(hwnd), C.byref(pid))
        try:
            process = psutil.Process(pid.value).name()
        except psutil.Error:
            return {}
        focus = self.auto.GetFocusedControl()
        return {"hwnd": hwnd, "title": title.value, "process": process,
                "password_focused": bool(focus and focus.IsPassword), "secure_desktop": False}

    def walk(self, root, limit=250, seconds=1.5):
        stack = [(root, 0)]
        deadline = time.monotonic() + seconds
        count = 0
        while stack and count < limit and time.monotonic() < deadline:
            control, depth = stack.pop()
            try:
                if control.IsPassword:
                    continue
                count += 1
                yield control
                if depth < 24:
                    stack.extend((child, depth+1) for child in reversed(control.GetChildren()[:100]))
            except Exception:
                continue

    @staticmethod
    def control_text(control):
        if control.IsPassword:
            return ""
        parts = [control.Name or ""]
        for getter in ["GetValuePattern", "GetTextPattern"]:
            try:
                pattern = getattr(control, getter)()
                value = pattern.Value if getter == "GetValuePattern" else pattern.DocumentRange.GetText(4000)
                if value:
                    parts.append(value[:4000])
            except Exception:
                continue
        return "\n".join(parts)

    def observe(self):
        if self.secure_desktop():
            return {"secure_desktop": True, "fingerprint": "secure"}
        root = self.foreground()
        if root is None:
            raise RuntimeError("No interactive foreground window in this Windows session; run ZORIN-M4 from your signed-in desktop")
        hwnd = root.NativeWindowHandle
        focus = self.auto.GetFocusedControl()
        elements = []
        browser_url = ""
        for control in self.walk(root):
            try:
                rect = control.BoundingRectangle
                if not control.IsOffscreen and control.Name and rect.width() > 0 and rect.height() > 0:
                    elements.append({"name": control.Name[:240], "type": control.ControlTypeName,
                                     "rect": [rect.left, rect.top, rect.right, rect.bottom], "enabled": control.IsEnabled})
                    if control.Name == "Address and search bar":
                        browser_url = self.control_value(control)
            except Exception:
                continue
        try:
            process = psutil.Process(root.ProcessId).name()
        except psutil.Error:
            process = ""
        protected = bool(focus and focus.IsPassword)
        focused_text = "" if protected or not focus else self.control_text(focus)
        value = {"hwnd": hwnd, "title": root.Name, "process": process, "browser_url": browser_url,
                 "focus": "[protected]" if protected else (focus.Name if focus else ""),
                 "focus_type": focus.ControlTypeName if focus else "", "password_focused": protected,
                 "focused_text": focused_text, "elements": elements, "windows": self.windows(), "secure_desktop": False}
        value["fingerprint"] = hashlib.sha256(json.dumps([hwnd, value["title"], elements, focused_text], ensure_ascii=False).encode()).hexdigest()[:20]
        return value

    @staticmethod
    def control_value(control):
        for getter in ('GetValuePattern', 'GetLegacyIAccessiblePattern'):
            try:
                value = getattr(control, getter)().Value
                if isinstance(value, str) and value:
                    return value
            except Exception:
                pass
        return ''

    def indexed_controls(self, category):
        from perception.selection import ordered_controls
        rows = []
        wanted = {'video': 'HyperlinkControl', 'link': 'HyperlinkControl', 'button': 'ButtonControl',
                  'tab': 'TabItemControl', 'item': 'ListItemControl'}[category]
        root = self.content_control() if category in {'video','link'} else self.foreground()
        for control in self.walk(root, limit=3000, seconds=3):
            try:
                if control.ControlTypeName != wanted:
                    continue
                if control.IsOffscreen or control.IsPassword:
                    continue
                rect = control.BoundingRectangle
                rows.append({'name': control.Name, 'type': wanted,
                             'enabled': control.IsEnabled, 'rect': [rect.left, rect.top, rect.right, rect.bottom],
                             'url': self.control_value(control) if control.ControlTypeName == 'HyperlinkControl' else '',
                             'control': control})
            except Exception:
                continue
        return ordered_controls(rows, category)

    def content_control(self):
        root=self.foreground()
        documents=[]
        for control in self.walk(root,limit=500,seconds=1.5):
            try:
                if control.ControlTypeName=='DocumentControl' and not control.IsOffscreen:
                    rect=control.BoundingRectangle
                    if rect.width()>100 and rect.height()>100:
                        # Chromium exposes an empty WebView wrapper and the real
                        # page at the same bounds. Prefer the named page when
                        # their areas match; walking the wrapper can yield no links.
                        documents.append((rect.width()*rect.height(),bool(control.Name),control))
            except Exception:
                continue
        return max(documents,key=lambda item:(item[0],item[1]))[2] if documents else root

    def scroll_anchors(self, root):
        anchors={}
        for control in self.walk(root,limit=1000,seconds=1):
            try:
                kind=control.ControlTypeName
                if kind not in {'HyperlinkControl','TextControl','ListItemControl'} or control.IsOffscreen:
                    continue
                name=control.Name
                rect=control.BoundingRectangle
                if name and rect.width()>0 and rect.height()>0:
                    anchors.setdefault((kind,name),[]).append((rect.left,rect.top))
            except Exception:
                continue
        return anchors

    def locate_index(self, category, index):
        ordered = self.indexed_controls(category)
        if len(ordered) < index:
            raise LookupError(f'Only {len(ordered)} identifiable visible {category} targets; cannot select number {index}. Scroll or name the target.')
        return ordered[index-1]

    def locate(self, target, root=None):
        target = target.casefold().strip()
        exact, partial = [], []
        for control in self.walk(root or self.foreground(), limit=400, seconds=2):
            try:
                if control.IsOffscreen or not control.IsEnabled or control.IsPassword:
                    continue
                name = control.Name.casefold().strip()
                rect = control.BoundingRectangle
                if rect.width() <= 0 or rect.height() <= 0:
                    continue
                if name == target:
                    exact.append(control)
                elif target in name:
                    partial.append(control)
            except Exception:
                continue
        matches = exact or partial
        if len(matches) != 1:
            raise LookupError(f"Target '{target}' has {len(matches)} matches; need one unambiguous visible control")
        return matches[0]

    def focus_window(self, title, token=None, process=None):
        matches = [w for w in self.windows() if title.casefold() in w["title"].casefold()
                   and (not process or w.get('process','').casefold() == process)]
        if len(matches) != 1:
            raise LookupError(f"Window '{title}' has {len(matches)} matches")
        self.focus_handle(matches[0]['hwnd'], token)

    def focus_handle(self, hwnd, token=None):
        self.user32.ShowWindow(W.HWND(hwnd), 9)
        try:
            self.auto.ControlFromHandle(hwnd).SetFocus()
        except Exception:
            pass
        self.user32.SetForegroundWindow(hwnd)
        # Activation can be asynchronous across input queues. Check after a short wait.
        for _ in range(10):
            if self.user32.GetForegroundWindow() == hwnd:
                return
            token.wait(.05) if token else time.sleep(.05)
        raise RuntimeError("Windows did not grant focus")

    def close(self):
        self.initializer.__exit__(None, None, None)
