from pathlib import Path
from typing import Literal
import os
import yaml
from dotenv import load_dotenv
from pydantic import BaseModel, ConfigDict, Field, model_validator

ROOT = Path(__file__).resolve().parents[1]


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)


class AssistantConfig(Strict):
    name: str = "ZORIN-M4"
    user_title: str = "boss"
    language_mode: str = "hinglish"
    response_length: str = "short"
    autostart: bool = False


class ProviderConfig(Strict):
    base_url: str
    model: str = ""
    key_env: str


class BrainConfig(Strict):
    primary_provider: str = "groq"
    fallback_providers: list[str] = Field(default_factory=lambda: ["gemini", "local"])
    timeout: float = Field(default=18, ge=1, le=120)
    providers: dict[str, ProviderConfig] = Field(default_factory=dict)
    local_autostart: bool = True
    local_executable: str = "vendor/llama/llama-server.exe"
    local_model_file: str = "models/Qwen3-4B-Instruct-2507-Q4_K_M.gguf"
    local_context: int = Field(default=8192, ge=2048, le=16384)
    local_threads: int = Field(default=4, ge=1, le=16)
    local_gpu_layers: int = Field(default=99, ge=0, le=999)


class PersonalityConfig(Strict):
    humor: float = Field(default=.3, ge=0, le=1)
    sarcasm: float = Field(default=.2, ge=0, le=1)
    proactivity: float = Field(default=.35, ge=0, le=1)
    relevance_threshold: float = Field(default=.72, ge=0, le=1)
    cooldown_seconds: float = Field(default=180, ge=0)
    companion_enabled: bool = False
    activity_settle_seconds: float = Field(default=3, ge=1, le=15)
    companion_gap_seconds: float = Field(default=25, ge=10, le=300)
    companion_timeout: float = Field(default=4, ge=1, le=15)


class AppAlias(Strict):
    search: str
    window: str


class AutomationConfig(Strict):
    human_visible_mode: bool = True
    mouse_speed: Literal["fast", "natural", "demo"] = "natural"
    verify_actions: bool = True
    max_steps: int = Field(default=16, ge=1, le=32)
    retries: int = Field(default=1, ge=0, le=2)
    app_aliases: dict[str, AppAlias] = Field(default_factory=dict)


class VoiceConfig(Strict):
    enabled: bool = True
    mode: Literal["cascade", "gemini_live"] = "cascade"
    live_model: str = "gemini-3.1-flash-live-preview"
    live_voice: str = "Puck"
    live_endpoint_ms: int = Field(default=500, ge=150, le=1500)
    live_reply_protection: bool = True
    live_min_energy: int = Field(default=250, ge=50, le=4000)
    live_vad_aggressiveness: int = Field(default=2, ge=0, le=3)
    live_noise_ratio: float = Field(default=1.7, ge=1.1, le=4)
    live_input_gain: float = Field(default=2.0, ge=1, le=6)
    stt_provider: Literal["local_whisper", "groq"] = "local_whisper"
    cloud_stt_fallback: bool = False
    local_stt_fallback: bool = True
    groq_stt_model: Literal["whisper-large-v3", "whisper-large-v3-turbo"] = "whisper-large-v3"
    cloud_stt_timeout: float = Field(default=5, ge=1, le=30)
    transcription_prompt: str = Field(default="Zorin, ZORIN-M4, M4. YouTube, Chrome, Notepad, Steam, Forza. यूट्यूब खोलो। Chrome खोल दो। ज़ोरिन रुको। Hello Zorin. YouTube kholo. Ruko.", max_length=800)
    whisper_url: str = "http://127.0.0.1:8178/inference"
    whisper_executable: str = "vendor/whisper/whisper-server.exe"
    whisper_model: str = "models/ggml-large-v3-turbo-q5_0.bin"
    whisper_language: str = "auto"
    whisper_threads: int = Field(default=4, ge=1, le=16)
    tts_provider: Literal["gemini", "google", "edge", "kokoro", "groq", "sapi", "none"] = "google"
    tts_fallbacks: list[Literal["gemini", "google", "edge", "kokoro", "groq", "sapi"]] = Field(default_factory=lambda: ["kokoro", "sapi"])
    gemini_tts_model: str = "gemini-3.1-flash-tts-preview"
    gemini_tts_fallback_models: list[str] = Field(default_factory=lambda: ["gemini-2.5-flash-preview-tts"])
    gemini_tts_voice: str = "Algieba"
    gemini_tts_style: str = Field(default="A relaxed, friendly conversation with one person. Natural Indian Hindi/Hinglish pronunciation and ordinary conversational pacing. Gentle expression, not a performance.", max_length=1500)
    gemini_tts_timeout: float = Field(default=20, ge=2, le=60)
    gemini_tts_streaming: bool = False
    tts_cache_directory: str = "data/voice-cache"
    google_tld: str = "co.in"
    google_timeout: float = Field(default=12, ge=2, le=60)
    edge_hindi_voice: str = "hi-IN-MadhurNeural"
    edge_english_voice: str = "en-IN-PrabhatNeural"
    edge_timeout: float = Field(default=12, ge=2, le=60)
    kokoro_hindi_voice: str = "hm_omega"
    kokoro_model: str = "models/kokoro-v1.0.int8.onnx"
    kokoro_voices: str = "models/voices-v1.0.bin"
    kokoro_voice: str = "bm_george"
    tts_language: str = "en-gb"
    tts_speed: float = Field(default=1.05, ge=.5, le=2)
    groq_tts_model: str = "canopylabs/orpheus-v1-english"
    groq_tts_voice: str = "troy"
    input_device: int | str | None = None
    output_device: int | str | None = None
    allow_barge_in: bool = True
    barge_in_mode: Literal["confirmed", "speech"] = "confirmed"
    vad_aggressiveness: int = Field(default=2, ge=0, le=3)
    endpoint_ms: int = Field(default=840, ge=150, le=1500)
    min_speech_ms: int = Field(default=300, ge=60, le=1000)
    max_segment_seconds: int = Field(default=20, ge=2, le=60)
    barge_in_ms: int = Field(default=360, ge=30, le=900)
    energy_threshold: int = Field(default=180, ge=0, le=4000)
    whisper_beam_size: int = Field(default=1, ge=1, le=5)


class MemoryConfig(Strict):
    enabled: bool = True
    reflection: bool = True
    database: str = "data/assistant.db"
    max_context_memories: int = Field(default=8, ge=1, le=30)


class PrivacyConfig(Strict):
    save_screenshots: bool = False
    cloud_vision: bool = False
    cloud_screen_context: bool = False
    cloud_activity_titles: bool = False
    cloud_control_labels: bool = False
    live_screen_sharing: bool = False
    vision_provider: str = "gemini"
    vision_model: str = ''


class SafetyConfig(Strict):
    confirm_sensitive_actions: bool = True


class ServicesConfig(Strict):
    websocket_enabled: bool = False
    websocket_host: Literal["127.0.0.1", "localhost", "::1"] = "127.0.0.1"
    websocket_port: int = Field(default=8765, ge=1024, le=65535)
    token_env: str = "ZORIN_WS_TOKEN"


class Config(Strict):
    assistant: AssistantConfig = Field(default_factory=AssistantConfig)
    brain: BrainConfig = Field(default_factory=BrainConfig)
    personality: PersonalityConfig = Field(default_factory=PersonalityConfig)
    automation: AutomationConfig = Field(default_factory=AutomationConfig)
    voice: VoiceConfig = Field(default_factory=VoiceConfig)
    memory: MemoryConfig = Field(default_factory=MemoryConfig)
    privacy: PrivacyConfig = Field(default_factory=PrivacyConfig)
    safety: SafetyConfig = Field(default_factory=SafetyConfig)
    services: ServicesConfig = Field(default_factory=ServicesConfig)

    @model_validator(mode="after")
    def invariants(self):
        if not self.safety.confirm_sensitive_actions:
            raise ValueError("Sensitive-action confirmation cannot be disabled in Phase 1")
        if not self.automation.verify_actions:
            raise ValueError("Action verification is required")
        return self


def load_config(path: str | Path = ROOT / "config.yaml") -> Config:
    load_dotenv(ROOT / ".env", override=True)
    return Config.model_validate(yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {})


def project_path(path: str) -> Path:
    p = Path(path).expanduser()
    return p if p.is_absolute() else ROOT / p
