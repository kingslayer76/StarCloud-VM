"""Address handling and interruption admission, separate from raw audio detection."""
import re
import unicodedata
from difflib import SequenceMatcher
from brain.intent import is_cancel

# Zorian/Zoiro are observed local-Whisper spellings from the live microphone
# test. Keep aliases explicit rather than fuzzy-matching arbitrary names.
ADDRESS = re.compile(r"^\s*(?:(?:hey|hello|hi|okay|ok|हेलो|हैलो|हे)[,\s]+)?(?:zorin(?:[ -]?m[ -]?(?:4|four))?|m[ -]?(?:4|four)|zorian|zoiro|ज़ोरिन|जोरिन|ज़ॉरिन|जॉरिन)(?=$|[\s,.:;!?।-])[\s,.:;!?।-]*", re.I)


def voice_command(text, *, busy=False, last_reply="", speaking=False):
    text = unicodedata.normalize("NFKC", text).strip()
    # Gemini Live's observed transcription of "Hello Zorin" in the synthetic
    # Hindi command is "Hello Soren". Only treat this as a name after a greeting.
    text = re.sub(r"^(?:hello|hey|hi)\s+soren[\s,.:;!?।-]+", "Zorin, ", text, flags=re.I)
    match = ADDRESS.match(text)
    addressed = bool(match)
    if match:
        text = text[match.end():].strip() or "Hello"
    if not text or not any(c.isalpha() for c in text):
        return None
    if speaking and last_reply:
        normalize = lambda value: re.sub(r"[^\w]+", " ", value.casefold()).strip()
        current, previous = normalize(text), normalize(last_reply)
        if SequenceMatcher(None, current, previous).ratio() > .85 or len(current.split()) >= 4 and current in previous:
            return None
    if busy and not addressed and not is_cancel(text):
        return None
    return text
