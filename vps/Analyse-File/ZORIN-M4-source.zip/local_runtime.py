"""Managed loopback llama.cpp server. No shell or user-script execution."""
import asyncio
import os
import secrets
import subprocess
import time
from urllib.parse import urlparse
import httpx
from core.config import project_path
from core.child_process import spawn_managed


class LocalBrainRuntime:
    def __init__(self, config, bus):
        self.config, self.bus = config, bus
        self.process = None
        self.ready = False

    async def ensure_running(self):
        if not self.config.local_autostart or self.process is None or self.process.poll() is None:
            return False
        self.ready = False
        self.bus.emit("system", message="Local brain stopped; restarting its managed server")
        await self.start()
        return self.ready

    async def start(self):
        cfg = self.config
        if not cfg.local_autostart or "local" not in cfg.providers:
            return
        provider = cfg.providers["local"]
        executable, model = project_path(cfg.local_executable), project_path(cfg.local_model_file)
        if not executable.exists() or not model.exists():
            self.bus.emit("degraded", subsystem="local brain", message="Local model not installed; run setup.ps1 -DownloadBrain")
            return
        url = urlparse(provider.base_url)
        if url.hostname not in {"localhost", "127.0.0.1", "::1"}:
            raise ValueError("Managed brain must use loopback")
        origin = f"{url.scheme}://{url.netloc}"
        async with httpx.AsyncClient(timeout=1) as client:
            try:
                response = await client.get(origin + "/health")
                if response.status_code == 200:
                    key = os.getenv(provider.key_env, "")
                    check = await client.get(origin + "/v1/models", headers={"Authorization": f"Bearer {key}"})
                    if check.status_code == 200:
                        self.ready = True
                        return
                    raise RuntimeError("A local brain is already using this port with different credentials. Close the previous ZORIN-M4 server or choose another local port.")
            except httpx.HTTPError:
                pass
            key = os.getenv(provider.key_env) or secrets.token_urlsafe(32)
            os.environ[provider.key_env] = key
            self.process = spawn_managed([str(executable), "-m", str(model), "--alias", provider.model,
                "--host", url.hostname, "--port", str(url.port or 8179), "--api-key", key,
                "-c", str(cfg.local_context), "-t", str(cfg.local_threads), "-ngl", str(cfg.local_gpu_layers),
                "--parallel", "1", "--jinja", "--reasoning-budget", "0", "--no-webui"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            deadline = time.monotonic() + 90
            while time.monotonic() < deadline:
                if self.process.poll() is not None:
                    raise RuntimeError("Local brain exited; check binary/model/GPU configuration")
                try:
                    if (await client.get(origin + "/health")).status_code == 200:
                        self.ready = True
                        self.bus.emit("system", message="Local reasoning brain ready (no API key required)")
                        return
                except httpx.HTTPError:
                    pass
                await asyncio.sleep(.4)
        raise RuntimeError("Local brain startup timed out")

    async def close(self):
        if self.process and self.process.poll() is None:
            self.process.terminate()
            try:
                await asyncio.to_thread(self.process.wait, 3)
            except subprocess.TimeoutExpired:
                self.process.kill()
