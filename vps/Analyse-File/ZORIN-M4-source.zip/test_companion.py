import asyncio
import json
from unittest.mock import AsyncMock
import pytest
from core.config import Config, VoiceConfig
from core.events import EventBus
from core.orchestrator import Assistant
from hands.executor import Outcome
from memory.manager import Memory
from persona.personality import Personality
from persona.companion import Companion, activity_context, context_key
from voice.tts import SpeechOutput


def observation(title):
    return {'title': title, 'process': 'chrome.exe', 'hwnd': 1}


def setup_companion(tmp_path):
    config = Config()
    config.personality.companion_enabled = True
    memory = Memory(tmp_path/'companion.db')
    persona = Personality(config, memory)
    router = type('Router', (), {'complete': AsyncMock(return_value='Drift सीखने का मूड है?')})()
    return config, memory, Companion(config, memory, persona, router)


def test_tab_change_must_settle_and_is_considered_only_once(tmp_path):
    config, memory, companion = setup_companion(tmp_path)
    try:
        assert companion.observe(observation('Home'), now=0) is None
        assert companion.observe(observation('Forza - YouTube'), now=1) is None
        assert companion.observe(observation('Forza - YouTube'), now=2) is None
        assert companion.observe(observation('Forza - YouTube'), now=5, busy=True) is None
        assert companion.observe(observation('Forza - YouTube'), now=6)
        assert companion.observe(observation('Forza - YouTube'), now=100) is None
    finally:
        memory.close()


def test_topic_and_dialogue_survive_restart_and_forget_erases_them(tmp_path):
    config, memory, companion = setup_companion(tmp_path)
    key = context_key(activity_context(observation('Forza - YouTube')))
    memory.remember_topic(key)
    memory.record_dialogue('assistant', 'Drift सीखने का मूड है?')
    memory.close()
    memory = Memory(tmp_path/'companion.db')
    try:
        restored = Companion(config, memory, Personality(config, memory), companion.router)
        restored.observe(observation('Home'), now=0)
        restored.observe(observation('Forza - YouTube'), now=1)
        assert restored.observe(observation('Forza - YouTube'), now=10) is None
        assert restored.is_repetition('Drift सीखने का मूड है?')
        memory.forget()
        assert not memory.topic_recent(key)
        assert memory.recent_dialogue() == []
    finally:
        memory.close()


@pytest.mark.parametrize('extra', [{'password_focused': True}, {'secure_desktop': True}, {'title': 'Incognito - Chrome'}, {'process': 'powershell.exe'}])
def test_protected_context_does_not_generate_an_offer(extra):
    assert activity_context({**observation('Page'), **extra}) is None


@pytest.mark.parametrize('cloud_allowed', [True, False])
async def test_only_titles_and_app_names_reach_activity_model(tmp_path, cloud_allowed):
    config, memory, companion = setup_companion(tmp_path)
    config.privacy.cloud_activity_titles = cloud_allowed
    try:
        reply = await companion.generate('activity', activity={'title': 'Forza', 'app': 'chrome.exe', 'focused_text': 'PRIVATE FIELD', 'elements': ['SECRET PAGE']})
        assert reply
        args, kwargs = companion.router.complete.call_args
        sent = json.dumps(args[0], ensure_ascii=False)
        assert 'Forza' in sent
        assert 'PRIVATE FIELD' not in sent and 'SECRET PAGE' not in sent
        assert kwargs['local_only'] is (not cloud_allowed)
        assert kwargs['conversation'] is True
    finally:
        memory.close()


async def test_duplicate_model_remark_is_suppressed(tmp_path):
    config, memory, companion = setup_companion(tmp_path)
    try:
        companion.persona.remember_response('Drift सीखने का मूड है?')
        assert await companion.generate('activity', activity={'title': 'Forza', 'app': 'chrome.exe'}) is None
    finally:
        memory.close()


class Speech:
    speaking = False
    def __init__(self): self.replies = []
    def stop(self): self.speaking = False
    def say(self, text): self.replies.append(text)
    async def close(self): pass


class Desktop:
    def __init__(self): self.current = observation('Home'); self.actions = []; self.fail = False
    async def observe(self): return {**self.current, 'fingerprint': 'test', 'windows': []}
    async def activity(self): return self.current
    async def execute(self, action, *args):
        self.actions.append(action)
        await asyncio.sleep(.01)
        return Outcome(not self.fail, 'Verified' if not self.fail else 'Failed', await self.observe())
    async def close(self): pass


def make_assistant(tmp_path):
    config = Config()
    config.personality.companion_enabled = True
    config.memory.database = str(tmp_path/'assistant.db')
    config.voice.enabled = False
    return Assistant(config, Desktop(), providers={}, speech=Speech())


async def test_activity_remark_runs_without_user_command_and_never_executes_actions(tmp_path):
    assistant = make_assistant(tmp_path)
    assistant.companion.generate = AsyncMock(return_value='Drift tuning चल रही है?')
    try:
        await assistant._consider_activity(observation('Home'), now=0)
        assistant.executor.current = observation('Forza - YouTube')
        await assistant._consider_activity(assistant.executor.current, now=1)
        await assistant._consider_activity(assistant.executor.current, now=5)
        await assistant.companion_task
        assert assistant.last_response == 'Drift tuning चल रही है?'
        assert not assistant.executor.actions
        assert assistant.speech_context == 'companion'
    finally:
        await assistant.close()


async def test_stale_tab_reply_is_discarded(tmp_path):
    assistant = make_assistant(tmp_path)
    async def generate(*args, **kwargs):
        assistant.executor.current = observation('Different page')
        return 'Old page comment'
    assistant.companion.generate = generate
    try:
        await assistant._consider_activity(observation('Home'), now=0)
        await assistant._consider_activity(observation('Forza'), now=1)
        await assistant._consider_activity(observation('Forza'), now=5)
        await assistant.companion_task
        assert assistant.last_response == ''
    finally:
        await assistant.close()


async def test_quiet_mode_suppresses_activity(tmp_path):
    assistant = make_assistant(tmp_path)
    assistant.companion.generate = AsyncMock()
    try:
        assistant.persona.social.user_busy = True
        await assistant._consider_activity(observation('Home'), now=0)
        await assistant._consider_activity(observation('Forza'), now=1)
        await assistant._consider_activity(observation('Forza'), now=20)
        assistant.companion.generate.assert_not_awaited()
    finally:
        await assistant.close()


async def test_command_success_uses_dynamic_draft_but_failure_discards_it(tmp_path):
    assistant = make_assistant(tmp_path)
    assistant.companion.generate = AsyncMock(return_value='Notepad खुल गया। कुछ लिखने का मन है?')
    try:
        await assistant.submit('Open Notepad')
        await assistant.task
        assert assistant.last_response == 'Notepad खुल गया। कुछ लिखने का मन है?'
        assistant.executor.fail = True
        await assistant.submit('Open Notepad')
        await assistant.task
        assert assistant.last_response.startswith('Stopped here:')
    finally:
        await assistant.close()


async def test_user_reply_cancels_pending_unsolicited_comment(tmp_path):
    assistant = make_assistant(tmp_path)
    entered = asyncio.Event()
    async def generate(*args, **kwargs):
        entered.set()
        await asyncio.Event().wait()
    assistant.companion.generate = generate
    try:
        await assistant._consider_activity(observation('Home'), now=0)
        await assistant._consider_activity(observation('Forza'), now=1)
        await assistant._consider_activity(observation('Forza'), now=5)
        await entered.wait()
        await assistant.submit('/quiet')
        await asyncio.gather(assistant.companion_task, return_exceptions=True)
        assert assistant.companion_task.cancelled()
        assert assistant.last_response == 'Quiet mode on.'
    finally:
        await assistant.close()


async def test_prepared_speech_cancellation_cancels_pending_generation(tmp_path):
    speech = SpeechOutput(VoiceConfig(tts_provider='gemini', tts_cache_directory=str(tmp_path)), EventBus())
    pending = asyncio.create_task(asyncio.Event().wait())
    try:
        speech.say('A novel reply.', prepared=pending)
        speech.stop()  # Cancellation before the speech coroutine even starts.
        await asyncio.gather(pending, speech.task, return_exceptions=True)
        assert pending.cancelled()
    finally:
        await speech.close()


async def test_generic_service_offer_gets_one_contextual_rewrite(tmp_path):
    config, memory, companion = setup_companion(tmp_path)
    companion.router.complete.side_effect = ['कोई खास जानकारी चाहिए तो बताओ।', 'आज drift tuning का मूड है?']
    try:
        assert await companion.generate('activity', activity={'title': 'Forza', 'app': 'chrome.exe'}) == 'आज drift tuning का मूड है?'
        assert companion.router.complete.await_count == 2
    finally:
        memory.close()


async def test_ambiguous_window_does_not_trigger_slow_model_replanning(tmp_path):
    assistant = make_assistant(tmp_path)
    assistant.executor.execute = AsyncMock(return_value=Outcome(False, 'LookupError: Multiple matching windows; specify which one', {}))
    assistant.planner.plan = AsyncMock(side_effect=AssertionError('Ambiguity must not cause replanning'))
    assistant.companion.generate = AsyncMock(return_value=None)
    try:
        await assistant.submit('Open Chrome')
        await assistant.task
        assistant.planner.plan.assert_not_awaited()
        assert 'सामने' in assistant.last_response
        assert assistant.state.outcome == 'failed'
    finally:
        await assistant.close()


async def test_natural_quiet_preference_persists(tmp_path):
    assistant = make_assistant(tmp_path)
    try:
        await assistant.submit('अभी मत बोलो')
        assert assistant.memory.preference('proactive_paused') is True
        assert Personality(assistant.config, assistant.memory).social.user_busy
        await assistant.submit('बात करते रहो')
        assert not assistant.memory.preference('proactive_paused')
    finally:
        await assistant.close()


async def test_conversational_followup_can_interrupt_without_repeating_name(tmp_path):
    from brain.schemas import Plan
    assistant = make_assistant(tmp_path)
    assistant.planner.plan = AsyncMock(return_value=Plan(reply='अच्छा, racing वाला mood है।'))
    try:
        assistant.speech.speaking = True
        assistant.speech_context = 'conversation'
        await assistant.submit('आज racing का mood है', source='voice')
        assert assistant.task is not None
        await assistant.task
        assert assistant.last_response == 'अच्छा, racing वाला mood है।'
    finally:
        await assistant.close()


async def test_novel_prepared_speech_is_used_once_after_handoff_and_not_saved(tmp_path, monkeypatch):
    monkeypatch.setenv('GEMINI_API_KEY', 'test-key')
    speech = SpeechOutput(VoiceConfig(tts_provider='gemini', tts_cache_directory=str(tmp_path)), EventBus())
    speech.providers['gemini'].synthesize_async = AsyncMock(return_value=([0.0]*240, 24000))
    speech.providers['gemini'].last_model = 'gemini-2.5-flash-preview-tts'
    speech.playback.play = AsyncMock()
    try:
        prepared = asyncio.create_task(speech.prepare('YouTube खुल गया। कुछ खास देखने का मन है?'))
        await prepared
        speech.playback.play.assert_not_awaited()
        speech.say('YouTube खुल गया। कुछ खास देखने का मन है?', prepared=prepared)
        await speech.task
        speech.providers['gemini'].synthesize_async.assert_awaited_once()
        speech.playback.play.assert_awaited_once()
        assert not list(tmp_path.iterdir())
    finally:
        await speech.close()
