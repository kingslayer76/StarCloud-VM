"""Order visible controls from measured rectangles, never invented coordinates."""
from urllib.parse import urlparse, parse_qs


def video_url(url):
    parsed = urlparse(url)
    return (parsed.hostname or '').lower() in {'www.youtube.com', 'youtube.com', 'm.youtube.com'} and (
        parsed.path == '/watch' and bool(parse_qs(parsed.query).get('v')) or parsed.path.startswith('/shorts/'))


def video_key(url):
    parsed = urlparse(url)
    return ('watch', parse_qs(parsed.query)['v'][0]) if parsed.path == '/watch' else ('shorts', parsed.path)


def ordered_controls(rows, category):
    types = {'video': 'HyperlinkControl', 'link': 'HyperlinkControl', 'button': 'ButtonControl',
             'tab': 'TabItemControl', 'item': 'ListItemControl'}
    unique = {}
    for row in rows:
        if row['type'] != types[category] or not row.get('enabled', True):
            continue
        if category == 'video' and not video_url(row.get('url', '')):
            continue
        rect = row['rect']
        if rect[2] <= rect[0] or rect[3] <= rect[1]:
            continue
        if category == 'video':
            key = video_key(row['url'])
        else:
            key = tuple(rect)
        old = unique.get(key)
        if not old or (rect[1], rect[0]) < (old['rect'][1], old['rect'][0]):
            unique[key] = row
    pending = sorted(unique.values(), key=lambda r: (r['rect'][1], r['rect'][0]))
    result = []
    while pending:
        top = pending[0]['rect'][1]
        band = [r for r in pending if r['rect'][1] <= top+40]
        pending = [r for r in pending if r['rect'][1] > top+40]
        result.extend(sorted(band, key=lambda r: r['rect'][0]))
    return result
